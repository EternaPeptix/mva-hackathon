# Independent batch11 eligibility audit — 2026-10-04

The independent available-abstract reading is complete for **160 distinct source/ID records**, totaling **316,943 literal saved-abstract characters**. The original lane set **cannot be accepted unchanged**: 19 route disagreements require root adjudication. No coverage acceptance, primary main-paper efficacy appraisal, candidate qualification, or ledger credit is granted by this audit.

All available abstract text, titles, publication types and saved notice/version metadata were read to displayed end markers. The original source abstracts' completeness has not been independently established. The initial 1–20 tool output was truncated in its middle; orders 9–12 were reread separately in an untruncated output. Remaining reads were bounded groups of ten. This was independent route assessment followed by a comparison, **not a blinded review**: the first three root annotations were visible during schema inspection before the source pass. Every record has a short literal, character-indexed and hash-bound source anchor in `independent-screen.json` and the six annotation JSONL files.

The independent proposal before root adjudication is C 47, H_CF 85, H_UF 7, H_M 13, P_F 5, P_M 2, U 1. These counts are proposals, not accepted final lanes. Cognitive-only, mental-fatigue, global-recovery, inferred-strength and passive-tissue-mechanics routes require explicit endpoint labels and adjudication against the frozen definitions; no favorable result or candidate competitiveness was used for eligibility.

## Disagreements

The source-text basis and all cautions are preserved in `disagreements.json`; this table is a navigation view. Root must retain the original annotations alongside each adjudication.

| Order | Exact record | Root → independent proposal | Literal short source anchor |
|---:|---|---|---|
| 43 | PMC:PMC7607346 | C → H_UF | His power improved to 3/5 on MRC grading |
| 52 | MED:41843413 | C → H_CF | 1-h CWI at 10°C |
| 71 | MED:8818199 | H_M → H_CF | maximal oxygen uptake was significantly increased |
| 82 | MED:31562049 | C → H_CF | Physical function measures included grip strength |
| 91 | MED:39533187 | C → U | quality of recovery-15 (QoR-15) scale |
| 97 | MED:16565362 | C → H_CF | mobility subscale compared with the placebo group |
| 98 | MED:30854916 | H_M → H_CF | no statistically significant between-group differences |
| 100 | MED:35028890 | H_M → H_CF | diminished muscle mass, muscle strength |
| 115 | MED:11916809 | C → H_CF | recovery of sensory and motor function |
| 119 | MED:23229869 | H_CF → H_M | time to achieve eligibility for PACU discharge |
| 131 | MED:41416984 | C → H_CF | Cognitive findings were mixed |
| 136 | MED:19393841 | U → H_CF | ability to perform daily activities |
| 142 | MED:22101698 | C → H_CF | Physical function of SF-36 QOL questionnaire |
| 145 | MED:36739264 | C → P_M | up-regulated claudin-1 and mucin-1 expression |
| 147 | MED:11834155 | C → P_F | torsional strength of the therapy group |
| 152 | MED:30640362 | H_M → H_CF | Movement Disorders Society Unified Parkinson's Disease Rating Scale part 3 |
| 153 | PMC:PMC6574075 | H_M → H_CF | post-75 km cycling (176 |
| 156 | MED:1787282 | C → H_M | mean stool output, number of stools, or weight gain |
| 159 | MED:3666191 | C → P_F | Estrogen administration was found to increase BS and EX |

The clearest missed-text cases are 43 (administered steroids/MMF and MRC power change), 82 (grip/knee strength/walking explicitly measured), 115 (observed motor recovery), 136 (WOMAC daily activity), and 142 (SF-36 physical function). Orders 71 and 153 illustrate the fixed rule that measured physiology or actual descriptive performance remains eligible despite a biomarker-focused report or absent arm-specific effect estimate. Order 119 illustrates the converse: mobility in an introduction does not establish that a motor outcome was measured. Orders 152/153 supply no new independent trial or randomized functional-effect estimate merely because their record route is functional.

Orders 91, 97, 98 and 131 require explicit handling of cognition/vision/mobility/fatigue versus muscle/task function; generic QoL wording must not automatically become function. Order 100 explicitly mentions diminished muscle strength, but its instrument and actual direct assessment are unclear; U is defensible pending recovery of that fact, while an asserted absence of function is too strong. For 147/159, passive biological tissue mechanics must be labeled as bone-callus torsion/uterine-wound burst tests, never muscle contraction. The fixed rule preserves biological tissue mechanics separately from shell/material production strength. Order 145 has actual molecular exposure outcomes even though its poultry production endpoints are not functional; order 156 has actual defined-food nutritional/clinical outcomes rather than muscle function.

## Binding and notice findings

`source-and-annotation-integrity.json` reports 225 declared binding rows checked with no failures, all 160 literal anchors valid, all source IDs distinct and all abstract hashes matching the frozen records. The existing selection-verifier logic was copied with only its output path redirected and rerun without touching original artifacts. `selection-verification-rerun.json` passes reconstruction of the 55,057-record continuation queue, 160 selected records, 54,897 unselected records, exact 64/48/48 strata, 239 raw origins on 57 raw pages, and exact selected core equality. This is reproducible identity evidence; it does not establish scientific reading by itself.

The 22 saved notice/version-bearing records agree with the root notice table. No selected record has a retraction publication type in the saved metadata. Comments and updates were retained as document relationships; no unseen comment body was credited. Two short linked notice bodies were separately read from primary-source web results: the [Pavis corrigendum](https://journals.physiology.org/doi/full/10.1152/ajpendo.00328.2021_COR) corrects Table 5 protein/DNA content labels from wet to dry weight; the [Exenatide-PD byline notice](https://jamanetwork.com/journals/jamaneurology/articlepdf/2729107/jamaneurology_2019_cx_190004.pdf) corrects an author name. Neither short notice states a functional-result correction. Main-paper appraisal credit remains zero. Europe PMC notice-XML requests returned HTTP 500; the error manifest is retained. Order 74's Crossmark current status was reported by root on September 28 and was not independently refreshed here. Order 84's title/first-author-based preprint/journal link needs confirmation before an asserted alias/family merge.

## Common-compound follow-up leads

These are routes for source-specific follow-up, not efficacy admissions or a competitiveness ranking:

- Inulin, order 149 MED:41829888: controlled secondary grip-strength result in knee OA; verify exact dose/control, factorial contrasts, secondary status and attrition. Existing root primary work should be checked before duplicating it.
- HMB, order 73 MED:37248756: placebo plus common-training comparison with grip, gait and chair-stand outcomes; verify preparation and prior appraisal. Orders 80/96 are nutritional products or amino-acid mixtures and cannot be treated as isolated HMB evidence.
- Vitamin D2, order 123 MED:41449463: unusually high intramuscular regimen in deficient intestinal-failure adults; primary source/registration/safety and formulation must be verified before any transfer claim. This is not a retail-D or pediatric/MVA result.
- Salidroside, order 25 MED:40988719: title says Rhodiola while the abstract specifies salidroside; preparation identity and exercise-matched contrast need recovery.
- Standardized ashwagandha, order 34 MED:41940566; fish oil, order 9 MED:22218156; PS128 probiotic, order 64 MED:38098805: actual controlled functional outcomes, each restricted by exact preparation, small cohort and athlete/aging context.
- The common-compound screen also retains useful nulls: NAC order 30; whey/potassium bicarbonate order 72; NMN formulation MIB-626 order 110; citrulline/citrulline-malate order 49. These are source-specific results and **not candidate failures**.

## Acceptance recommendation

The source packet and full independent abstract-reading scope are verified. Accept the completed reading only after root records a disposition for all 19 disagreements, including unresolved taxonomy where necessary. An uncertain record may count as screened without being resolved, but the provisional lane distribution must not be presented as independently confirmed. The audit does not enumerate every compound, establish efficacy in BUB1B, compare against leaders, or qualify any source at full-paper depth.
