import pathlib,json,hashlib,datetime
O=pathlib.Path('/Users/jeweled/mva-hackathon/track2-drug-census-work/global-existing-evidence-stage-register-20261005')
def j(n):return json.loads((O/n).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(n,d):
 p=O/n;assert not p.exists(),p;p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
q=j('mechanical-qa.json');r=j('frozen-input-rebuild-verification.json');reg=j('source-evidence-stage-register.json');den=j('bounded-stage-denominators.json')
assert q['status']==r['status']=='PASS' and q['check_count']==125332
checks=[]
def c(n,b):checks.append({'check':n,'pass':bool(b)})
c('all309 preserved complete',len(reg['records'])==309)
c('all874 URL occurrences',len(reg['source_preparation_contrast_identifier_occurrences'])==874)
c('all8740 component rows',len(reg['component_rows'])==8740)
c('125332 source-field QA PASS',q['status']=='PASS' and q['check_count']==125332)
c('12frozen rebuild groups PASS',r['status']=='PASS' and len(r['comparisons'])==12)
c('3byteidentical TSVs',sum(x.get('byte_identical') is True for x in r['comparisons'])==3)
c('wholemain denominator UNKNOWN',den['full_main_qualified_source_denominator']=='UNKNOWN')
c('allnewcreditszero',reg['all_new_chemical_alias_trial_source_reading_efficacy_nominee_credits']==0)
c('historical failed helpers preserved',(O/'historical-build-attempt-01/error-note.json').is_file() and (O/'historical-reproduction-reference-order-only-FAIL/failed-rebuild-verification.json').is_file())
c('derived scratch cleaned',not (O/'reproduction-scratch').exists())
for n in ['report.md','summary.md','REPRODUCIBILITY.md']:
 t=(O/n).read_text();c('readable309scope:'+n,'309' in t);c('readable UNKNOWNscope:'+n,'UNKNOWN' in t)
inputs=j('input-snapshot-bindings.json')
for x in inputs['frozen_files']:
 p=pathlib.Path(x['copy']);c('frozeninput:'+p.name,sha(p)==x['sha256'] and p.stat().st_size==x['bytes'])
g=j('explicit-linked-document-capture.json')
for x in g['documents']:
 p=pathlib.Path(x['frozen_copy']);c('947explicitdocument:'+x['document_id'],sha(p)==x['sha256'] and p.stat().st_size==x['bytes'])
Q=pathlib.Path('/Users/jeweled/mva-hackathon/track2-drug-census-work/common-acquired-frontier-fourth-primary-independent-20261005')
c('Q03final SHA unchanged',sha(Q/'final-bindings.json')=='5a613492d3cc5cbd122301a02cf497fc5aa04f69b28430687aad2ca1119aae35')
for x in json.loads((Q/'final-bindings.json').read_text())['entries']:
 p=pathlib.Path(x['path']);c('Q03protectedbyteidentity:'+str(p),sha(p)==x['sha256'] and p.stat().st_size==x['bytes'])
status='PASS' if all(x['pass'] for x in checks) else 'FAIL'
save('fresh-final-closure-checks.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':status,
 'checks':checks,'check_count':len(checks),'fresh_readonly_full_QA_call':{
  'command':'python3 verify_mechanical_register.py --check-only','actual_tool_output_chunk_id':'c4bf63',
  'status':'PASS','checks':125332,'raw_pointer_fresh_rechecks':14453,'writes':0},
 'scientific_reading_or_comprehension_validated':False,'Q03all204originalbindings_unchanged':True})
assert status=='PASS','Retain closure failure; do not bind a failed package'
save('closure-scope.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'COMPLETE_MECHANICAL_EXISTING_EVIDENCE_REGISTER','owned_root':str(O),
 'captured_HEAD':inputs['HEAD_start'],'captured_ledger_sha256':reg['ledger_snapshot_sha256'],
 'original_decisions':309,'source_URL_occurrences':874,'component_rows':8740,
 'explicit_captured_documents':947,'reported_depth_fields':14673,'reported_stage_fields':516,
 'reported_preparation_contrast_fields':1674,'uncapped_gap_objects':12660,
 'reported_claims_independent_bytes_and_UNKNOWN_separate':True,
 'new_assays_or_scientific_outcome_reappraisal':0,'new_chemical_alias_trial_source_reading_rank_nominee_credits':0,
 'repository_and_foreign_original_edits':0,'Q03unchanged':True,'growing_foreign_directories_bound':False,
 'whole_primary_and_validated_stage_denominators':'UNKNOWN','worldwide_coverage_complete':False,
 'all_original_fields_and_historical_depth_retained':True,'mechanical_QA_checks':125332,
 'successful_frozen_rebuild_comparisons':12,'fresh_closure_checks':len(checks)})

# Exclude only exact owned root self-files, never every file with that basename.
excluded={O/'final-bindings.json',O/'final-verification.json'}
files=sorted(p for p in O.rglob('*') if p.is_file() and p not in excluded)
assert all(not p.is_symlink() for p in files)
entries=[{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]
save('final-bindings.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'CLOSED_IMMUTABLE_MECHANICAL_STAGE_REGISTER','root':str(O),'entries':entries,
 'binding_count':len(entries),'physical_file_count_after_final_verification':len(entries)+2,
 'bound_bytes':sum(x['bytes'] for x in entries),'self_excluded_exact_paths':[str(p) for p in sorted(excluded)],
 'captured_repository_HEAD':inputs['HEAD_start'],'captured_ledger_sha256':reg['ledger_snapshot_sha256'],
 'original309_verbatim':True,'source_URL_occurrences_not_unique_sources':874,
 'component_rows_not_reading_or_trial_counts':8740,'full_primary_validated_stage_denominators':'UNKNOWN',
 'scientific_comprehension_or_efficacy_validation':False,'all_new_credit_layers':0,
 'mechanical_QA_checks':125332,'fresh_closure_checks':len(checks),'frozen_only_rebuild':'PASS',
 'Q03_original204bindings_unchanged':True,'foreign_directories_not_bound':True,'foreign_originals_not_mutated':True,
 'historical_failures_and_mixed_partial_access_claims_retained':True})
mf=j('final-bindings.json');rechecks=[]
for x in mf['entries']:
 p=pathlib.Path(x['path']);rechecks.append({'path':str(p),'bytes_pass':p.stat().st_size==x['bytes'],'sha256_pass':sha(p)==x['sha256']})
actual={p for p in O.rglob('*') if p.is_file()};expected={pathlib.Path(x['path']) for x in entries}|{O/'final-bindings.json'}
assert actual==expected and all(x['bytes_pass'] and x['sha256_pass'] for x in rechecks)
save('final-verification.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS',
 'manifest':str(O/'final-bindings.json'),'manifest_sha256':sha(O/'final-bindings.json'),
 'fresh_rehashed_bindings':len(entries),'checks':rechecks,'exact_owned_physical_coverage_before_self':True,
 'physical_files_after_self':len(entries)+2,'mechanical_QA_status':'PASS','mechanical_QA_checks':125332,
 'fresh_closure_status':'PASS','fresh_closure_checks':len(checks),'frozen_only_rebuild_status':'PASS',
 'all_original309objects_retained':True,'new_credit_all_layers':0,'repo_foreign_Q03mutations':0})
assert {p for p in O.rglob('*') if p.is_file()}=={pathlib.Path(x['path']) for x in entries}|excluded
print(json.dumps({'status':'CLOSED_PASS','manifest':str(O/'final-bindings.json'),
 'manifest_sha256':sha(O/'final-bindings.json'),'verification_sha256':sha(O/'final-verification.json'),
 'bindings':len(entries),'physical_files':len(entries)+2,'bound_bytes':sum(x['bytes'] for x in entries),
 'fresh_closure_checks':len(checks),'mechanical_QA_checks':125332,'original309_verbatim':True}))
