"""Freeze exact ledger report and explicit metadata edges, never enumerate foreign trees.

This program reads documentation/JSON mechanically, not scientific sources for a
new appraisal. Raw scientific bodies are NOT opened as scientific text here.
"""
import pathlib,json,hashlib,re,urllib.parse,datetime,collections,os
O=pathlib.Path(os.environ.get('MVA_STAGE_REGISTER_ROOT','/Users/jeweled/mva-hackathon/track2-drug-census-work/global-existing-evidence-stage-register-20261005'))
R=pathlib.Path('/Users/jeweled/Documents/Codex/2026-09-18/co/work/mva-pr2-hmb-integration-20260928')
F=O/'frozen-linked-documents';F.mkdir(exist_ok=True)
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(n,d):
 p=O/n;assert not p.exists(),p;p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def resolve(s,base):
 raw=s; s=s.strip().strip('`').strip('<>');s=urllib.parse.unquote(s.split('#')[0])
 if re.match(r'^https?://',s):return None,'REMOTE_IDENTIFIER_ONLY_NOT_FETCHED'
 if s.startswith(('workflow/','reports/')):return R/s,'REPOSITORY_ROOT_EXPLICIT_RELATIVE'
 if s.startswith('/'):return pathlib.Path(s),'EXPLICIT_ABSOLUTE'
 if s.startswith(('file://','app://','codex://')):return None,'UNSUPPORTED_POINTER_SCHEME_RETAINED'
 if s and re.search(r'\.(?:json|jsonl|md|txt|xml|pdf|docx|html|htm|tsv|csv|png|jpg|jpeg|zip)(?:$|[?#])',s,re.I):return base/s,'EXPLICIT_DOCUMENT_RELATIVE'
 return None,'UNRESOLVED_NONFILE_POINTER_RETAINED'
docs={};edges=[];queue=collections.deque();rootedges=[]
ds=json.loads((O/'frozen-inputs/repository/decisions.json').read_text())['decisions']
for d in ds:
 for key in ['source_report','additional_source_reports','related_source_reports']:
  if key not in d:continue
  vals=d[key] if isinstance(d[key],list) else [d[key]]
  for i,v in enumerate(vals):
   if isinstance(v,str):
    p,reason=resolve(v,R);e={'decision_id':d['decision_id'],'original_field':key,'ordinal':i,'raw_pointer':v,'resolution_policy':reason,
     'path':str(p) if p else None,'edge_kind':'EXACT_LEDGER_REPORT'};rootedges.append(e)
    if p:queue.append((p,e,None))
 for key in ['source_qualification_audit','batch14_primary_source_audit','independent_bounded_qualification','root_source_adjudication_audit']:
  v=d.get(key)
  if isinstance(v,dict) and isinstance(v.get('path'),str):
   p,reason=resolve(v['path'],R);e={'decision_id':d['decision_id'],'original_field':key,'raw_pointer':v['path'],
    'resolution_policy':reason,'path':str(p) if p else None,'edge_kind':'EXACT_LEDGER_AUDIT','expected_binding_original':v};rootedges.append(e)
   if p:queue.append((p,e,v))

# Only explicit metadata pointers from inspected documentation/metadata are
# traversed. No rglob/rg/find or inferred directory companions are used.
metadata_name=re.compile(r'(manifest|reading|receipt|scope|audit|binding|qualification|source[-_]?(?:check|retriev|data|depth|compo)|adjudicat)',re.I)
structured_name=re.compile(r'\.(json|jsonl)$',re.I)
report_name=re.compile(r'\.(md)$',re.I)
path_leaf=re.compile(r'(?:path|file|manifest|receipt|scope|audit|bind|report|source)',re.I)
while queue:
 p,edge,expected=queue.popleft();p=p.resolve();k=str(p)
 if k in docs:
  edge['document_id']=docs[k]['document_id'];edge['retrieval_existence']='FILE_PRESENT_CAPTURED';edges.append(edge);continue
 if not p.is_file():edge['retrieval_existence']='UNRESOLVED_FILE_NOT_PRESENT';edge['document_id']=None;edges.append(edge);continue
 before=sha(p);raw=p.read_bytes();after=sha(p)
 if before!=after:edge['retrieval_existence']='UNSTABLE_FILE_DURING_CAPTURE';edge['document_id']=None;edges.append(edge);continue
 did=f'DOC{len(docs)+1:04d}';copy=F/(did+'-'+p.name);copy.write_bytes(raw)
 rec={'document_id':did,'original_path':k,'frozen_copy':str(copy),'bytes':len(raw),'sha256':before,
   'byte_capture_verified':sha(copy)==before,'stable_during_capture':True,'role':'DOCUMENTATION_OR_EXPLICIT_METADATA',
   'new_actual_scientific_source_reading_credit':0,'explicit_parent_edges':[]}
 if expected:rec['ledger_expected_binding']=expected;rec['ledger_expected_hash_matches_capture']=expected.get('sha256',before)==before;rec['ledger_expected_bytes_matches_capture']=expected.get('bytes',len(raw))==len(raw)
 docs[k]=rec;edge['document_id']=did;edge['retrieval_existence']='FILE_PRESENT_CAPTURED';edges.append(edge)
 if p.suffix.lower()=='.md':
  text=raw.decode('utf-8',errors='replace')
  for m in re.finditer(r'\[([^\]]*)\]\(([^\n)]+)\)',text):
   label,s=m.groups();qp,why=resolve(s,p.parent)
   ne={'parent_document_id':did,'original_path':k,'character_start':m.start(),'character_end':m.end(),'raw_pointer':s,
    'link_label_verbatim':label,'resolution_policy':why,'path':str(qp) if qp else None,'edge_kind':'EXPLICIT_MARKDOWN_LINK'}
   # Ordinary article/web references remain identifier edges, not remote fetches.
   if qp and (structured_name.search(qp.name) or (report_name.search(qp.name) and metadata_name.search(qp.name))):queue.append((qp,ne,None))
   else:ne['traversal']='NOT_FOLLOWED_RAW_SOURCE_OR_NON_METADATA_LINK';edges.append(ne)
  # An absolute code/prose pointer is also explicit, even without Markdown syntax.
  seen=set()
  for m in re.finditer(r'/Users/[^\n`<>\]"\)]+?\.(?:json|jsonl|md)',text):
   s=m.group(0)
   if s in seen:continue
   seen.add(s);qp,why=resolve(s,p.parent)
   if qp and metadata_name.search(qp.name):queue.append((qp,{'parent_document_id':did,'original_path':k,
    'character_start':m.start(),'character_end':m.end(),'raw_pointer':s,'resolution_policy':why,
    'path':str(qp),'edge_kind':'EXPLICIT_ABSOLUTE_METADATA_TEXT_POINTER'},None))
 elif p.suffix.lower() in ['.json','.jsonl']:
  try:
   obj=json.loads(raw) if p.suffix.lower()=='.json' else [json.loads(l) for l in raw.decode().split('\n') if l]
  except Exception as ex:rec['JSON_parse_error']=type(ex).__name__;continue
  def walk(v,path=''):
   if isinstance(v,dict):
    for key,x in v.items():
     pp=path+'/'+str(key).replace('~','~0').replace('/','~1')
     if isinstance(x,str) and path_leaf.search(key):
      qp,why=resolve(x,p.parent)
      if qp:
       ne={'parent_document_id':did,'original_path':k,'JSON_pointer':pp,'raw_pointer':x,'resolution_policy':why,
        'path':str(qp),'edge_kind':'EXPLICIT_JSON_METADATA_POINTER'}
       if qp.suffix.lower() in ['.json','.jsonl','.md'] and metadata_name.search(qp.name):queue.append((qp,ne,None))
       else:
        ne['traversal']='NOT_TEXT_READ_RAW_COMPONENT_OR_NON_METADATA'
        ne['retrieval_existence']='FILE_PRESENT' if qp.is_file() else 'UNRESOLVED_FILE_NOT_PRESENT'
        # For scientific source files, pin existence and bytes; hash verification
        # remains a separate field, never reading credit.
        if qp.is_file():
         ne['independent_byte_identity']={'bytes':qp.stat().st_size,'sha256':sha(qp),'actual_scientific_reading':False}
         if 'sha256' in v:
          ne['reported_source_binding_verbatim']={a:v[a] for a in ['path','file','source','sha256','bytes'] if a in v}
          ne['reported_sha256_matches_verified_bytes']=v['sha256']==ne['independent_byte_identity']['sha256']
        edges.append(ne)
     walk(x,pp)
   elif isinstance(v,list):
    for i,x in enumerate(v):walk(x,path+'/'+str(i))
  walk(obj)

# Reverse graph retains all duplicate and historical pointer occurrences.
for e in edges:
 if e.get('document_id'):
  rec=next(x for x in docs.values() if x['document_id']==e['document_id']);rec['explicit_parent_edges'].append({k:v for k,v in e.items() if k!='document_id'})
save('explicit-linked-document-capture.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'EXACT_POINTER_GRAPH_MECHANICALLY_CAPTURED','documents':list(docs.values()),'edges':edges,
 'root_ledger_edges':rootedges,'document_count':len(docs),'edge_count':len(edges),
 'foreign_directory_enumeration':False,'web_scientific_fetches':0,'scientific_outcome_reappraisal':False,
 'frozen_repository_inputs':'input-snapshot-bindings.json','scope':'Individual exact pointers only; no guessed companion files, broad filesystem hunt or cohort equivalence',
 'hash_title_rationale_presence_not_source_reading':True,'credit_all_layers':0})
print(json.dumps({'documents':len(docs),'edges':len(edges),'unresolved_edges':sum(e.get('retrieval_existence')=='UNRESOLVED_FILE_NOT_PRESENT' for e in edges),
 'raw_component_files_byte_checked':sum('independent_byte_identity' in e for e in edges),'bytes_captured':sum(x['bytes'] for x in docs.values())}))
