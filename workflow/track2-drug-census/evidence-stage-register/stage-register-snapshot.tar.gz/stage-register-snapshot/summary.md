# Existing-evidence stage register complete

All309 existing decisions are preserved verbatim at captured HEAD `4ca09e9b8d34a868c41e9f952c06f3d725c6c242`. The register contains874 original URL occurrences and8,740 component rows; these are not unique drugs or trials.

Reported depth and labels remain separate from verified bytes:947 exact linked documents,14,673 reported depth fields,1,674 preparation/contrast fields and12,660 uncapped gap objects are retained. Main and475 status-unverified catalogue rows remain separate; no chemical or alias join is added. Whole-primary, validated BUB1B/restoration/function and competitiveness denominators remain UNKNOWN.

All125,332 mechanical QA checks passed, including14,453 explicit byte-pointer rechecks. Frozen-only rebuild passed12 comparisons; all3 TSVs are byte-identical. Historical helper failures and mixed/partial/access claims are retained. Q03, foreign packages, repository, evidence labels and nominees remain unchanged; all new admission/source-reading/trial/rank credits are0.

[Register](/Users/jeweled/mva-hackathon/track2-drug-census-work/global-existing-evidence-stage-register-20261005/source-evidence-stage-register.json) · [Decision TSV](/Users/jeweled/mva-hackathon/track2-drug-census-work/global-existing-evidence-stage-register-20261005/source-evidence-stage-register-decisions.tsv) · [Component TSV](/Users/jeweled/mva-hackathon/track2-drug-census-work/global-existing-evidence-stage-register-20261005/source-evidence-stage-register-components.tsv) · [Full report](/Users/jeweled/mva-hackathon/track2-drug-census-work/global-existing-evidence-stage-register-20261005/report.md)
