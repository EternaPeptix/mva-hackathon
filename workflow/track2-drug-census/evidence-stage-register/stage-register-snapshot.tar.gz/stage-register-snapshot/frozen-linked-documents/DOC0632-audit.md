# Shatavari PMID 39834460: controlled performance and contractility, post-training strength nonpositive

[Greed et al.](https://pmc.ncbi.nlm.nih.gov/articles/PMC11743497/) supports nominal objective training-performance and evoked-contractility signals. It does not demonstrate extra post-training strength or hypertrophy. Preserve both categories rather than erase positives or recast training load as the primary strength win.

Participants took two 500-mg shatavari-powder capsules daily (1,000 mg/day; source-reported fresh-root equivalent 26,500 mg/day) versus two matched 500-mg magnesium-stearate capsules during eight weeks of supervised leg training. Product brand, standardized constituents, lot and analytical content are not established; Pukka Herbs funding alone does not identify retail equivalence. Independent randomization/double blinding is reported.

26 older and 18 younger women were recruited/randomized; 22 older (11/11) and 17 younger (SH 9/PL 8) completed. Four older withdrawals were attributed to unrelated medical reasons and one younger withdrawal to time. Native Figure 4 uses only 10 older placebo participants for LP strength, versus 11 for older KE; that missing record is unexplained. Younger training analyses show residual df=9 without explicit outcome Ns. Proteomics used older 8/8 and younger 5/7 only. No full-randomized efficacy/sensitivity analysis is demonstrated.

| Reported controlled result | Statistical result | Scope |
|---|---|---|
| Older weekly LP repetitions | P=.049, partial η²=.198 | Nominal objective training-performance positive |
| Older weekly LP maximum weight/baseline 1RM | P=.03, partial η²=.386 | Nominal normalized-load positive; F/P inconsistency |
| Older weekly KE maximum weight/baseline 1RM | P=.043 | Positive in Results/native Figure 3B despite Discussion's broad no-KE-load statement |
| Older KE repetitions | P=.286 | Nonpositive |
| Younger repetitions/normalized loads | P=.123–.745 | Nonpositive |
| Older post-training LP/KE 1RM | P=.575/.293 | Nonpositive; KE1RM is the main-declared primary |
| Younger post-training LP/KE 1RM | P=.969/.436 | Nonpositive |
| Grip, fiber size, isometric knee MVC | Supplement effects nonpositive | Shared training adaptations do not establish compound renewal |
| Older potentiated-twitch half-relaxation time | SH−11.74±11.93% versus PL+.42±14.73%; P=.021 | Contractility timing; direct fatigue challenge not performed |
| Younger evoked peak-twitch amplitude | Rest P=.006, MVC-state P=.029, potentiated P=.010 | Retained nominal contractility signals, distinct from voluntary strength |

Baseline-controlling repeated ANCOVA and Bonferroni posthoc tests are reported. Global control across many functional endpoints/age groups is unverified. Primary KE1RM was nonpositive; a protocol/registry specifying prospective hierarchy was not recovered. The older trial stopped below its planned 16/group after a stated blinded interim; younger recruitment stopped below target amid COVID/resource limits. The printed power notation 1−β=.08 remains unrepaired; nonsignificance is not equivalence.

Reported F(1,19)=11.951 with P=.03 is internally inconsistent: literal F/df give approximately .00264057. The KE-repetition η²=.62 likewise differs from approximately .0621 using its reported F/df. Separate consistency calculations preserve these as reporting conflicts, not raw-data reproduction or replacement P values. The Discussion's no-KE-load claim also conflicts with Results/native Figure 3B. Other minor table/prose conflicts are recorded in audit.json.

No individual proteomic proteins were significant. Selected older contractile/transcription/translation pathways decreased, while innate/acute-phase/complement pathways increased; younger directions differ. These pathways do not prove clinical harm, mechanistic mediation, productive renewal or BUBR1 rescue. No serious AEs were reported; complete event/lab tables and long-term/pediatric safety are unavailable. Funding was Pukka Herbs; authors declared no commercial/financial conflicts.

Read completely: scientific main, all main tables/captions, front funding/declarations, all four native figures and both native tables; full DOCX supplement text/cells plus native Supplementary Figure 1. References were not individually qualified. Zenodo files were inventoried/downloaded but participant workbooks remain unread; no replay is claimed. No own registry was identified; NCT05025917 belongs to the distinct six-week 2019 cohort. Main PMID/DOI were absent from the immutable 300-decision snapshot/source reports. Targeted reading grants zero collection-screen IDs and no ledger admission.
