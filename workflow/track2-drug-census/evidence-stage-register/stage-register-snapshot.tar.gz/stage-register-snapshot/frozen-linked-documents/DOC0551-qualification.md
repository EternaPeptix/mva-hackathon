# 2021 D,L-3HB sodium salt in septic mice: qualified primary appraisal

**Retain a preparation-specific, survivor-only muscle-force signal alongside substantial dose-associated harm.** [Weckx et al., 2021](https://doi.org/10.1186/s40360-021-00517-7) reports higher ex vivo specific EDL force at 150 and 180 mg/day, without preservation of EDL mass. The 180 mg/day arm also had worse illness; higher doses increased mortality. Even 150 mg/day altered electrolytes. This supports neither a broadly safe dose nor a class-wide verdict on ketones, food, retail supplements, or human treatment. External qualification only: no queue credit or repository integration.

## Preparation and design

The material was **D,L-3-hydroxybutyrate sodium salt**, supplied by Sigma-Aldrich. This paper does not identify the catalogue number, batch, purity, analytical enantiomer ratio, injection solvent, concentration, or volume. Do not silently import the earlier paper's H6501 preparation details. It was administered **subcutaneously twice daily from day 1**, alongside intravenous parenteral nutrition; it was not oral, an ester, or a continuous ketone infusion. Reported 150/180/225/300 mg doses are **daily totals**, not amounts per injection. Equal splitting is plausible but not explicitly quantified in the inspected report.

Twenty-four-week-old male C57BL/6J mice underwent catheterized, fluid-resuscitated CLP sepsis for five days, with antibiotics, analgesia and Olimel N7E nutrition (5.8 kcal/day). Healthy controls were pair-fed 5.8 kcal/day. The septic comparator received glucose 187.5 mg/day, described as isovolumetric/isocaloric. Dose-specific calorie matching across the escalating salt doses is not demonstrated, and no sodium-matched comparator was included.

Random allocation and blinded caretakers/data collectors are reported. Sequence generation and concealment are not detailed. Adaptive dose finding tested 300 after the 150 reference and then de-escalated to 225 and 180. The target was 15 survivors with force measurements when toxicity was absent; no formal power calculation or prospective protocol/SAP was identified. The measured force samples were smaller in several groups. Ethics approval: P124/2017.

## Animals, survival and force

| Group; total daily salt dose | Day-5 survivors / included | Deaths | Specific-force n | EDL dry-mass n |
|---|---:|---:|---:|---:|
| Healthy | 14/14 | 0 | 13 | 13 |
| Septic glucose | 15/18 | 3 | 12 | 15 |
| 150 mg | 16/23 | 7 | 13 | 16 |
| 180 mg | 12/24 | 12 | 12 | 12 |
| 225 mg | 7/16 | 9 | pooled below | pooled below |
| 300 mg | 1/8 | 7 | pooled below | pooled below |
| Pooled 225 + 300 survivors | 8/24 | 16 | 8 | 8 |

The first six included denominators sum to 103. Nine exclusions were reported: two pre-surgery physical abnormalities, one surgery death in the 300 group, and six catheter malfunctions (one 300, one 150, four 225). A complete initial-allocation flow is not supplied; the plotted denominators should not be labeled all randomized animals. Most blood/gene/water outcomes have n=14/15/16/12/8; histology n=13/14/16/12/8; supplementary microglia n=14/15/16/10/8 (healthy/placebo/150/180/pooled high). Missing-assay reasons are not given.

Native Figure 7a and Methods identify **CSA-normalized specific maximal tetanic force, mN/mm²**, despite the caption's imprecise “per unit muscle mass” wording. The 150 and 180 arms each have P≤.05 versus placebo. No group absolute-force result is presented. Nonsignificance versus healthy animals (abstract P≥.3) does not establish equivalence or full normalization. The pooled high-dose survivors show no significant force benefit; pooling seven 225 survivors with one 300 survivor cannot establish separate high-dose efficacy. All terminal outcomes condition on survival, and EDL dry-mass loss persists. No whole-animal strength, locomotion, cognition or long-term recovery was demonstrated.

## Harms, nulls and reporting limits

- Native Figure 1 shows illness worsened at 180/225/300 versus 150 (P=.03/.04/.0008 respectively); placebo comparisons are marked P≤.01/≤.01/≤.001. The abstract gives P=.004 for doubled-dose illness, rather than native .0008; preserve this reporting difference. The mortality increase from 30.4% to 87.5% compares **150 with 300**, not glucose placebo with 300. Mortality at 225/300 is significantly higher than 150; the 180-versus-150 mortality comparison is nonsignificant (reported P=.2), despite 50% deaths.
- At **150 already**, Figure 2 marks higher sodium, pH and bicarbonate and lower potassium/chloride versus glucose. Higher doses further disturb selected measures. The pooled high group has reduced brain/lung water. Aldosterone and liver/muscle water show no detected salt-dose effect. Absence of significant mortality worsening at 150 is not absence of biochemical harm.
- Figure 4 supports higher Kim1 and lower Vnn1 at 180/high versus placebo. Creatinine is higher versus healthy controls in salt arms, but has **no significant placebo-comparison marker**. Avoid describing all renal results as placebo-controlled injury or clinical kidney failure.
- Figure 3 supports greater dentate-gyrus neuronal-damage scores in the pooled high arm; no significant group changes are marked in CA1/CA3. Hepatic histology is largely null; 180 has greater sinusoidal dilatation versus healthy controls, not a demonstrated placebo difference. No brain behavior or renal histology outcome was assessed.
- Plasma TNFα and kidney/liver Tnf show no detected salt benefit; pooled-high hippocampal Tnf is higher than 150 (P=.02). **The microglia prose is broader than native Supplementary Figure 1:** 180 has a CA3 marker versus healthy only; no dentate or placebo marker. Pooled high has CA3 markers versus healthy/placebo and a dentate marker versus placebo. CA1 is unmarked. The supplement does not establish the full set of 180-dose comparisons claimed in the prose.
- Free fatty acids/glycerol show no detected placebo differences. Ppara/Hmgcs2 changes are pathway readouts, not functional rescue. Sparse ketone measurements—30 minutes on day 1 and four hours on day 5—are not a formal clearance study. Methods call the early measurement whole blood; Results call it plasma. Enantiomer-specific exposures were not characterized.

Student t, Wilcoxon, log-rank and Pearson chi-square tests are listed with two-sided P≤.05. Multiplicity control is **not reported**; do not import the 2022 paper's explicit statement. Numerous nominal comparisons, small surviving groups, adaptive stopping, pooling, and missing assay explanations constrain inference. Figure 7 summarizes medians and interquartile ranges. Numerical force treatment differences and confidence intervals are not tabulated; no plots were digitized. Sodium overload is a plausible explanation, but no sodium-matched arm separates it causally from ketone load or other formulation effects. Doses below 150 were untested, so “maximally effective” and a precise universal toxic threshold are not established.

## Transparency, lineage and transfer

Funding: Flemish Methusalem, Research Foundation Flanders and ERC; authors report no funder role and no competing interests. Baxter supplied the named nutrition product but is **not listed as a funder in this paper**. Raw datasets are available on reasonable request and were not obtained. Fresh PubMed, Europe PMC and Crossref records and publisher HTML revealed no linked correction/retraction; this is a bounded notice check, not universal absence proof.

The study cites the earlier salt-force result as confirmed here. Shared laboratory/model/ethics context does not prove independent animals or reuse. The confirmed 2019-to-2021 cholesterol force reuse remains separate lineage context. This experiment supplies no BUB1B/BUBR1 or MVA evidence. Its injected sodium-salt results do not establish effects of ketogenic foods, oral retail products, other cations, D-only materials, or esters.

Complete scientific main and reference list were read; all seven native main figures and the supplementary microglia figure were visually inspected; the complete supplementary gene table was extracted/read. Exact source URLs, SHA-256 bindings, counts and read depth are in `qualification.json`, `source-manifest.json` and `reading-scope.json`.
