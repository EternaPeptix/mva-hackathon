# BCAA PMID 8818199: abstract-level mixture and training qualification

The complete original indexed abstract does not establish an extra BCAA functional benefit. VO2max increased about 5% in both treatment and control groups (P<.01); this shared training response is not a compound treatment contrast. Additional capillary adaptation was absent. Preserve exact-mixture context without isolated-leucine efficacy attribution.

[Freyssenet et al. 1996](https://doi.org/10.1076/apab.104.2.157.12879) included 17 older men (age 63±5 years), nine receiving oral leucine 16 g/day, isoleucine 2 g/day and valine 2 g/day, and eight placebo recipients for six weeks. This is 20 g/day BCAA at an 8:1:1 mass ratio. Both arms trained one hour/day, four days/week on Monark cycles at 75±9% maximal heart rate. Randomization is not stated in the abstract; indexing alone is not a complete allocation or blinding read.

Capillaries per fiber and contacting type I fibers increased in both groups (P<.05), similarly. Types I/IIa/IIb distributions and areas remained unchanged and did not differ between groups. Abstract authors conclude the mixture did not further enhance training-induced histomorphometric changes. Between-arm VO2 effect estimates/tests are unavailable, so this is not a fully quantified endurance-null analysis. Morphology does not establish useful tissue renewal or chromosome fidelity.

Original main, native outcomes, supplement, own registry, protocol/SAP, attrition, AE counts and exact hierarchy remain UNKNOWN. Europe PMC lists no PMCID/OA main. Publisher DOI/PDF returned 403 and exact-DOI HAL search returned zero results. No full qualification or safety proof follows. Mixture results cannot be attributed to leucine alone or imported into existing pure-leucine trials.

Exact target is absent from existing decisions/qualification reports and already appears in B11 screening/discovery: zero collection-screen increment, no ledger admission. Retain preparation/training-specific counterevidence/context. No positive-function nomination or head-to-head superiority over niacin, NMN or apitegromab follows. Structured audit and exact source byte/SHA-256 bindings are separate.
