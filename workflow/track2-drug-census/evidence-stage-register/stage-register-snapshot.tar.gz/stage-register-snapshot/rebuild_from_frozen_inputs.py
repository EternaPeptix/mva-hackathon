"""Rebuild in a NEW destination using frozen metadata only; never overwrite.

No scientific body reappraisal, new source fetch, catalogue join or ledger change.
Raw-pointer byte rechecks in the QA are separate from the frozen rebuild itself.
"""
import pathlib,json,hashlib,shutil,subprocess,os,sys,argparse,datetime
B=pathlib.Path(__file__).resolve().parent
ap=argparse.ArgumentParser();ap.add_argument('--destination',required=True);ap.add_argument('--receipt');ap.add_argument('--cleanup-under-owned-root',action='store_true');args=ap.parse_args()
T=pathlib.Path(args.destination).resolve();assert not T.exists(),f'Destination must not exist: {T}'
if args.cleanup_under_owned_root:
 assert T.parent==B and T.name=='reproduction-scratch','Cleanup restricted to fresh owned reproduction-scratch'
 assert args.receipt,'Cleanup requires an explicit receipt path outside scratch'
T.mkdir();shutil.copytree(B/'frozen-inputs',T/'frozen-inputs')
for n in ['input-snapshot-bindings.json','additional-needed-catalogue-input-binding.json','explicit-linked-document-capture.json']:
 shutil.copyfile(B/n,T/n)
# Graph nodes retain immutable original frozen-copy paths at B. These are the
# captured individual metadata inputs, not live foreign reports or directories.
env=dict(os.environ);env['MVA_STAGE_REGISTER_ROOT']=str(T);outputs=[]
for n in ['build_existing_stage_register.py','augment_identity_fields_and_limits.py','complete_catalogue_projection_and_write_final_tsv.py']:
 r=subprocess.run([sys.executable,str(B/n)],env=env,capture_output=True,text=True);outputs.append({'script':n,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,r.stderr
r=subprocess.run([sys.executable,str(B/'verify_mechanical_register.py'),'--check-only'],env=env,capture_output=True,text=True)
outputs.append({'script':'verify_mechanical_register.py --check-only','exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==0,r.stdout+r.stderr
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
checks=[]
for n in ['source-evidence-stage-register.json','reported-reading-depth-claims-verbatim.json','existing-stage-statements-and-fields-verbatim.json',
 'explicit-preparation-contrast-fields-verbatim.json','historical-partial-access-and-mixed-depth-index.json','ledger-explicit-audit-pointer-binding-checks.json',
 'bounded-stage-denominators.json','uncapped-explicit-gaps.json','mechanical-method-and-scope.json']:
 a=json.loads((B/n).read_text());b=json.loads((T/n).read_text());a.pop('utc',None);b.pop('utc',None)
 checks.append({'file':n,'semantic_equality_except_generated_top_level_utc':a==b,
   'original_sha256':sha(B/n),'rebuilt_sha256':sha(T/n)})
for n in ['source-evidence-stage-register-decisions.tsv','source-evidence-stage-register-sources.tsv','source-evidence-stage-register-components.tsv']:
 checks.append({'file':n,'byte_identical':(B/n).read_bytes()==(T/n).read_bytes(),'original_sha256':sha(B/n),'rebuilt_sha256':sha(T/n)})
passed=all(x.get('semantic_equality_except_generated_top_level_utc',x.get('byte_identical')) for x in checks)
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS' if passed else 'FAIL',
 'frozen_only_rebuild_destination':str(T),'commands':outputs,'comparisons':checks,
 'foreign_report_or_scientific_body_reading_during_rebuild':False,'new_credit_all_layers':0,
 'raw_pointer_QA_only_checks_bytes_not_reading':True,'cleanup_derived_scratch_requested':args.cleanup_under_owned_root}
q=pathlib.Path(args.receipt).resolve() if args.receipt else T/'rebuild-verification.json'
assert not q.exists(),q
if args.cleanup_under_owned_root:assert T not in q.parents,'Receipt must survive scratch cleanup'
q.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
if passed and args.cleanup_under_owned_root:
 shutil.rmtree(T) # only fresh generated copies/results; all original inputs stay.
print(json.dumps({'status':result['status'],'comparisons':len(checks),'QA_exit_code':r.returncode,'derived_scratch_cleaned':passed and args.cleanup_under_owned_root}))
assert passed,'Preserve failed scratch and result for diagnosis'
