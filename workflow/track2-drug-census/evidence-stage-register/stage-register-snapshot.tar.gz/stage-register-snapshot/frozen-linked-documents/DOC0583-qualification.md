# Lamb 2019: tart-cherry concentrate counterevidence

**Retain as preparation-specific, controlled functional counterevidence.** This randomized parallel trial found no statistically detectable improvement in recovery of measured elbow-flexion strength after a damaging exercise bout. The result meaningfully qualifies broad claims about tart-cherry recovery products. It does not establish equivalence, rule out smaller benefits, or directly refute Connolly's different 2006 cherry–apple blend. [Lamb et al., 2019](https://pmc.ncbi.nlm.nih.gov/articles/PMC6683053/), PMID 31337122, DOI 10.3390/nu11071593.

**Preparation and exposure.** The tart-cherry drink was **30 mL CherryActive concentrate plus 220 mL water**, with maltodextrin added to match the energy of 250 mL undiluted POM Wonderful pomegranate juice. The placebo was an energy-matched blackcurrant-flavored maltodextrin sports drink, Science in Sport Energy Go. The tart-cherry intervention Methods do not explicitly identify cultivar, batch, source-fruit composition or an apple component; the CherryActive brand alone cannot verify a particular Montmorency lot or generic retail equivalence.

Methods specify one 250 mL serving morning and evening for nine days, plus an additional 250 mL immediately after exercise on day 5. The abstract's awkward “2 × 250 mL … twice daily” should not be read as four routine servings. These are source-regimen descriptions, not advice. Participants also received a standardized post-exercise meal providing 0.3 g protein/kg body weight; both chicken and vegetarian options were offered.

Three bottles per juice, each assayed in triplicate, yielded the following per-serving composition:

| Preparation | Total phenolics, gallic-acid equivalents | Monomeric anthocyanins, cyanidin-3-glucoside equivalents |
|---|---:|---:|
| CherryActive drink | 294.7 ± 14.9 mg | 7.7 ± 0.3 mg |
| POM Wonderful | 878.9 ± 92.7 mg | 49.4 ± 2.0 mg |
| Connolly 2006 Cherrypharm blend, as reported in frozen appraisal | At least 600 mg | At least 40 mg |

The 2006 preparation was freshly made from frozen Montmorency cherries **blended with apple juice in an undisclosed ratio**, served in 12 fl oz bottles. Thus this is not an exact-product replication. Different measured composition could contribute to different outcomes, but no dose-response or composition-mediation experiment establishes that explanation. Higher phenolic content in the separate pomegranate arm also failed to produce detectable benefit here; phenolic quantity alone cannot be assumed to predict efficacy.

**Design and denominators.** Thirty-six non-resistance-trained men were randomized, 12 per arm, and all completed the study. Eligibility was age 18–65, nonsmoking, injury-free and no upper-body strength training for three months; actual median age was 24 years (IQR 22–33). Computer-generated blocks of three and six were ordered by a researcher outside recruitment. A separate technician prepared drinks in brown bottles; participants were told different fruit-flavored drinks were being compared. The study reports double blinding, but no masking-success assessment or explicit allocation-concealment mechanism beyond these procedures.

A low-effort familiarization preceded the trial. On day 5, after four days of supplementation and the morning drink, participants performed **50 maximal eccentric contractions of the nondominant elbow flexors** on a Biodex dynamometer. Recovery was measured before exercise, immediately afterward and at 24, 48, 72 and 96 hours. This was parallel, so crossover sequence, washout and treatment carryover do not apply. Familiarization was intentionally low effort to limit a repeated-bout effect; it was not tested for biological inertness.

All 36 completed, but endpoint analyses were smaller. One placebo participant missed 72-hour measurements owing to illness; technical problems removed one 48-hour pomegranate CK value and one 72-hour strength value in each active group. Native figure captions report **strength n=11 per arm; soreness/ROM n=12 cherry, 12 pomegranate, 11 placebo; CK n=12, 11, 11**, respectively. Imputation is not reported. All drinks were reportedly consumed, although two participants took both servings in the evening on one day. Polyphenol-rich food intake persisted despite avoidance instructions, with no detected group difference.

**Functional result and nulls.** Strength was the mean of five three-second maximal voluntary isometric contractions at 90°. Analysis used each participant's percentage of the day-5 pre-exercise value, not an absolute force treatment effect. Table 1 prints baseline strength in N·cm⁻² without explaining area normalization; that unit should not be silently corrected or treated as a validated specific-force assay. No endurance test or chronic muscle-strength endpoint was measured.

| Outcome | Cherry / pomegranate / placebo summary | Actual three-group tests |
|---|---|---|
| Mean post-exercise strength decrement | 14.6% / 19.4% / 17.3% | Group F(2,30)=0.27, P=.77; group×time F(5.7,85.5)=0.33, P=.91 |
| Mean soreness increase | 17.2 / 17.4 / 11.7 mm | Group P=.32; interaction P=.10 |
| Mean ROM reduction | 4.6% / 6.1% / 3.5% | Group P=.31; interaction P=.71 |
| Mean CK increase | 478.3 / 502.9 / 471.6 U/L | Group P=.995; interaction P=.93, as printed |

The arithmetic cherry–placebo difference is **2.7 percentage points less average strength loss**. It has no published pairwise confidence interval or cherry-versus-placebo P value; the omnibus tests must not be relabeled as pairwise tests. The exercise challenge was effective: pooled strength reached a 26.8% decrement at 24 hours. This null is therefore not explained simply by absence of a measurable strength deficit. Conversely, small groups and absent treatment-effect CIs prevent an equivalence/no-benefit conclusion.

Six CK hyper-responders, two per arm, were retained in the main analyses. A separately labeled exploratory analysis excluding them remained nonsignificant: strength group P=.78, interaction P=.97. Endpoint-specific reduced sample sizes are not supplied and cannot automatically be called ten per arm given the other missing observations. The protocol used mixed ANOVAs, Greenhouse–Geisser corrections where needed and Bonferroni comparisons for time effects. A single prospectively verified primary endpoint, sample-size calculation, across-outcome correction and public protocol were not supplied. A bounded ClinicalTrials.gov cherry/pomegranate query returned no records; registration under other terms or registries remains unknown.

**Safety, transparency and competitive meaning.** The paper supplies no systematic adverse-event/tolerability counts; the missed visit was attributed to illness without treatment attribution. It was funded by Sheffield Hallam University and the University of Sheffield. A.L. disclosed a separate Cherry Marketing Institute grant for a gout study, on which K.L.L. worked. This is not documented industry funding of the present trial, but the relationship must remain visible.

The parallel design avoids the cross-limb/period concern in Connolly's small crossover and uses a comparable healthy, untrained elbow-flexor challenge. Different formulation, assayed composition, eccentric workload, baseline timing and cointerventions limit direct product comparison. Retain the 2006 blend's positive functional signal with these counterdata; neither paper ranks chronic benefit against niacin or apitegromab, establishes MVA treatment, or assays BUB1B/BUBR1. Lack of a BUBR1 assay does not erase the useful functional measurements. No general all-cherry or all-polyphenol claim follows.

**Reading boundary.** Complete official main text, both published tables and all five native figures/captions were read; no scientific supplement link or raw dataset was located in the main. Publisher PDF access returned 403, so no PDF-reading credit is claimed. Current PubMed/Crossref records show no correction/retraction relation; this is a bounded notice check. The 2006 comparison uses the frozen source-qualified packet, without reopening its primary appraisal. Exact source, context and depth hashes are recorded with this packet. No repository or earlier-packet edits were made.
