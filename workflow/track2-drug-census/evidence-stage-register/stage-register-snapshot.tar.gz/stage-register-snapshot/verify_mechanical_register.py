"""Fresh read-only verification; --check-only never writes or changes a ledger."""
import pathlib,json,csv,hashlib,re,datetime,collections,os,sys
O=pathlib.Path(os.environ.get('MVA_STAGE_REGISTER_ROOT','/Users/jeweled/mva-hackathon/track2-drug-census-work/global-existing-evidence-stage-register-20261005'))
def j(p):return json.loads(pathlib.Path(p).read_text())
cache={}
def sha(p):
 p=str(p)
 if p not in cache:cache[p]=hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
 return cache[p]
def rows(p):
 with pathlib.Path(p).open() as f:return list(csv.DictReader(f,delimiter='\t'))
def pointer(v,p):
 for k in p.strip('/').split('/') if p else []:
  k=k.replace('~1','/').replace('~0','~');v=v[int(k)] if isinstance(v,list) else v[k]
 return v
checks=[]
def c(k,b):checks.append({'check':k,'pass':bool(b)})
reg=j(O/'source-evidence-stage-register.json');g=j(O/'explicit-linked-document-capture.json');docs={d['document_id']:d for d in g['documents']}
inputs=j(O/'input-snapshot-bindings.json');ledger=j(O/'frozen-inputs/repository/decisions.json')['decisions']
for x in inputs['frozen_files']:
 c('input-copy-hash:'+x['copy'],sha(x['copy'])==x['sha256']);c('input-copy-bytes:'+x['copy'],pathlib.Path(x['copy']).stat().st_size==x['bytes'])
x=j(O/'additional-needed-catalogue-input-binding.json');c('additional475 input hash',sha(x['copy'])==x['sha256'])
c('captured authoritative309',len(ledger)==reg['decision_count']==309)
c('all309completeobjectsverbatim',[r['original_decision_verbatim'] for r in reg['records']]==ledger)
c('capturedHEADpreserved',reg['captured_repository_HEAD']==inputs['HEAD_start'])
c('ledgerhashpreserved',reg['ledger_snapshot_sha256']==sha(O/'frozen-inputs/repository/decisions.json'))
ar={r['decision_id']:r for r in rows(O/'frozen-inputs/repository/decision-alias-joins.tsv')}
ap=rows(O/'frozen-inputs/repository/catalog-appraisals.tsv');cat=rows(O/'frozen-inputs/repository/catalog.tsv');uv=rows(O/'frozen-inputs/repository/drugcentral-status-unverified.tsv')
catby={r['catalog_id']:r for r in cat};uvby={r['drugcentral_id']:r for r in uv};apby=collections.defaultdict(list)
for r in ap:
 for did in json.loads(r['decision_ids']):apby[did].append(r)
c('309originalprojectionrows',len(ar)==309);c('14882maincatalogrows',len(cat)==14882);c('475separateunverifiedrows',len(uv)==475);c('15357appraisalprojectionrows',len(ap)==15357)
for i,r in enumerate(reg['records']):
 d=ledger[i];did=d['decision_id'];cj=r['catalogue_presence_and_join']
 c('complete-order:'+did,r['decision_id']==did and r['decision_ordinal_zero_based']==i)
 c('originaldecisioncanonicalhash:'+did,r['original_object_canonical_sha256']==hashlib.sha256(json.dumps(d,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest())
 c('aliasrowunchanged:'+did,cj['original_alias_projection_row_verbatim']==ar[did])
 c('appraisalrowsunchanged:'+did,cj['appraisal_projection_rows_verbatim']==apby[did])
 c('maincatalogrowsunchanged:'+did,cj['catalogue_rows_at_reported_ids_verbatim']==[catby[x] for x in json.loads(ar[did]['catalog_ids']) if x in catby])
 c('reportedledgerlabelsunchanged:'+did,r['existing_ledger_labels_verbatim']=={k:d[k] for k in ['route','disposition','evidence_scope','bub1b_variant_efficacy','rationale']})
 c('no-new-join:'+did,cj['no_new_join_performed'] and cj['main_and_status_unverified_layers_kept_separate'])
 for s in cj['separate_status_unverified_source_rows_by_reported_projection_id']:
  c('unverifiedsource-rowexact:'+did+':'+s['reported_projection_catalog_id'],s['source_row_verbatim']==uvby[s['original_source_drugcentral_id']])
 c('stage-labelsnotinferred:'+did,all(s['label']=='UNKNOWN_NOT_INFERRED_FROM_RATIONALE_OR_TITLE' for s in r['stage_specific_labels'].values()))
 c('zero-source-credit:'+did,r['source_reading_credit_from_audit']==0)

parsed={};texts={}
for d in g['documents']:
 p=pathlib.Path(d['frozen_copy']);c('linked947docbytehash:'+d['document_id'],sha(p)==d['sha256'] and p.stat().st_size==d['bytes'])
 c('linked947capturestable:'+d['document_id'],d['stable_during_capture'] and d['byte_capture_verified'])
 text=p.read_text(errors='replace');texts[d['document_id']]=text
 if p.suffix=='.json':
  try:parsed[d['document_id']]=json.loads(text)
  except Exception:pass
 elif p.suffix=='.jsonl':
  try:parsed[d['document_id']]=[json.loads(l) for l in text.split('\n') if l]
  except Exception:pass
depth=j(O/'reported-reading-depth-claims-verbatim.json')['claims'];dm={x['reported_claim_id']:x for x in depth}
for x in depth:
 if x['kind']=='REPORT_LINE':
  loc=x['literal_character_locator'];lit=texts[x['document_id']][loc['character_start']:loc['character_end']]
  c('depth-verbatim-line:'+x['reported_claim_id'],lit==x['field_or_line_verbatim'])
 else:c('depth-verbatim-JSONfield:'+x['reported_claim_id'],pointer(parsed[x['document_id']],x['locator'])==x['field_or_line_verbatim'])
 c('depth-sourcehash:'+x['reported_claim_id'],x['frozen_document_sha256']==docs[x['document_id']]['sha256'])
 c('depth-no-comprehension-upgrade:'+x['reported_claim_id'],not x['independently_validated_comprehension'] and x['no_new_source_reading_or_efficacy_credit'])
stage=j(O/'existing-stage-statements-and-fields-verbatim.json')
for x in stage['structured_fields']:c('stagefieldverbatim:'+x['stage_field_id'],pointer(parsed[x['document_id']],x['JSON_pointer'])==x['value_verbatim'])
for x in stage['report_topic_statements']:
 l=x['locator'];c('stagestatementverbatim:'+x['statement_id'],texts[x['document_id']][l['character_start']:l['character_end']]==x['literal'])
preps=j(O/'explicit-preparation-contrast-fields-verbatim.json')['fields'];pm={x['field_id']:x for x in preps}
for x in preps:c('prepcontrastfieldverbatim:'+x['field_id'],pointer(parsed[x['document_id']],x['JSON_pointer'])==x['value_verbatim'])
c('noexplicitcontrastIDsinvented',not any(x['field_name_verbatim'].endswith('_id') for x in preps))
soc=reg['source_preparation_contrast_identifier_occurrences'];sources={x['source_occurrence_id']:x for x in soc};cr=reg['component_rows']
expected_urls=[(d['decision_id'],k,i,u) for d in ledger for k in ['source_urls','additional_source_urls'] for i,u in enumerate(d.get(k,[]))]
c('all874sourceoccurrencesexact',[(x['decision_id'],x['ledger_source_field'],x['ordinal_in_original_field'],x['source_URL_verbatim']) for x in soc]==expected_urls)
c('8740componentrows',len(cr)==8740==reg['component_row_count'])
c('every sourceoccurrence10components',all(n==10 for n in collections.Counter(x['source_occurrence_id'] for x in cr).values()))
for x in soc:
 c('sourcecontrastnotinvented:'+x['source_occurrence_id'],x['contrast_id']=='UNKNOWN_UNSTRUCTURED_OR_NOT_EXPLICITLY_SCOPED' and x['study_family_id']=='UNKNOWN_IDENTIFIER_EDGE_IS_NOT_COHORT_EQUIVALENCE')
 c('sourceclaimsrefsvalid:'+x['source_occurrence_id'],all(i in dm for i in x['reported_claim_ids_with_explicit_identifier_context']))
 c('sourcepreprefsvalid:'+x['source_occurrence_id'],all(i in pm for i in x['explicit_preparation_contrast_field_ids_with_identifier_context']))
for x in cr:
 s=sources[x['source_occurrence_id']]
 c('componentidentitypreserved:'+x['component_row_id'],x['source_URL_verbatim']==s['source_URL_verbatim'] and x['preparation_route_verbatim']==s['preparation_route_verbatim'] and x['decision_id']==s['decision_id'])
 c('componentnoactualreadingupgrade:'+x['component_row_id'],not x['actual_reading_validated_by_this_audit'] and x['full_primary_depth_completion']=='UNKNOWN' and x['new_credit']==0)
 c('componentdepthclaimsvalid:'+x['component_row_id'],all(i in dm and x['component'] in dm[i]['component_mentions_not_reading_inferences'] for i in x['reported_claim_ids']))
 c('componentreadingUNKNOWNwhenmissing:'+x['component_row_id'],bool(x['reported_claim_ids']) or x['reported_component_depth'].startswith('UNKNOWN'))
 c('componentbytesseparatefrombodyequivalence:'+x['component_row_id'],x['exact_source_body_equivalence']=='UNKNOWN_NOT_INFERRED_FROM_SHARED_DOI_REGISTRY_NAME_OR_DIRECTORY')

# Rehash only explicit byte pointers, with caching for repeated edges. Capture
# records remain historical even if a foreign file has subsequently changed.
rawrechecks=[]
for i,e in enumerate(g['edges']):
 if 'independent_byte_identity' not in e:continue
 p=pathlib.Path(e['path']);b=e['independent_byte_identity'];exists=p.is_file()
 match=exists and p.stat().st_size==b['bytes'] and sha(p)==b['sha256']
 rawrechecks.append({'edge_index':i,'path':str(p),'captured_byte_binding_verbatim':b,'currently_exists':exists,
  'fresh_matches_captured_bytes':match,'actual_source_reading':False,'source_body_equivalence':'UNKNOWN'})
 c('explicitrawbytepointer:'+str(i),match)
for e in j(O/'ledger-explicit-audit-pointer-binding-checks.json')['checks']:
 c('explicitledgerexpectedbinding:'+str(e['edge_index']),e['expected_sha256_matches_captured'] and e['expected_bytes_matches_captured'])

dt=rows(O/'source-evidence-stage-register-decisions.tsv');st=rows(O/'source-evidence-stage-register-sources.tsv');ct=rows(O/'source-evidence-stage-register-components.tsv')
c('decisionTSV309rows',len(dt)==309);c('sourceTSV874rows',len(st)==874);c('componentTSV8740rows',len(ct)==8740)
for a,b in zip(dt,reg['records']):
 c('decisionTSVverbatim:'+b['decision_id'],json.loads(a['original_decision_verbatim_json'])==b['original_decision_verbatim'])
 c('decisionTSVlabels:'+b['decision_id'],json.loads(a['existing_ledger_labels_verbatim_json'])==b['existing_ledger_labels_verbatim'])
 c('decisionTSVcatalog:'+b['decision_id'],json.loads(a['catalogue_presence_and_join_json'])==b['catalogue_presence_and_join'])
 c('decisionTSVstages:'+b['decision_id'],json.loads(a['stage_specific_labels_json'])==b['stage_specific_labels'])
def roundtrip(r,o):
 for k,v in o.items():
  got=json.loads(r[k]) if isinstance(v,(list,dict)) else (r[k]=='True' if isinstance(v,bool) else int(r[k]) if isinstance(v,int) else r[k])
  if got!=v:return False
 return True
for a,b in zip(st,soc):c('sourceTSVcomplete-roundtrip:'+b['source_occurrence_id'],roundtrip(a,b))
for a,b in zip(ct,cr):c('componentTSVcomplete-roundtrip:'+b['component_row_id'],roundtrip(a,b))
den=j(O/'bounded-stage-denominators.json')
c('denominatorunitsbounded',den['full_main_qualified_source_denominator']=='UNKNOWN' and den['actual_scientific_reads_validated_by_mechanical_audit']==0)
c('decisionjoin-counts',den['decision_join_status_counts']==dict(collections.Counter(r['catalogue_presence_and_join']['join_status_verbatim'] for r in reg['records'])))
c('projectionjoin-counts',den['catalogue_appraisal_join_state_counts']==dict(collections.Counter(r['appraisal_join_status'] for r in ap)))
c('main+unverifiednonchemicalcounts',den['catalogue_main_plus_unverified_projection_rows']==len(cat)+len(uv)==len(ap))
c('874_URL_edges_not_sources',reg['source_URL_occurrence_count']==len(expected_urls))
c('uncappedallclaims',len(depth)==j(O/'reported-reading-depth-claims-verbatim.json')['reported_claim_count'])
c('uncappedallgapobjects',len(j(O/'uncapped-explicit-gaps.json')['gaps'])==j(O/'uncapped-explicit-gaps.json')['gap_object_count'])
c('allzero new credits',reg['all_new_chemical_alias_trial_source_reading_efficacy_nominee_credits']==0)
q03=pathlib.Path('/Users/jeweled/mva-hackathon/track2-drug-census-work/common-acquired-frontier-fourth-primary-independent-20261005/final-bindings.json')
c('Q03final unchanged',sha(q03)=='5a613492d3cc5cbd122301a02cf497fc5aa04f69b28430687aad2ca1119aae35')
status='PASS' if all(x['pass'] for x in checks) else 'FAIL'
result={'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':status,'check_count':len(checks),
 'checks':checks,'raw_explicit_pointer_rechecks':rawrechecks,'raw_pointer_check_count':len(rawrechecks),
 'all_original309objects_preserved':True,'source_reading_or_comprehension_credit':0,'repo_or_foreign_edits':0,
 'reported_vs_independently_byte_verified_vs_UNKNOWN_separate':True}
if '--check-only' not in sys.argv:
 p=O/'mechanical-qa.json';assert not p.exists(),p;p.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':status,'checks':len(checks),'raw_pointer_fresh_rechecks':len(rawrechecks),'failed':[x['check'] for x in checks if not x['pass']]}))
if status!='PASS':raise SystemExit(1)
