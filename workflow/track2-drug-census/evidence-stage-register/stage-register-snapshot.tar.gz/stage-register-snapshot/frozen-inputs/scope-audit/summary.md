# Scope audit summary

The fixed repository has 14,882 main source entities plus 475 unverified rows, broader food/supplement/consumer/research overlays, and 2,120 accepted eligibility screens from 56,217 exact outcome records. B17 remains pending with zero accepted increment at HEAD`4ca09e9b8d34a868c41e9f952c06f3d725c6c242`. Catalogue and screen counts do not establish complete worldwide inventory or per-compound efficacy/competitiveness.

The 15,357-row appraisal projection has 115 exact joins, 25 ambiguous and 15,217 unknown; current 309 decision objects are not 309 unique compounds or full-primary reads. CPDat two-kind identifier union is 8,468 with 1,634 overlap; other overlay denominators remain separate. Historical joins use 282/289/300 comparator objects and need additive refresh against current 309.

Next evidence work is to freeze source/jurisdiction/acquisition-class coverage, harvest complete primary product registers, resolve identity/form/mixture ambiguities, broaden neutral class-based retrieval beyond the three-query corpus, and build linked depth/restoration/function/competitiveness stages. Comparable absolute function plus preserved renewal/chromosome fidelity requires source-specific evidence; no compound is newly ranked.

All 42 input copies, 30 metric checks and 79 frontier hash-only entries passed. The report retains 17 scope findings and 9 dependency-ordered, unexecuted actions. Raw documentation diagnostics and limited browser verification are explicit. No foreign mutation or new scientific reading, screening, admission, ledger, alias, trial, compound or nominee credit.

[Full report](/Users/jeweled/mva-hackathon/track2-drug-census-work/global-inventory-and-common-scope-audit-20261005/report.md) · [Uncapped gaps](/Users/jeweled/mva-hackathon/track2-drug-census-work/global-inventory-and-common-scope-audit-20261005/coverage-gap-table.json) · [Actions](/Users/jeweled/mva-hackathon/track2-drug-census-work/global-inventory-and-common-scope-audit-20261005/next-evidence-actions.json) · [Provenance](/Users/jeweled/mva-hackathon/track2-drug-census-work/global-inventory-and-common-scope-audit-20261005/scope-and-provenance.json)
