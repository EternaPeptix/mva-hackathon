"""Capture ONLY named stable inputs in a new directory; no repository writes.

The delivered historical capture is already bound. This script is provided for
reproducible future captures and never overwrites that package.
"""
import pathlib,json,hashlib,subprocess,datetime,argparse,shutil
ap=argparse.ArgumentParser();ap.add_argument('--destination',required=True);ap.add_argument('--expected-decisions',type=int,default=309);a=ap.parse_args()
R=pathlib.Path('/Users/jeweled/Documents/Codex/2026-09-18/co/work/mva-pr2-hmb-integration-20260928')
A=pathlib.Path('/Users/jeweled/mva-hackathon/track2-drug-census-work/global-inventory-and-common-scope-audit-20261005')
T=pathlib.Path(a.destination).resolve();assert not T.exists(),'Capture destination must not exist'
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
assert sha(A/'final-bindings.json')=='b1cc3d7791d1819791b2ae7f5aa4bb9f789723fba713e531e36d3c6dddd447f6'
assert len(json.loads((R/'workflow/track2-drug-census/decisions.json').read_text())['decisions'])==a.expected_decisions,'Live ledger count differs from requested captured scope'
h0=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();s0=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)
(T/'frozen-inputs/repository').mkdir(parents=True);(T/'frozen-inputs/scope-audit').mkdir();out=[]
for name in ['decisions.json','catalog.tsv','catalog-appraisals.tsv','decision-alias-joins.tsv','coverage.json','provenance.json','drugcentral-status-unverified.tsv']:
 p=R/'workflow/track2-drug-census'/name;q=T/'frozen-inputs/repository'/name;before=sha(p);shutil.copyfile(p,q);after=sha(p)
 assert before==after==sha(q),'Source changed during capture; retain draft and retry in a fresh directory'
 out.append({'original':str(p),'copy':str(q),'bytes':q.stat().st_size,'sha256':sha(q),'stable_during_capture':True})
for name in ['final-bindings.json','final-verification.json','report.md','summary.md','proposed-evidence-stage-register-schema.json','coverage-gap-table.json','next-evidence-actions.json','scope-and-provenance.json','source-index.json']:
 p=A/name;q=T/'frozen-inputs/scope-audit'/name;shutil.copyfile(p,q);assert sha(p)==sha(q)
 out.append({'original':str(p),'copy':str(q),'bytes':q.stat().st_size,'sha256':sha(q),'byte_identical':True})
h1=subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip();s1=subprocess.check_output(['git','status','--porcelain'],cwd=R,text=True)
uv=next(x for x in out if x['original'].endswith('/drugcentral-status-unverified.tsv'))
(T/'additional-needed-catalogue-input-binding.json').write_text(json.dumps({**uv,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'HEAD_start':h0,'HEAD_end':h1,'reason':'Named separate status-unverified catalogue source; original projection identifier representation only, no chemical join'},indent=2)+'\n')
(T/'input-snapshot-bindings.json').write_text(json.dumps({'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'HEAD_start':h0,'HEAD_end':h1,
 'HEAD_stable':h0==h1,'status_start':s0,'status_end':s1,'frozen_files':out,'expected_decisions':a.expected_decisions,
 'only_named_needed_inputs':True,'growing_screen_directories_bound':False,'scientific_reappraisal_or_reading_credit':0,'repo_mutation':0},indent=2)+'\n')
assert h0==h1,'HEAD changed during capture; fixed files retained, snapshot not declared same-HEAD'
print(json.dumps({'status':'CAPTURED_STABLE_NAMED_INPUTS','HEAD':h0,'decisions':a.expected_decisions,'files':len(out)}))
