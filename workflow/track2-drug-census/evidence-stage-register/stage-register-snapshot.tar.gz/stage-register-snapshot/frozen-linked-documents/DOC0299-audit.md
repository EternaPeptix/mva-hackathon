# Independent menaquinone audit, 4 October 2026

The current extension's main disposition is supported: MK-4 supplies a defined-product, fixed-oocyte morphology signal; MK-7 supplies conditional worm function/lifespan signals. Neither is established BUB1B/MVA therapy. The neonatal vitamin K2 preparation remains unidentified and must remain separate.

This reviewer made no repository/ledger edits, contacted no one, and submitted nothing. All findings below are source-specific; no treatment is recommended.

## Material changes to the extension

1. **Narrow the 10 µM worm harm statement.** Native Figure 1C marks body bending at 10 µM versus control **ns**, despite the Results' broad locomotion statement. Head beating (1D), pumping (1E), total brood (1H), and lifespan worsen at 10 µM. The 5 µM body-bending, head-beating and pumping benefits are supported. Body length is nonpositive at all three concentrations; egg counts at 1/5 µM are nonpositive.
2. **Add the native timing conflict.** Methods 2.2 describes daily exposure from egg stage to adulthood, then transfer to fresh medium; Results 3.1 describes ten-day exposure before lifespan assessment. Native Figure 1A depicts a treatment bar beginning at L3 and ending at Day 14, followed by experiments. Other endpoint Methods describe L4 plus ten days. Do not choose a settled schedule or translate these concentrations into an oral human regimen.
3. **Preserve the MediQ7 formulation denominator.** Methods states purified MK-7 >96% purity, subsequently added to MCT oil at 50,000 mg/kg. Native Table 14 describes the tested yellowish oil as **53,157 mg/kg MK-7**, approximately 5.3157% by weight. These two source values are distinct. The nominal preparation doses cannot automatically become pure-active MK-7 doses.
4. **Keep genotoxicity conclusions author-reported.** The already-noted Table 13 problems are real; additional native table/count/caption inconsistencies are detailed below. These do not establish genotoxic harm, but prevent treating all printed findings as independently verified data.

## MK-4: Zheng 2026

[Primary PMC main](https://pmc.ncbi.nlm.nih.gov/articles/PMC13429177/), [DOI](https://doi.org/10.1002/mrd.70141).

Methods 5.1–5.3 specifies 6–8-week female CB6F1 mice, superovulation, and MCE **HY-B2156** MK-4. The injection is 10 mg/kg intraperitoneally, 100 µL per mouse, in 10% DMSO/90% corn oil, with a volume-matched vehicle. Methods places injection at 0 h post-hCG and collection at 24 h; fresh oocytes are collected at 14 h. Results 2.1 agrees with concurrent hCG treatment. Figure 1's caption instead says MK-4 treatment after 24 h priming. Figure 5 refers back to the same priming/time phases. Retain the disagreement and preventive context. Product purity and lot were not supplied in the reviewed main.

Native Figure 5 supports lower fragmentation and fewer abnormal chromosome alignments, spindles, and MTOCs. The paper reports fragmentation decreasing from approximately 10% to 5%; treated fragmentation remains above the fresh arm (**). Fixed spindle/alignment/MTOC comparisons versus fresh are marked ns, which does not prove equivalence. Methods 5.5 fixes oocytes for immunofluorescence. No completed chromosome segregation, chromosome-number count, checkpoint rescue, BUB1B/BUBR1 measurement, muscle output, or actual fertilization/embryo-development/live-birth outcome was measured in the reviewed main. The caption's word “developmental” does not add such an assay.

The separate in vitro arm treats oocytes collected at 14 h with 5 µM MK-4 for ten hours. Native Figure 7J–M uses a DMSO comparator and supports changes in MDA, Sirt1 and SOD1 protein readouts. It does not inherit Figure 5's in vivo spindle result. Marker changes do not independently demonstrate ferritinophagy/mitophagy flux or causal FSP1/VKORC1L1 mediation. Useful nulls include GPX4, IRP1/2, 4-HNE and Prx2. The study has no broad dose-response or oral human exposure comparison, and no fresh-plus-MK-4 safety arm.

**Read depth:** complete scientific main from abstract through Methods 5.10; all seven main captions and native figures. No supplement, raw measurements, blinded rescoring or biological replication. Asset filenames are not figure numbers: **Figure 5 is g001**, Figure 1 is g005, Figure 4 is g007, and Figure 7 is g002; the explicit mapping is saved in `mk4-figure-map.json`.

## MK-7: Guo 2026 worm study

[Primary PMC main](https://pmc.ncbi.nlm.nih.gov/articles/PMC13135748/), [DOI](https://doi.org/10.1111/acel.70530).

Methods 2.21 identifies Sungen Bioscience (Shantou, China) **MK-7 water-soluble powder, 99.63% purity**. Catalog/lot and the water-solubilizing formulation are unreported. The comparator is M9 buffer. Lifespan assays use three independent experiments with at least 50 worms per group; Figure 1 reports n=150 per arm. Functional Methods generally use at least 30 worms per group, with repeated experiments specified unevenly. These are nominal culture concentrations, not verified tissue or human exposures.

Retain the 5 µM measured function benefits and the endpoint-specific 10 µM harms described above. The Results reports survival HR 0.7534 (95% CI 0.5995–0.9469) at 5 µM and HR 1.724 (1.363–2.180) at 10 µM. The 1 µM prose claims lifespan extension, but its reported HR 0.8106 (0.6456–1.018) crosses 1; Figure 1B has no individual pairwise significance labels. Do not promote 1 µM as an independently secure lifespan benefit or function benefit.

The recovered supplement adds another text/figure distinction: **S1B/C marks 10 µM-versus-control ROS and ATP ns**, despite Results 3.1 claiming increased ROS/reduced ATP. Its 5 µM ROS and ATP contrasts are positive. Preserve the 10 µM measured survival/motor/reproductive harms without importing significant oxidative/ATP changes that the native panels do not support. S1 includes mitochondrial morphology/roundness observations; these are separate from chromosome fidelity.

Mechanistic conditionality matters. Lifespan/stress benefits are lost in mev-1, jnk-1, sir-2.1 and daf-16 mutant contexts. The skn-1 strain has a reported adverse lifespan HR 1.260 (1.004–1.583); this is a genotype-specific observation, not proof of general toxicity at 5 µM. Native Figure 4V shows lower mitochondrial membrane potential in daf-16 mutants at 5 µM (**). Supplemental Figure S2's ns baseline movement/pumping/brood/length comparisons do not establish equal drug absorption. The Discussion identifies **SIR-2.1 as a mammalian SIRT1 homolog**. It cannot inherit the separate mammalian SIRT2-to-BUBR1 evidence chain. No BUB1B/BUBR1, mitotic fidelity, chromosome number, MVA genotype or mammalian muscle-force assay is supplied.

**Read depth:** complete Methods 2.1–2.22, Results 3.1–3.4, Discussion and Conclusions; Introduction from PMC; all four scientific main figures/captions. Complete supporting DOCX text/captions and both original embedded figures S1/S2 visually inspected after PNG format conversion. No raw data or independent experiments.

## MK-7: MediQ7 toxicology study

[Primary publisher main](https://www.nature.com/articles/s41598-024-56151-w), [primary PDF](https://www.nature.com/articles/s41598-024-56151-w.pdf), [DOI](https://doi.org/10.1038/s41598-024-56151-w).

The source is GF Fermentech **MediQ7**, fermented from Bacillus subtilis var. natto and purified. Table 14 gives an all-E systematic name, CAS 2124-57-4, and MCT carrier. This formulation differs from the worm powder. The ingredient purity and finished-oil active content are different denominators.

Authors report no induced bacterial reverse mutation, no significant increase in structural/numerical chromosome aberrations in Chinese hamster lung cells, and no increase in mouse marrow micronuclei under the tested conditions. These are genotoxicity tests with separate positive controls, **without a damaged-cell-plus-MK-7 rescue arm**. In vitro metaphase scoring and mouse marrow outcomes are not MVA checkpoint rescue. The cell test's maximum concentrations were limited by precipitation: 250 µg/mL for short exposures and 125 µg/mL for continuous exposure. The main micronucleus assay is male-only, five mice per group, nominal oral doses 500/1,000/2,000 mg/kg preparation, alongside water, MCT and 1 mg/kg intraperitoneal MMC controls.

Native problems must not be repaired by inference:

- **Table 13, page 15:** all MK-7 and MMC doses are printed 0, conflicting with Methods and Tables 11/12. Animal 1302 has MNPCE **30**, but its group's mean/SD is **0.8/1.30**. Vehicle counts **0,0,0,2,0** also do not reproduce the printed mean/SD **1/0.60**. An apparent digit error must not be silently replaced by 3, and nominal doses should be attributed to Methods/Table 11/12 rather than Table 13.
- **Table 9, page 12:** in the −S9/6 h section, MK-7 250 µg/mL has gap-positive aberrations 0.7% but “total normal cell” 225; MMC has 25.0% but 300 normal cells. These columns are inconsistent with the simple counts they purport to summarize. Do not repair them or reconstruct significance.
- **Table 10, page 13:** the caption claims structural abnormalities in positive controls, but the table body contains Poly/Endo numerical counts for all groups. It labels the no-S9 positive comparators B[a]P where Table 9 labels MMC. Retain the mismatch.

The author-reported NOAEL is 4,500 mg/kg/day **of this preparation**. It is not unrestricted human or pediatric safety. Methods on native page 16 reports temporary diarrhea at 5,000 mg/kg test article, despite the abstract/acute Results' “no toxic effects” wording. Other observations were judged nonadverse by the authors, including increased prothrombin time in high-dose female recovery rats. No causal adverse attribution is asserted here.

The only grip-strength statement is a male low-dose increase **versus the negative control**, without dose response. A significant comparison with the MCT vehicle and a numerical efficacy effect estimate are unverified; the study was designed for toxicology. It does not establish muscle rescue, and negative genotoxicity findings do not strengthen an efficacy claim.

**Read depth:** targeted complete relevant identity/formulation, acute/repeated-toxicity function findings, chromosome-aberration/micronucleus Methods/Results and Discussion; native PDF pages 12–16 and 18 in full. Remaining main tables were not all independently rescored; Supplementary Table S1 and raw data were not read. This is not a whole-paper quantitative replication.

## Competitive interpretation

The current repository shortlist was read; its incumbent primary sources were not independently re-audited in this task. On that existing evidence portfolio, NMN has a more direct administered-compound-to-WT-BUBR1 finding; niacin has a human muscle NAD-engagement exposure precedent; apitegromab has randomized SMA motor-function evidence for compensation. None establishes MVA rescue, and these evidence types do not prove one compound clinically superior in MVA.

MK-4 remains a morphology/fidelity-adjacent laboratory comparison with unmeasured completed fidelity. MK-7 remains a conditional worm functional comparator with formulation, schedule and dose-dependent limitations. No source here supports replacement of the niacin/NMN restoration experiments or the apitegromab compensation role. The neonatal K2 subtype, regimen and supplier remain unknown; this audit did not recheck its original native assets and does not identify them by family-name similarity.

## Provenance and access

`audit.json` contains source URLs, SHA-256 hashes, read depth and claim-level findings. `sources/retrieval-manifest.json`, `asset-manifest.json`, and supplement manifests preserve the observed retrieval outcomes. MK-4 EuropePMC XML returned 500, but its complete scientific PMC HTML and native CDN figures were accessible via ordinary requests. Web-tool PMC visits intermittently returned a browser check; those responses were not treated as scientific mains.

The worm supplement's direct PMC path returned 404 and its official instance path returned HTML instead of DOCX. The official EuropePMC `supplementaryFiles` endpoint then supplied a valid ZIP containing the original DOCX and native assets. ZIP SHA-256: `8c5a2c836634fe27a81627e75047fecf195f880b4cdda8ff5b4747dc2f298670`; original DOCX SHA-256: `978f90b422664d03fe956b87f1e089ce5d14c2172017f0e7b0ef600c948bfd70`. The publisher genotoxicity PDF was valid and inspectable. No access controls were bypassed, and no numerical effect was reconstructed from pixels.
