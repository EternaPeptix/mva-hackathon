import pathlib,json,csv,re,datetime,os
O=pathlib.Path(os.environ.get('MVA_STAGE_REGISTER_ROOT','/Users/jeweled/mva-hackathon/track2-drug-census-work/global-existing-evidence-stage-register-20261005'))
reg=json.loads((O/'source-evidence-stage-register.json').read_text())
with (O/'frozen-inputs/repository/drugcentral-status-unverified.tsv').open() as f:unverified=list(csv.DictReader(f,delimiter='\t'))
ub={r['drugcentral_id']:r for r in unverified};corrected=[]
for d in reg['records']:
 cat=d['catalogue_presence_and_join'];ids=json.loads(cat['original_alias_projection_row_verbatim']['catalog_ids'])
 lookups=[];still=[]
 old=cat.get('reported_ids_without_main_catalogue_row',cat['reported_ids_without_catalogue_row'])
 for cid in old:
  m=re.fullmatch(r'DC(\d+)',cid)
  if m and m.group(1) in ub:lookups.append({'reported_projection_catalog_id':cid,'original_source_drugcentral_id':m.group(1),
   'source_row_verbatim':ub[m.group(1)],'source_layer':'SEPARATE_STATUS_UNVERIFIED',
   'lookup_rule':'Original DC-prefixed projection key to exact DrugCentral integer source ID; identifier representation only, no name/chemical/alias join'})
  else:still.append(cid)
 cat['reported_ids_without_main_catalogue_row']=old
 cat['separate_status_unverified_source_rows_by_reported_projection_id']=lookups
 cat['reported_ids_without_catalogue_row']=still
 cat['main_and_status_unverified_layers_kept_separate']=True
 if lookups:corrected.append({'decision_id':d['decision_id'],'initial_missing_main_only_ids':old,
   'separate_original_unverified_ids_located':[x['reported_projection_catalog_id'] for x in lookups],
   'new_chemical_or_alias_join':False,'original_alias_projection_unchanged':True})
reg['catalogue_status_unverified_input']='additional-needed-catalogue-input-binding.json'
# Canonicalize derived reference lists only. Original decision fields, alias rows,
# source pointer order, body fields and historical declarations are unchanged.
for r in reg['records']:
 for k in ['reported_depth_claim_ids_at_document_scope','explicit_preparation_contrast_field_ids_at_document_scope']:
  r[k]=sorted(r[k])
 for x in r['stage_specific_labels'].values():
  x['linked_structured_field_ids']=sorted(x['linked_structured_field_ids']);x['linked_report_statement_ids']=sorted(x['linked_report_statement_ids'])
for r in reg['source_preparation_contrast_identifier_occurrences']:
 r['reported_claim_ids_with_explicit_identifier_context']=sorted(r['reported_claim_ids_with_explicit_identifier_context'])
 r['structured_stage_field_ids_with_explicit_identifier_context']=sorted(r['structured_stage_field_ids_with_explicit_identifier_context'])
for r in reg['component_rows']:
 r['reported_claim_ids']=sorted(r['reported_claim_ids']);r['reported_claim_classifications']=sorted(r['reported_claim_classifications'])
 r['independently_byte_checked_pointer_edge_indices']=sorted(r['independently_byte_checked_pointer_edge_indices'])
(O/'source-evidence-stage-register.json').write_text(json.dumps(reg,ensure_ascii=False,indent=2)+'\n')
den=json.loads((O/'bounded-stage-denominators.json').read_text());den['catalogue_separate_status_unverified_rows']=len(unverified)
den['catalogue_main_plus_unverified_projection_rows']=den['catalogue_main_rows']+len(unverified)
den['catalogue_appraisal_join_state_counts']=dict(__import__('collections').Counter())
with (O/'frozen-inputs/repository/catalog-appraisals.tsv').open() as f:
 app=list(csv.DictReader(f,delimiter='\t'))
den['catalogue_appraisal_join_state_counts']=dict(__import__('collections').Counter(r['appraisal_join_status'] for r in app))
(O/'bounded-stage-denominators.json').write_text(json.dumps(den,ensure_ascii=False,indent=2)+'\n')

def write(n,keys,rows):
 with (O/n).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys,delimiter='\t');w.writeheader()
  for r in rows:w.writerow({k:json.dumps(v,ensure_ascii=False,separators=(',',':')) if isinstance(v,(dict,list)) else v for k,v in r.items()})
dr=[]
for r in reg['records']:
 dr.append({'decision_id':r['decision_id'],'decision_ordinal_zero_based':r['decision_ordinal_zero_based'],
  'reported_route':r['preparation_identity']['reported_route_verbatim'],
  'join_status_verbatim':r['catalogue_presence_and_join']['join_status_verbatim'],
  'source_occurrence_count':len(r['source_occurrence_ids']),
  'original_decision_verbatim_json':r['original_decision_verbatim'],
  'existing_ledger_labels_verbatim_json':r['existing_ledger_labels_verbatim'],
  'catalogue_presence_and_join_json':r['catalogue_presence_and_join'],
  'stage_specific_labels_json':r['stage_specific_labels'],'report_pointer_edges_json':r['report_pointer_edges'],
  'reported_depth_claim_ids_at_document_scope_json':r['reported_depth_claim_ids_at_document_scope'],
  'explicit_preparation_contrast_field_ids_at_document_scope_json':r['explicit_preparation_contrast_field_ids_at_document_scope'],
  'source_occurrence_ids_json':r['source_occurrence_ids']})
write('source-evidence-stage-register-decisions.tsv',list(dr[0]),dr)
write('source-evidence-stage-register-sources.tsv',list(reg['source_preparation_contrast_identifier_occurrences'][0]),reg['source_preparation_contrast_identifier_occurrences'])
write('source-evidence-stage-register-components.tsv',list(reg['component_rows'][0]),reg['component_rows'])
(O/'final-projection-generation-and-catalogue-layer-note.json').write_text(json.dumps({
 'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'decision_TSV_rows':len(dr),
 'source_TSV_rows':len(reg['source_preparation_contrast_identifier_occurrences']),
 'component_TSV_rows':len(reg['component_rows']),'all_final_TSVs_generated_from_final_register':True,
 'separate_unverified_catalogue_lookup_notes':corrected,
 'original309_decisions_original_projection_and_all_foreign_files_unchanged':True,
 'no_new_join_alias_or_admission':True,'contrast_IDs_remain_UNKNOWN_unless_explicit':True},ensure_ascii=False,indent=2)+'\n')
print(json.dumps({'status':'FINAL_PROJECTIONS_WRITTEN','decisions':len(dr),'source_rows':reg['source_URL_occurrence_count'],
 'component_rows':reg['component_row_count'],'unverified_catalogue_rows':len(unverified),'separate_unverified_lookups':len(corrected)}))
