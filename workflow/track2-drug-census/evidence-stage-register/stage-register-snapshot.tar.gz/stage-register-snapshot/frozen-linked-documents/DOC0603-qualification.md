# Machin 2014: pomegranate concentrate and post-exercise strength

**Retain a preparation-specific controlled functional research reserve.** Machin et al. report higher average post-exercise knee-extensor and elbow-flexor strength with both tested pomegranate-juice-concentrate schedules than with placebo. These are main treatment effects in baseline-relative strength; treatment-by-time interactions were nonsignificant. The paper does not establish a faster recovery trajectory, dose equivalence, a minimum effective dose, chronic benefit or MVA superiority. [Original publisher main](https://onlinelibrary.wiley.com/doi/10.1155/2014/271959), [original seven-page PDF](https://onlinelibrary.wiley.com/doi/pdf/10.1155/2014/271959), DOI **10.1155/2014/271959**.

## Source identity and actual reading depth

The exact paper is “Effects of Differing Dosages of Pomegranate Juice Supplementation after Eccentric Exercise,” Daniel R. Machin and six coauthors, *Physiology Journal*, 2014, article 271959. It was received 24 July, accepted 16 September and published 29 September 2014. The original PDF identifies a Creative Commons Attribution license; Crossref specifies CC BY 3.0. Author and DOI identity agree with the retained Lamb 2019 reference 31 and UT Austin laboratory profile.

The complete scientific main, Methods 2.1–2.9, Results, Discussion, conflicts/funding and **all six figure captions** were read through the publisher HTML/PDF web reader. Complete text witnesses are retained externally. Ordinary local requests to the old Hindawi downloads and Wiley main/PDF yielded 403 HTML, not a usable local PDF. Publisher figure-export clicks failed. PDF screenshot calls returned only reference strings through the available tool interface, without visible image pixels. The bounded publisher-provided ResearchGate route exposed the same main/captions but its figure routes failed or rate-limited. Thus **no native figure-pixel inspection or digitization is claimed**. No scientific supplement or participant dataset was exposed in the checked primary page. These limits do not erase the original full-text results or impose an extra admission requirement on this challenger.

## Design, preparation and denominator limits

The reported study recruited **45** healthy, nonsmoking, non-resistance-trained, recreationally active young men (mean age 22.3 ± 4.1 years). It is a double-blind randomized **parallel** study with one eight-day period, not a crossover. After three days of strength-test familiarization, men were assigned to three groups. The article does not give per-arm sample sizes, random sequence generation, allocation concealment, masking-success assessment, a screening/participant-flow diagram or recruitment dates. **Do not infer 15 per arm.** The strength and soreness captions give total n=45; the authors state all participants completed the 40 elbow-exercise repetitions. Neither statement provides a complete endpoint-by-time missingness account or an intention-to-treat analysis plan.

| Schedule | Morning drink | Evening drink | Source-reported daily polyphenols |
|---|---|---|---:|
| 1x | 30 mL pomegranate juice concentrate, diluted with water | 30 mL placebo concentrate, diluted with water | 650 mg gallic-acid equivalents (GAE) |
| 2x | 30 mL active concentrate, diluted with water | Same active serving | 1,300 mg GAE |
| PLA | 30 mL placebo concentrate, diluted with water | Same placebo serving | 0 mg GAE |

All groups took **two drinks daily**, about twelve hours apart. The active source was Wonderful-variety California pomegranates, POM Wonderful Inc., LLP, supplied in 500-mL concentrate bottles. Each active serving is reported to contain 650 mg GAE with a polyphenol profile of 95.5% ellagitannins, 3.5% ellagic acid and 1% anthocyanins. Both active and placebo servings contained **24 g carbohydrate**, with added color/flavor for masking. The final dilution volume, lot/catalogue number, placebo ingredients beyond this description, independent batch assay and profile-measurement method are not supplied. GAE is an assay-equivalent quantity, not a dose of pure gallic acid or a demonstrated active constituent. No retail equivalence or interchangeability with POMx extract, ordinary juice or urolithin A is established.

On **day 4**, after supplementation had already begun, blood, strength and soreness baseline measurements preceded exercise. The challenge combined 20 minutes of downhill running (4 km, −10% grade) with 40 bilateral eccentric elbow-flexion repetitions. Assessments followed at 2, 24, 48, 72 and 96 hours. This post-supplementation/pre-exercise baseline differs from a pre-supplementation baseline. Results were the peak of three bilateral isometric tests at 65° knee flexion or 45° elbow flexion, expressed as each participant's percentage of baseline. No absolute-force treatment estimate is published. Anti-inflammatory, antioxidant and multivitamin supplements were stopped one week before and throughout testing; participants were reminded to take drinks, returned in a similar postprandial state and avoided caffeine. Quantified adherence and dietary control beyond these statements are not reported.

## Direct functional results

Numbers below are **reported means ± SD averaged over the post-exercise observation period**, not single-day results or treatment-effect intervals. The source does not fully specify how the reported SD combines participant/time variation.

| Outcome | 1x | 2x | PLA | What was actually tested/reported |
|---|---:|---:|---:|---|
| Knee-extensor strength, % of day-4 baseline | 93.9 ± 6.1 | 91.6 ± 5.6 | 87.1 ± 7.9 | Three-group treatment effect P<.05; text and Figure 2 caption report each active group higher than PLA, P<.05. |
| Elbow-flexor strength, % of day-4 baseline | 83.6 ± 10.4 | 85.6 ± 7.2 | 78.4 ± 6.7 | Three-group treatment effect P<.05; text and Figure 4 caption report each active group higher than PLA, P<.05. |
| Knee soreness, 0–10 | 2.3 ± 1.3 | 2.3 ± 1.1 | 2.3 ± 1.4 | No detected group difference, P>.05. |
| Elbow soreness, 0–10 | 3.0 ± 1.5 | 2.9 ± 1.1 | 2.9 ± 1.2 | No detected group difference, P>.05. |
| Serum myoglobin, ng/mL; reduced total n=39 | 79 ± 56 | 53 ± 27 | 56 ± 22 | No detected group difference, P>.05 after outlier exclusion. |

Simple subtraction of reported means gives **+6.8 and +4.5 percentage points** for 1x/2x versus placebo in knee strength, and **+5.2 and +7.2 points** in elbow strength. These descriptive differences are not absolute-force gains, relative percentage improvements, model-derived effect estimates or confidence intervals. No interval is reconstructed from the SDs or an assumed arm n.

The article reports time effects and strength below baseline at every post-exercise measurement, including 96 hours. It explicitly reports **no significant treatment-by-time interaction for any measured variable**. Accordingly, the defensible finding is higher average baseline-relative strength during the post-exercise period. The main effect does not independently demonstrate that the groups' recovery slopes differ or that every individual time point has a significant active–placebo contrast. Figures 2/4 captions explicitly label their symbols as main treatment effects; no time-point pairwise P values are supplied.

Myoglobin results exclude people with values described as four times the group mean at any time point, reducing n from 45 to 39: **six excluded**, by subtraction. Per-arm exclusions, exact threshold implementation, prespecification, reasons for extreme values, and an all-participant sensitivity analysis are not supplied. This is an endpoint-specific exclusion, not evidence that six people left the whole trial. Strength and soreness remain captioned n=45. A myoglobin null after exclusion is not proof of absent structural injury; the paper supplies no tissue assay confirming structural protection.

## Dose inference and statistical reporting

Methods specify two-way ANOVA for treatment, time and interaction, alpha <.05, SPSS, and mean ± SD. They do not name the pairwise procedure, state a multiplicity adjustment across groups/outcomes/time, report exact strength P values or F/df, provide a power calculation, or identify prospective registration/protocol/SAP and an endpoint-testing hierarchy. Those details remain **unreported**, rather than being silently assumed corrected or uncorrected. The statement of a primary purpose in the paper is not proof of a prospectively registered statistical hierarchy. The repeated-measure covariance/sphericity treatment and analysis-population definitions are not described.

The discussion reports **no statistically significant difference between 1x and 2x** for either strength measure. It gives no exact dose-comparison P, CI, equivalence margin or equivalence/noninferiority test. The direction even differs descriptively: 1x minus 2x is +2.3 percentage points for knee strength but −2.0 for elbow strength. Two tested doses with an undetected difference cannot establish equivalence, a plateau, equal potency or a 650-mg threshold. The paper's suggestion that half the prior dose may be sufficient is an author interpretation; it is not adopted as a minimum effective dose or clinical regimen.

## Safety, funding, cohort boundaries and earlier studies

No systematic adverse-event/tolerability counts or ascertainment plan are reported. Health-related exclusions and completion of exercise do not establish safety, including pediatric, renal, cancer-context or long-term safety. POM Wonderful funded the study by grant; the authors state the company did not have final approval over paper content. The authors also declare no conflicts. Both disclosures should remain visible; sponsor independence is not inferred.

This is a separately described 45-person parallel study, not the previously qualified nine-day POMx crossover or the 36-person Sheffield Lamb trial. It shares investigator/laboratory lineage with Trombold/Coyle and commercial source context; it is **not an independent-laboratory replication of POMx**. Individual participant overlap with earlier UT work cannot be audited without identifiers/recruitment dates. The different design/sample supports treating it as a distinct reported study, not claiming proven participant-level independence or duplicating either earlier cohort's reading credit.

- **POMx 2010 remains original-abstract-only.** Its reported elbow-strength advantages at 48/72 hours are preserved. This 2014 paper's retrospective statements about earlier doses do not fill the original 2010 formulation, denominator, baseline, masking or analysis gaps. Concentrate and extract are not aliases; no pooled effect is computed.
- **Lamb 2019 remains full-source counterevidence.** It tested undiluted POM Wonderful juice in a separate three-arm parallel trial and found no detected group/interaction strength effect. Its strength n=11 per arm, omnibus tests, missingness and measured chemistry remain as previously qualified. It is not an exact-concentrate replication, and the shared brand does not establish formulation equivalence. No phenolic-dose explanation is inferred across trials.

The study adds controlled actual-function evidence beyond biomarkers. That deserves compensation-oriented comparison with niacin's uncontrolled functional observation under the same source standards, while healthy-adult short-term recovery does not establish larger clinical benefit than either niacin or apitegromab. No BUB1B/BUBR1 result, actual-allele rescue, MVA treatment, chronic weakness benefit or nominee replacement is established.

## Notices and disposition

The current exact Crossref record has no `update-to` or relation entry; no correction/retraction banner appears in the checked publisher main, and the exact-DOI notice query returned no identified exact-paper notice. This is a bounded notice check, not a guarantee of no notice anywhere. Europe PMC's exact DOI query returned zero records; that result does not prove absence from every archive. No scientific supplement link was exposed on the primary page; no raw data were obtained.

The packet is ready for independent source review. Root decides any ledger action after review; no candidate ID, alias, count or repository change is made here. Raw sources and tool text witnesses remain external. No new biological experiment, statistical replay/test, broad pomegranate search campaign, contact, purchase or access bypass occurred. Prior frozen packets were read in place and left unchanged.
