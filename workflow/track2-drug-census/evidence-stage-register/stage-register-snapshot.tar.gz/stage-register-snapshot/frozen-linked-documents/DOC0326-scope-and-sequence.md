# Independent source-first QA scope

Prior-context disclosure: Parent task supplied the study identity, source directory, frozen parent final-bindings SHA, relevant PDF pages and artifacts to compare, and warned of printed 31/314, 262/263, and 364%/415 percentage-point inconsistencies and statistical synergy overinterpretation. These are hypotheses to check against the originals, not independent discoveries. I have not read the parent report, qualification, anchor ledger, or numerical audit before starting original-source reading.

Ownership: This directory only. No source parent, root package, repository, selection trees, ledger, screen counts, trial credits or outcome entries are edited.

Sequence: Copy originals and hash; independently extract and read full main source in bounded output; visually inspect original native pages 5-8; independently write scientific-first findings; then read all parent report/JSON/94 anchors; record uncapped corrections and mechanical binding checks separately.
