"""Mechanical existing-label/depth register. No outcome appraisal or new joins."""
import pathlib,json,csv,re,hashlib,datetime,collections,urllib.parse,os
O=pathlib.Path(os.environ.get('MVA_STAGE_REGISTER_ROOT','/Users/jeweled/mva-hackathon/track2-drug-census-work/global-existing-evidence-stage-register-20261005'))
R=pathlib.Path('/Users/jeweled/Documents/Codex/2026-09-18/co/work/mva-pr2-hmb-integration-20260928')
def j(p):return json.loads(pathlib.Path(p).read_text())
def sha(p):return hashlib.sha256(pathlib.Path(p).read_bytes()).hexdigest()
def save(n,d):
 p=O/n;assert not p.exists(),p;p.write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
def table(n):
 with (O/'frozen-inputs/repository'/n).open() as f:return list(csv.DictReader(f,delimiter='\t'))
def ptr(k):return str(k).replace('~','~0').replace('/','~1')
g=j(O/'explicit-linked-document-capture.json');docs={d['document_id']:d for d in g['documents']}
docbyoriginal={d['original_path']:d['document_id'] for d in g['documents']}
def tokens(s):
 s=urllib.parse.unquote(str(s));out=set()
 for x in re.findall(r'10\.\d{4,9}/[^\s<>"\]\)`,;]+',s,re.I):out.add('DOI:'+x.rstrip('.').casefold())
 for x in re.findall(r'\bPMC\d+\b',s,re.I):out.add(x.upper())
 for x in re.findall(r'(?:pubmed\.ncbi\.nlm\.nih\.gov/|(?:PMID|MED)\s*[: ]?)(\d{5,9})',s,re.I):out.add('PMID:'+x)
 for x in re.findall(r'\b(?:NCT\d{8}|UMIN\d{9}|RBR-[A-Za-z0-9]+|ISRCTN\d+|KCT\d+)\b',s,re.I):out.add(x.upper())
 for x in re.findall(r'https?://[^\s<>"\]`)]+',s,re.I):out.add('URL:'+x.rstrip('.,;').casefold())
 return out
identitykey=re.compile(r'^(?:source(?:_id|_ids|_url|_urls|_record_id|_identity|_metadata)?|selected(?:_source|_identity)?|pmid|pmcid|doi|url|urls|registry|study_id|record_id|identity)$',re.I)
depthkey=re.compile(r'(read|depth|scope|component|retriev|available|access|supplement|protocol|registry|histor|notice|version|full.?text|native|main)',re.I)
stagepatterns={
 'restoration':re.compile(r'restor|BUBR1.?repair|BUB1B.?rescue',re.I),
 'RNA':re.compile(r'\bRNA\b|transcript',re.I),
 'protein':re.compile(r'\bprotein\b|BUBR1.?abundance',re.I),
 'checkpoint':re.compile(r'checkpoint|\bSAC\b',re.I),
 'chromosome_fidelity':re.compile(r'fidelity|euploid|aneuploid|segregation',re.I),
 'function':re.compile(r'function|force|strength|torque|walking|Wingate|physical.?task',re.I),
 'compensation':re.compile(r'compensat|downstream',re.I)}
components={
 'saved_abstract':re.compile(r'abstract',re.I),
 'main':re.compile(r'\bmain\b|whole.?paper|full.?text|scientific.?narrative|whole.?source',re.I),
 'native_PDF_pages':re.compile(r'native.{0,30}(?:pdf|page)|(?:pdf|page).{0,30}native',re.I),
 'native_tables':re.compile(r'\btable[s]?\b|table_cell',re.I),
 'native_figures':re.compile(r'\bfigure[s]?\b|\bpanel[s]?\b',re.I),
 'supplement':re.compile(r'supplement|supporting.?information',re.I),
 'protocol_SAP':re.compile(r'protocol|\bSAP\b|statistical.?analysis.?plan',re.I),
 'current_registry':re.compile(r'current.{0,30}registr|registr.{0,30}current|UMIN|ReBEC|CRIS|ClinicalTrials',re.I),
 'registry_history':re.compile(r'\bhistor|old.{0,12}version|version.?1.?3|amendment',re.I),
 'notice':re.compile(r'notice|correction|erratum|retract',re.I)}
claims=[];stagefields=[];statements=[];doc_tokens={};doc_components={}
edge_by_json={(e.get('parent_document_id'),e.get('JSON_pointer')):e for e in g['edges'] if e.get('JSON_pointer')}
def appendclaim(d,loc,value,context,kind,readingkey,scopelevel):
 text=json.dumps(value,ensure_ascii=False) if not isinstance(value,str) else value
 mentioned=[k for k,p in components.items() if p.search(loc+' '+text)]
 if not mentioned and not depthkey.search(loc+' '+text):return None
 cid=f'RC{len(claims)+1:06d}'
 # Classification describes only the reported field, never validated reading.
 reading='REPORTED_DEPTH_OR_SCOPE_VERBATIM_NOT_VALIDATED'
 if isinstance(value,bool) and re.search(r'read',readingkey,re.I):reading='REPORTED_READ_BOOLEAN_TRUE' if value else 'REPORTED_READ_BOOLEAN_FALSE'
 elif re.search(r'actual.*read|actually.*read|complete.*read|read.*complete|whole.*read',readingkey+' '+text,re.I):reading='REPORTED_READING_STATEMENT_VERBATIM'
 if re.search(r'hash.*only|metadata.?only|not.*read|unread|partial|abstract.?only|403|inaccess|blocked|unknown',text,re.I):reading+='__LIMIT_OR_NEGATIVE_OR_MIXED_SCOPE_PRESENT'
 claims.append({'reported_claim_id':cid,'document_id':d['document_id'],'original_document_path':d['original_path'],
  'frozen_document_sha256':d['sha256'],'locator':loc,'field_or_line_verbatim':value,
  'reading_classification':reading,'component_mentions_not_reading_inferences':mentioned,
  'explicit_source_context_verbatim':context,'source_identity_tokens':sorted(tokens(json.dumps(context,ensure_ascii=False))),
  'source_scope_level':scopelevel,'kind':kind,'independently_validated_comprehension':False,
  'no_new_source_reading_or_efficacy_credit':True})
 return claims[-1]

for d in g['documents']:
 p=pathlib.Path(d['frozen_copy']);text=p.read_text(errors='replace');doc_tokens[d['document_id']]=tokens(text)
 if p.suffix=='.md':
  offset=0
  for i,line in enumerate(text.split('\n')):
   loc={'line_number_one_based':i+1,'character_start':offset,'character_end':offset+len(line)}
   if re.search(r'read|depth|scope|retriev|supplement|protocol|registry|histor|notice|partial|403|inaccess|blocked',line,re.I):
    appended=appendclaim(d,'line:'+str(i+1),line,{'same_line_explicit_identifiers_only':sorted(tokens(line))},'REPORT_LINE',line,'SAME_LINE_IDENTIFIER_EDGE_OR_REPORT_SCOPE_ONLY')
    if appended is not None:appended['literal_character_locator']=loc
   st=[k for k,patt in stagepatterns.items() if patt.search(line)]
   if st:statements.append({'statement_id':f'RS{len(statements)+1:06d}','document_id':d['document_id'],
    'locator':loc,'literal':line,'stage_topic_mentions_not_labels':st,'source_identity_tokens':sorted(tokens(line)),
    'scientific_label_assignment':'UNKNOWN_NOT_INFERRED_FROM_TOPIC_WORDING'})
   offset+=len(line)+1
 else:
  try:obj=json.loads(text) if p.suffix=='.json' else [json.loads(l) for l in text.split('\n') if l]
  except Exception:continue
  def walk(v,path='',context=None):
   context=context or {};local=dict(context)
   if isinstance(v,dict):
    direct={k:x for k,x in v.items() if identitykey.fullmatch(k) and isinstance(x,(str,int,list,dict))}
    if direct:local={'direct_identity_fields':direct,'parent_explicit_identity_context':context}
    for key,x in v.items():
     pp=path+'/'+ptr(key)
     if depthkey.search(key) and not isinstance(x,(list,dict)):
      appendclaim(d,pp,x,local,'STRUCTURED_FIELD',key,'NEAREST_EXPLICIT_STRUCTURED_IDENTITY_CONTEXT' if direct or context else 'DOCUMENT_SCOPE_UNASSIGNED')
     # Retain explicit structured stage-label fields without interpreting values.
     st=[s for s,pat in stagepatterns.items() if pat.search(key)]
     if st and not isinstance(x,(list,dict)):
      stagefields.append({'stage_field_id':f'SF{len(stagefields)+1:06d}','document_id':d['document_id'],
       'JSON_pointer':pp,'field_name_verbatim':key,'value_verbatim':x,'stage_topic_mentions_not_validated_labels':st,
       'source_identity_tokens':sorted(tokens(json.dumps(local,ensure_ascii=False))),
       'explicit_source_context_verbatim':local,'label_validation':'NOT_REAPPRAISED'})
     walk(x,pp,local)
   elif isinstance(v,list):
    for i,x in enumerate(v):walk(x,path+'/'+str(i),local)
  walk(obj)

save('reported-reading-depth-claims-verbatim.json',{'status':'UNCAPPED_MECHANICAL_FIELD_CAPTURE_NOT_READING_VALIDATION',
 'reported_claim_count':len(claims),'claims':claims,'source_scope_rules':'Explicit structured identity context is an identifier edge, not trial/cohort/body equivalence. Report-only scope remains unassigned.',
 'new_scientific_source_reads':0,'independently_validated_comprehension':False})
save('existing-stage-statements-and-fields-verbatim.json',{'structured_fields':stagefields,'report_topic_statements':statements,
 'structured_count':len(stagefields),'statement_count':len(statements),'topic_words_not_labels_or_efficacy':True,
 'all_original_decision_labels_preserved_separately':True,'stage_specific_UNKNOWN_when_not_explicit':True})

# Directed reachability is tied to exact original ledger pointers; identifier
# matching below is an index edge only, and never joins chemicals/cohorts.
adj=collections.defaultdict(set)
for e in g['edges']:
 if e.get('parent_document_id') and e.get('document_id'):adj[e['parent_document_id']].add(e['document_id'])
roots=collections.defaultdict(set);root_records=collections.defaultdict(list)
for e in g['edges']:
 if e.get('decision_id'):
  root_records[e['decision_id']].append(e)
  if e.get('document_id'):roots[e['decision_id']].add(e['document_id'])
def reachable(start):
 q=list(start);out=set()
 while q:
  x=q.pop()
  if x in out:continue
  out.add(x);q.extend(adj[x]-out)
 return out
claims_by_doc=collections.defaultdict(list);stages_by_doc=collections.defaultdict(list);statements_by_doc=collections.defaultdict(list)
for x in claims:claims_by_doc[x['document_id']].append(x)
for x in stagefields:stages_by_doc[x['document_id']].append(x)
for x in statements:statements_by_doc[x['document_id']].append(x)
raw_by_doc=collections.defaultdict(list)
for i,e in enumerate(g['edges']):
 e['edge_index']=i
 if e.get('parent_document_id') and 'independent_byte_identity' in e:raw_by_doc[e['parent_document_id']].append(e)

ds=j(O/'frozen-inputs/repository/decisions.json')['decisions'];aliasrows=table('decision-alias-joins.tsv');aliasby={r['decision_id']:r for r in aliasrows}
catalog=table('catalog.tsv');catby={r['catalog_id']:r for r in catalog}
appraisals=table('catalog-appraisals.tsv');appbydecision=collections.defaultdict(list)
for r in appraisals:
 for did in json.loads(r['decision_ids']):appbydecision[did].append(r)
records=[];componentrows=[];sourceoccurrences=[]
for ordinal,d in enumerate(ds):
 did=d['decision_id'];reach=reachable(roots[did]);ar=aliasby.get(did);catids=json.loads(ar['catalog_ids']) if ar else []
 linkedclaims=[x for doc in sorted(reach) for x in claims_by_doc[doc]]
 linkedfields=[x for doc in sorted(reach) for x in stages_by_doc[doc]]
 linkedstatements=[x for doc in sorted(reach) for x in statements_by_doc[doc]]
 rec={'decision_ordinal_zero_based':ordinal,'decision_id':did,'original_decision_verbatim':d,
  'original_object_canonical_sha256':hashlib.sha256(json.dumps(d,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest(),
  'unit':'Existing decision object, not a unique drug/preparation/trial or independently read primary',
  'preparation_identity':{'reported_route_verbatim':d['route'],'match_aliases_verbatim':d['match_aliases'],
    'chemical_preparation_equivalence':'UNKNOWN_NOT_RESOLVED_BY_THIS_AUDIT','contrast_identity':'UNKNOWN_UNLESS_EXPLICIT_LINKED_FIELD'},
  'catalogue_presence_and_join':{'original_alias_projection_row_verbatim':ar,
    'catalogue_rows_at_reported_ids_verbatim':[catby[cid] for cid in catids if cid in catby],
    'reported_ids_without_catalogue_row':[cid for cid in catids if cid not in catby],
    'appraisal_projection_rows_verbatim':appbydecision[did],
    'join_status_verbatim':ar['join_status'] if ar else 'UNKNOWN_NO_ALIAS_PROJECTION_ROW','no_new_join_performed':True},
  'report_pointer_edges':root_records[did],'explicit_reachable_document_ids':sorted(reach),
  'reported_depth_claim_ids_at_document_scope':[x['reported_claim_id'] for x in linkedclaims],
  'existing_ledger_labels_verbatim':{k:d[k] for k in ['route','disposition','evidence_scope','bub1b_variant_efficacy','rationale']},
  'stage_specific_labels':{s:{'label':'UNKNOWN_NOT_INFERRED_FROM_RATIONALE_OR_TITLE',
     'linked_structured_field_ids':[x['stage_field_id'] for x in linkedfields if s in x['stage_topic_mentions_not_validated_labels']],
     'linked_report_statement_ids':[x['statement_id'] for x in linkedstatements if s in x['stage_topic_mentions_not_labels']],
     'scope':'Existing verbatim fields/statements retained at document scope; no stage-specific assay validation or efficacy inference'} for s in stagepatterns},
  'source_occurrence_ids':[],'source_reading_credit_from_audit':0}
 urls=[('source_urls',i,u) for i,u in enumerate(d['source_urls'])]+[('additional_source_urls',i,u) for i,u in enumerate(d.get('additional_source_urls',[]))]
 for field,index,u in urls:
  sid=f'SO{len(sourceoccurrences)+1:05d}';ts=tokens(u);rec['source_occurrence_ids'].append(sid)
  relateddocs=[doc for doc in reach if ts & doc_tokens.get(doc,set())]
  scopedclaims=[x for x in linkedclaims if ts & set(x['source_identity_tokens'])]
  fields=[x for x in linkedfields if ts & set(x['source_identity_tokens'])]
  soc={'source_occurrence_id':sid,'decision_id':did,'ledger_source_field':field,'ordinal_in_original_field':index,
    'source_URL_verbatim':u,'source_identifier_tokens':sorted(ts),'preparation_route_verbatim':d['route'],
    'contrast_id':'UNKNOWN_UNSTRUCTURED_OR_NOT_EXPLICITLY_SCOPED','study_family_id':'UNKNOWN_IDENTIFIER_EDGE_IS_NOT_COHORT_EQUIVALENCE',
    'documents_with_same_identifier_tokens':sorted(relateddocs),'reported_claim_ids_with_explicit_identifier_context':[x['reported_claim_id'] for x in scopedclaims],
    'structured_stage_field_ids_with_explicit_identifier_context':[x['stage_field_id'] for x in fields],
    'new_retrievals_or_body_reading':0,'component_rows':[]}
  for comp in components:
   cc=[x for x in scopedclaims if comp in x['component_mentions_not_reading_inferences']]
   raw=[]
   for doc in relateddocs:
    for e in raw_by_doc[doc]:
     # The declared metadata context may share an identifier; raw byte existence
     # is pinned independently but is not certified as the same source body.
     if components[comp].search(e['raw_pointer']+' '+e.get('JSON_pointer','')):raw.append(e['edge_index'])
   cr={'component_row_id':f'CR{len(componentrows)+1:06d}','source_occurrence_id':sid,'decision_id':did,'component':comp,
      'source_URL_verbatim':u,'preparation_route_verbatim':d['route'],'contrast_id':soc['contrast_id'],
      'reported_component_depth':'VERBATIM_SCOPED_CLAIMS_PRESENT_NOT_VALIDATED' if cc else 'UNKNOWN_NO_EXPLICIT_COMPONENT_READING_RECEIPT_AT_THIS_IDENTITY',
      'reported_claim_ids':[x['reported_claim_id'] for x in cc],
      'reported_claim_classifications':list(dict.fromkeys(x['reading_classification'] for x in cc)),
      'independently_byte_checked_pointer_edge_indices':raw,
      'independent_byte_identity_status':'EXPLICIT_LINKED_BYTES_EXIST_IDENTIFIER_CONTEXT_ONLY' if raw else 'UNKNOWN_NO_INDEPENDENT_COMPONENT_BODY_BINDING_AT_THIS_IDENTITY',
      'exact_source_body_equivalence':'UNKNOWN_NOT_INFERRED_FROM_SHARED_DOI_REGISTRY_NAME_OR_DIRECTORY',
      'actual_reading_validated_by_this_audit':False,'full_primary_depth_completion':'UNKNOWN',
      'known_historical_partial_negative_or_access_limits_preserved':True,'new_credit':0}
   componentrows.append(cr);soc['component_rows'].append(cr['component_row_id'])
  sourceoccurrences.append(soc)
 records.append(rec)

save('source-evidence-stage-register.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'MECHANICAL_EXISTING_EVIDENCE_STAGES_ONLY','captured_repository_HEAD':j(O/'input-snapshot-bindings.json')['HEAD_start'],
 'ledger_snapshot_sha256':sha(O/'frozen-inputs/repository/decisions.json'),'decision_count':len(records),
 'source_URL_occurrence_count':len(sourceoccurrences),'component_row_count':len(componentrows),
 'records':records,'source_preparation_contrast_identifier_occurrences':sourceoccurrences,'component_rows':componentrows,
 'original_fields_preserved_verbatim':True,'source_labels_are_reported_not_reappraised':True,
 'source_body_and_cohort_equivalence_not_inferred':True,'all_new_chemical_alias_trial_source_reading_efficacy_nominee_credits':0,
 'supporting_document_graph':'explicit-linked-document-capture.json','reported_depth_fields':'reported-reading-depth-claims-verbatim.json',
 'existing_stage_fields':'existing-stage-statements-and-fields-verbatim.json','worldwide_or_efficacy_completeness':False})

def tsv(n,fieldnames,rows):
 p=O/n;assert not p.exists(),p
 with p.open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=fieldnames,delimiter='\t');w.writeheader()
  for r in rows:w.writerow({k:(json.dumps(v,ensure_ascii=False,separators=(',',':')) if isinstance(v,(dict,list)) else v) for k,v in r.items()})
tsv('source-evidence-stage-register-decisions.tsv',[
 'decision_id','decision_ordinal_zero_based','reported_route','join_status_verbatim','source_occurrence_count','reported_depth_claim_count_document_scope',
 'original_decision_verbatim_json','existing_ledger_labels_verbatim_json','stage_specific_labels_json','report_pointer_edges_json','source_occurrence_ids_json'],[
 {'decision_id':r['decision_id'],'decision_ordinal_zero_based':r['decision_ordinal_zero_based'],'reported_route':r['preparation_identity']['reported_route_verbatim'],
 'join_status_verbatim':r['catalogue_presence_and_join']['join_status_verbatim'],'source_occurrence_count':len(r['source_occurrence_ids']),
 'reported_depth_claim_count_document_scope':len(r['reported_depth_claim_ids_at_document_scope']),
 'original_decision_verbatim_json':r['original_decision_verbatim'],'existing_ledger_labels_verbatim_json':r['existing_ledger_labels_verbatim'],
 'stage_specific_labels_json':r['stage_specific_labels'],'report_pointer_edges_json':r['report_pointer_edges'],'source_occurrence_ids_json':r['source_occurrence_ids']} for r in records])
tsv('source-evidence-stage-register-components.tsv',list(componentrows[0]),componentrows)
tsv('source-evidence-stage-register-sources.tsv',list(sourceoccurrences[0]),sourceoccurrences)

denoms={'ledger_decision_objects':len(records),'original_primary_report_pointer_values':len({d['source_report'] for d in ds}),
 'source_URL_occurrences_not_unique_sources_or_trials':len(sourceoccurrences),'component_rows_not_unique_bodies_or_reads':len(componentrows),
 'captured_explicit_document_nodes':len(docs),'original_alias_join_rows':len(aliasrows),
 'catalogue_projection_rows':len(appraisals),'catalogue_main_rows':len(catalog),
 'decision_join_status_counts':dict(collections.Counter(r['catalogue_presence_and_join']['join_status_verbatim'] for r in records)),
 'component_scoped_claim_presence_counts':{s:dict(collections.Counter(r['reported_component_depth'] for r in componentrows if r['component']==s)) for s in components},
 'reported_depth_claim_object_count':len(claims),'reported_structured_stage_field_object_count':len(stagefields),
 'report_topic_statement_count_not_assay_count':len(statements),
 'actual_scientific_reads_validated_by_mechanical_audit':0,'new_source_reading_credit':0,
 'full_main_qualified_source_denominator':'UNKNOWN','restoration_RNA_protein_checkpoint_fidelity_function_compensation_denominators':'UNKNOWN_NOT_REAPPRAISED',
 'unique_drug_chemical_preparation_cohort_trial_denominators':'UNKNOWN_NOT_DERIVED',
 'counts_are_nonadditive_and_not_worldwide_coverage':True}
save('bounded-stage-denominators.json',denoms)
gaprows=[]
for r in records:
 for stage,lab in r['stage_specific_labels'].items():
  gaprows.append({'decision_id':r['decision_id'],'stage':stage,'gap':'No explicit validated stage-specific label assigned by mechanical audit; original reported fields/statements remain verbatim',
    'unit':'Decision-specific requested stage; no assay/effect inference','new_credit':0})
for cr in componentrows:
 if cr['reported_component_depth'].startswith('UNKNOWN'):
  gaprows.append({'decision_id':cr['decision_id'],'source_occurrence_id':cr['source_occurrence_id'],'component':cr['component'],
   'gap':cr['reported_component_depth'],'unit':'Source/preparation/contrast identifier occurrence; not a unique body','new_credit':0})
for e in g['edges']:
 if e.get('retrieval_existence') in ['UNRESOLVED_FILE_NOT_PRESENT','UNSTABLE_FILE_DURING_CAPTURE']:
  gaprows.append({'pointer_edge':e,'gap':e['retrieval_existence'],'scope':'Exact unresolved pointer retained; no invented companion or redirect','new_credit':0})
save('uncapped-explicit-gaps.json',{'gaps':gaprows,'gap_object_count':len(gaprows),
 'not_unique_or_independent_scientific_gaps':True,'blank_missing_unread_not_no_effect':True,
 'whole_primary_denominator_not_invented':True})
save('mechanical-method-and-scope.json',{'scope':'Every309 complete decision object, exact report/URL pointers and explicitly linked metadata only',
 'snapshot':'input-snapshot-bindings.json','foreign_directory_search':False,'scientific_reappraisal':False,
 'reading_claim_rule':'Preserve exact fields/lines with immutable original file, JSON pointer or character/line positions. Hash presence/title/rationale/topic wording never establishes actual reading.',
 'identifier_rule':'Shared DOI/PMID/PMCID/registry/URL is an identifier edge, never body/cohort/preparation equivalence.',
 'component_rule':'Reported scoped claims and independently byte-checked linked pointers are separate; absence of explicit depth remains UNKNOWN. Positive/negative/historical/partial claims coexist.',
 'stage_rule':'Original labels remain exact. Topic statements are not converted to labels, genotype assays or efficacy. Stage-specific labels remain UNKNOWN absent explicit reported structured labels.',
 'denominator_rule':'Decision/source occurrence/component rows and explicit claimed-field presence are bounded counts. No309-unique-drug, all-primary, validated assay or competitiveness denominator.',
 'current_global_goal':'Worldwide drug/common-compound coverage and comparable BUB1B/function evidence remain broader than this linked mechanical register.',
 'credits':{'catalogue_or_chemical_join':0,'aliases':0,'trial_or_cohort':0,'source_reading':0,'accepted_screen':0,'efficacy_rank':0,'nominee_change':0,'repository_mutation':0}})
print(json.dumps({'decisions':len(records),'source_URL_occurrences':len(sourceoccurrences),'component_rows':len(componentrows),
 'reported_depth_fields':len(claims),'structured_stage_fields':len(stagefields),'explicit_gap_objects':len(gaprows),'denominators':denoms['decision_join_status_counts']}))
