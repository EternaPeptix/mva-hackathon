# Connolly 2006: Montmorency cherry–apple juice blend

**Retain for independent review as a preparation-specific acute functional-protection signal.** The randomized crossover study reports less loss of measured elbow-flexion strength with the Cherrypharm blend than with placebo after deliberately damaging exercise. This is a controlled muscle-function observation, not merely a blood biomarker. It does not establish treatment of chronic weakness, protection in BUB1B-associated MVA, or superiority over the provisional nominees. [Connolly et al., 2006](https://doi.org/10.1136/bjsm.2005.025429), PMID 16790484, [full scientific main](https://pmc.ncbi.nlm.nih.gov/articles/PMC2579450/).

## Exact preparation and comparator

The intervention was **freshly prepared juice from frozen Montmorency tart cherries blended with commercial apple juice in an undisclosed proprietary ratio**, supplied as the Cherrypharm formulation. It was not generic cherries, cherry juice alone, concentrate, isolated anthocyanins or a chemically defined single molecule. The blend was heated to 85°C, hot packed with a three-minute hold and water cooled. The Methods describe frozen starting fruit; the Discussion's “fresh” language distinguishes it from concentrate, not an unfrozen-fruit preparation.

Each 12 fl oz bottle reportedly contained at least **600 mg phenolics as gallic-acid equivalents** and **40 mg anthocyanins as cyanidin-3-glucoside equivalents**, using specified analytical methods. The source describes the equivalent of 50–60 cherries per bottle. These are preparation-characterization results, not exact doses of individual compounds, measured systemic exposure or proof of current retail equivalence.

Participants were instructed to drink one bottle morning and evening for eight days, with eccentric exercise on the fourth supplementation day. This records the trial exposure, not a recommendation. The placebo used unsweetened black-cherry Kool-Aid and water, with sugar added to match **13 Brix soluble solids**, then the same pasteurization/bottling procedure. The article does not supply an analytical calorie comparison or an apple-juice-only control. The observed contrast therefore belongs to the **whole cherry–apple blend versus this soluble-solids-matched flavored drink**. Apple components cannot be separated from cherry components.

## Design, sequence and attrition

Sixteen men volunteered and started the protocol; their mean age was 22 years (SD 4). They had no recent upper-extremity strength training, elbow pain, or elbow/shoulder injury history. The paper reports random assignment both of arms to treatments and of treatment order; the sequence-generation and concealment procedures are not supplied. Participant/investigator masking and a blinding-success assessment are not described in the scientific main, so “double blind” cannot be assigned from this source.

Nine men initially received placebo and seven the blend. **Both withdrawals were in the blend-first sequence**: the two students left school at semester end. Fourteen completed both periods, leaving **nine placebo-first and five blend-first**. No intention-to-treat estimate, imputation or sensitivity for the two missing complete sequences is reported.

For each period, the protocol measured baseline symptoms and force before providing drinks, then gave 40 maximal eccentric elbow-flexion contractions in two sets. Strength and symptoms were assessed at 24, 48, 72 and 96 hours after exercise. The opposite arm was used in period two, beginning two weeks after the initial baseline—**six days after the first trial ended**, not a two-week treatment-free washout. Visit times were kept consistent. Upper-body exercise and anti-inflammatory/pain-relieving medicines were restricted; quantitative adherence and achieved eccentric workload results are not supplied.

The authors argue that using the opposite arm avoids the repeated-bout effect. It avoids repeating the damaging exercise on the same local muscle, but this trial does not establish that all cross-limb, systemic, learning, period or treatment carryover is absent. A formal treatment-by-period/sequence model and a verified pharmacological washout are not reported.

There is useful counterevidence to a simple “second bout is always better” explanation: in the **five blend-first completers**, blend-period strength loss was 3% (SD 2) versus 24% (SD 3) during their later placebo period, with treatment-by-time **P=.001**. This small reanalysis, reported in the Discussion without prospective specification, strengthens the signal's plausibility; it is not independent replication or a substitute for a full crossover analysis. Pain's corresponding interaction in that subgroup was **P=.83**.

## Functional outcome and actual comparisons

A force transducer recorded peak voluntary isometric elbow-flexion force in Newtons at 130°, 90° and 30° of flexion. Two contractions per angle were averaged. However, the published efficacy results are **percentages relative to each period's baseline**, not an absolute Newton treatment effect. Baseline force means, paired difference variances and treatment-effect confidence intervals are not supplied. Do not relabel the percent contrast as an absolute force gain.

| Outcome | Blend | Placebo | Actual comparison |
|---|---:|---:|---|
| Strength loss averaged over four days and three angles | 4% (SD 15) | 22% (SD 12) | Treatment-by-time **P<.0001**; reported average-loss comparison also **P<.0001**. Arithmetic difference is **18 percentage points less loss**, not a published effect CI. |
| Strength loss at 24 hours | 12% | 30% | Figure 1 marks **P<.01**, Bonferroni-corrected daily pairwise comparison. |
| Strength at 96 hours | 6% above baseline | 12% below baseline | Figure 1 marks **P<.001**, Bonferroni-corrected daily comparison. These short-term values do not establish durable strength gain. |
| Pain averaged over four days, 0–10 scale | 2.4 (SD 0.7) | 3.2 (SD 1.1) | Average comparison **P=.051**, despite a positive time-course interaction **P=.017**. |
| Relaxed-elbow-angle motion loss | 3.5° (SD 6.0) | 4.4° (SD 5.6) | Time-course interaction **P=.85**. |
| Tenderness threshold change | 8.8 N (SD 9.7) | 8.2 N (SD 10.1) | Interaction **P=.81**; mean comparison **P=.84**. |

Figure 1's remaining daily pairwise marks are P<.001 at 48 hours and P<.05 at 72 hours, with Bonferroni correction stated in its caption. All four figures show **SE**, whereas narrative dispersion is **SD**. The strength interaction did not differ detectably across angles (three-way interaction P=.41); that is not an equivalence test.

The paper gives a sample-size calculation: 16 participants for 80% power to detect its stated 14% difference in strength loss, with corresponding detectable differences for pain, tenderness and motion. Actual completion was 14. Four symptom outcomes and multiple time points were analyzed with repeated-measures ANOVA. **Pairwise multiplicity correction was reported and must be credited.** A prespecified single primary endpoint, adjustment across all endpoint families and prospective registry/SAP verification are not provided. Strength was the sample-size anchor, but that alone does not establish a prospectively registered hierarchy.

## Interpretation, safety and transparency

Strength is actual function here; CK and myoglobin were **not measured**. The authors explicitly decline to infer that structural muscle damage was prevented merely because two of four symptom measures improved. Antioxidant/anti-inflammatory mediation was hypothesized rather than measured. Reduced pain or altered voluntary activation cannot be separated from structural protection by the published measurements. The preparation was started before injury and continued afterward; there was no post-injury-only treatment arm and no chronic-disease cohort.

The study was **funded by Cherrypharm**, and the paper discloses **2.5% company equity for each author**. This is a material conflict to retain, not proof that the findings are invalid. Sponsor involvement beyond funding is not described. No systematic adverse-event counts, laboratory safety outcomes or tolerability endpoint are supplied. The departures were attributed to leaving school; missing safety reporting must not be translated into “no adverse events” or long-term, pediatric or cancer-context safety.

No registration ID, recruitment dates, raw participant data or public prospective protocol was located in the main. A bounded fresh ClinicalTrials.gov exact-title query returned zero studies; registration under another title or registry remains unknown. PubMed lists a later commentary (PMID 17092438), not a correction; it was not read for this appraisal. No correction/retraction relation appeared in the inspected PubMed/Crossref fields. This is a bounded notice check, not a guarantee that no critique exists.

## Competitive disposition and reading boundary

The blend warrants a **preparation-specific functional reserve**: it reports a direct placebo-controlled acute strength-preservation signal under a defined challenge. The small imbalanced completer crossover, unresolved masking/carryover, undisclosed blend ratio and short healthy-exercise setting limit confirmation and transfer. It cannot rank chronic clinical benefit against niacin or apitegromab. Compensation credit does not require BUBR1 restoration; advancing to an MVA claim would still require relevant-model useful output, exposure, renewable reserve and chromosome fidelity under the same standards as the provisional nominees.

The full original scientific main was read from lawful PMC HTML, including all Methods, Results, Discussion, funding and conflicts. All four native figures and captions were visually examined. No results tables or supplement links were present in that main. The PMC PDF request returned an access page and the publisher PDF request returned 403; **no PDF reading credit** is claimed. Reference papers, the later commentary and other cherry trials were not read. No original-queue credit, new experiment, repository integration or nomination change is assigned. Independent review is the next gate.
