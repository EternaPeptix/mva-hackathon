"""Add exact preparation/contrast metadata and preserve mixed depth, no appraisal."""
import pathlib,json,re,hashlib,datetime,collections,urllib.parse,os
O=pathlib.Path(os.environ.get('MVA_STAGE_REGISTER_ROOT','/Users/jeweled/mva-hackathon/track2-drug-census-work/global-existing-evidence-stage-register-20261005'))
def j(p):return json.loads(pathlib.Path(p).read_text())
def save(n,x):
 p=O/n;assert not p.exists(),p;p.write_text(json.dumps(x,ensure_ascii=False,indent=2)+'\n')
g=j(O/'explicit-linked-document-capture.json');reg=j(O/'source-evidence-stage-register.json');fields=[]
keypat=re.compile(r'^(?:contrast_id|contrast|preparation_id|preparation|dose|route|vehicle|timepoint|study_family_id|comparator|population|genotype)$',re.I)
identitypat=re.compile(r'^(?:source(?:_id|_ids|_url|_urls|_record_id|_identity|_metadata)?|selected(?:_source|_identity)?|pmid|pmcid|doi|url|urls|registry|study_id|record_id|identity)$',re.I)
def tokens(s):
 s=urllib.parse.unquote(str(s));out=set()
 for x in re.findall(r'10\.\d{4,9}/[^\s<>"\]\)`,;]+',s,re.I):out.add('DOI:'+x.rstrip('.').casefold())
 for x in re.findall(r'\bPMC\d+\b',s,re.I):out.add(x.upper())
 for x in re.findall(r'(?:pubmed\.ncbi\.nlm\.nih\.gov/|(?:PMID|MED)\s*[: ]?)(\d{5,9})',s,re.I):out.add('PMID:'+x)
 for x in re.findall(r'\b(?:NCT\d{8}|UMIN\d{9}|RBR-[A-Za-z0-9]+|ISRCTN\d+|KCT\d+)\b',s,re.I):out.add(x.upper())
 for x in re.findall(r'https?://[^\s<>"\]`)]+',s,re.I):out.add('URL:'+x.rstrip('.,;').casefold())
 return out
for d in g['documents']:
 p=pathlib.Path(d['frozen_copy'])
 if p.suffix not in ['.json','.jsonl']:continue
 try:obj=j(p) if p.suffix=='.json' else [json.loads(l) for l in p.read_text().split('\n') if l]
 except Exception:continue
 def walk(v,loc='',context=None):
  context=context or {};local=dict(context)
  if isinstance(v,dict):
   direct={k:x for k,x in v.items() if identitypat.fullmatch(k) and isinstance(x,(str,int,list,dict))}
   if direct:local={'direct_identity_fields':direct,'parent_explicit_identity_context':context}
   for k,x in v.items():
    pp=loc+'/'+k.replace('~','~0').replace('/','~1')
    if keypat.fullmatch(k):fields.append({'field_id':f'PI{len(fields)+1:06d}','document_id':d['document_id'],
      'original_path':d['original_path'],'original_sha256':d['sha256'],'JSON_pointer':pp,
      'field_name_verbatim':k,'value_verbatim':x,'explicit_source_context_verbatim':local,
      'source_identifier_tokens':sorted(tokens(json.dumps(local,ensure_ascii=False))),
      'identity_equivalence_validation':'UNKNOWN_NOT_INFERRED','source_reading_credit':0})
    walk(x,pp,local)
  elif isinstance(v,list):
   for i,x in enumerate(v):walk(x,loc+'/'+str(i),local)
 walk(obj)
save('explicit-preparation-contrast-fields-verbatim.json',{'fields':fields,'count':len(fields),
 'role':'Original preparation/comparator/contrast/population/route/dose/time field values only; not new contrasts, studies, aliases or efficacy judgments',
 'explicit_id_fields_found':sum(x['field_name_verbatim'].endswith('_id') for x in fields),
 'UNKNOWN_contrast_ids_not_invented':True})
bydoc=collections.defaultdict(list)
for x in fields:bydoc[x['document_id']].append(x)
for r in reg['records']:
 r['explicit_preparation_contrast_field_ids_at_document_scope']=[x['field_id'] for doc in r['explicit_reachable_document_ids'] for x in bydoc[doc]]
for r in reg['source_preparation_contrast_identifier_occurrences']:
 ids=set(r['source_identifier_tokens']);reach=set(next(d['explicit_reachable_document_ids'] for d in reg['records'] if d['decision_id']==r['decision_id']))
 matched=[x for x in fields if x['document_id'] in reach and ids&set(x['source_identifier_tokens'])]
 r['explicit_preparation_contrast_field_ids_with_identifier_context']=[x['field_id'] for x in matched]
 # There are no explicit contrast_id/preparation_id/study_family_id keys in the
 # captured linked originals. Leave those identities UNKNOWN, rather than
 # manufacture a scientifically independent comparison from prose.
reg['explicit_preparation_contrast_fields']='explicit-preparation-contrast-fields-verbatim.json'
(O/'source-evidence-stage-register.json').write_text(json.dumps(reg,ensure_ascii=False,indent=2)+'\n')

claims=j(O/'reported-reading-depth-claims-verbatim.json')['claims'];cm={x['reported_claim_id']:x for x in claims};mixed=[];limits=[]
for x in claims:
 if 'LIMIT_OR_NEGATIVE_OR_MIXED_SCOPE_PRESENT' in x['reading_classification']:limits.append(x['reported_claim_id'])
for r in reg['component_rows']:
 vals=[cm[i] for i in r['reported_claim_ids']];states=set(x['reading_classification'] for x in vals)
 if len(states)>1:
  mixed.append({'component_row_id':r['component_row_id'],'decision_id':r['decision_id'],'source_occurrence_id':r['source_occurrence_id'],
    'component':r['component'],'reported_claim_ids':sorted(r['reported_claim_ids']),'reported_classifications':sorted(states),
    'status':'MULTIPLE_REPORTED_STATES_POSSIBLY_HISTORICAL_MIXED_OR_CONTRADICTORY_NOT_RESOLVED',
    'no_vote_or_upgrade':True,'all_original_claims_retained':True})
save('historical-partial-access-and-mixed-depth-index.json',{'possible_mixed_or_historical_component_rows':mixed,
 'count':len(mixed),'partial_negative_metadata_only_unknown_or_access_limit_claim_ids':limits,
 'limit_claim_count':len(limits),'classification_is_not_a_proven_scientific_conflict':True,
 'historical_claims_not_erased_by_later_claims':True,'positive_negative_and_UNKNOWN_preserved':True})

docs={d['document_id']:d for d in g['documents']};checks=[]
for i,e in enumerate(g['edges']):
 expected=e.get('expected_binding_original')
 if expected:
  doc=docs.get(e.get('document_id'))
  checks.append({'edge_index':i,'decision_id':e.get('decision_id'),'original_pointer':e['raw_pointer'],
    'original_expected_binding_verbatim':expected,'captured_document_id':e.get('document_id'),
    'captured_document_hash':doc['sha256'] if doc else 'UNKNOWN',
    'expected_sha256_matches_captured':bool(doc) and expected.get('sha256',doc['sha256'])==doc['sha256'],
    'expected_bytes_matches_captured':bool(doc) and expected.get('bytes',doc['bytes'])==doc['bytes'],
    'source_body_reading_or_comprehension_inferred':False})
save('ledger-explicit-audit-pointer-binding-checks.json',{'checks':checks,'count':len(checks),
 'all_expected_pointer_bindings_match':all(x['expected_sha256_matches_captured'] and x['expected_bytes_matches_captured'] for x in checks),
 'mismatches_if_any_not_repaired_or_hidden':True,'reported_reading_separate_from_verified_bytes':True})
print(json.dumps({'explicit_preparation_contrast_fields':len(fields),'explicit_contrast_ID_fields':sum(x['field_name_verbatim'].endswith('_id') for x in fields),
 'mixed_historical_rows':len(mixed),'limit_claims':len(limits),'explicit_ledger_audit_bindings':len(checks)}))
