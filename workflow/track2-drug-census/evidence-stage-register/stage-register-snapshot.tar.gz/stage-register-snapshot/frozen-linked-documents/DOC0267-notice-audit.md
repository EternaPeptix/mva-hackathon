# CoQ10 linked erratum: bounded retrieval audit

Status: METADATA_ONLY_NOTICE_BODY_UNAVAILABLE.

Parent study: PMID 18272335; DOI 10.1016/j.nut.2007.12.007; Mizuno et al., Nutrition 2008;24:293-299.

## Identity evidence

- The parent PubMed XML explicitly contains `CommentsCorrections RefType="ErratumIn"` with `RefSource` Nutrition. 2008 Jun;24(6):616. It gives no notice PMID.
- Direct Crossref notice metadata gives title Erratum, DOI 10.1016/j.nut.2008.04.001, PII S0899900708001755, Nutrition 24(6):616, June 2008. Its relation field is empty and it has no abstract or original-study reference.
- Elsevier coredata confirms the same DOI/PII/title and June 2008 journal date, but contains no originalText or notice body.
- Thus the candidate matches the explicitly linked erratum location by metadata. Its link to the original study and correction contents remain unconfirmed from the notice body.

## Actual read scope

- Zero native notice pages and zero original notice body were read.
- Read the complete returned Crossref work metadata and default Elsevier coredata XML; inspected only the parent PubMed CommentsCorrections element.
- Read DOI/linkinghub redirect/title metadata, targeted OpenAlex access/location fields, and short API error messages.
- ScienceDirect denial responses were checked for HTTP status, content type and PDF signature, not interpreted as article content.
- Web search snippets showed repeated citations/main-study metadata but no original notice text. No secondary PDF was opened or downloaded.
- No main-PDF full-reading claim, new primary-study screening, efficacy ranking, or result-equivalence claim is made.

## Retrieval outcome

- ScienceDirect article and pdfft endpoints: 403 Forbidden; returned HTML denial data, not PDF.
- Elsevier default XML: 200 metadata only.
- Elsevier advertised text/plain endpoint: 400 INVALID_INPUT; invalid view parameter.
- Elsevier view=FULL XML: 401 AUTHENTICATION_ERROR; invalid API key (no key was supplied).
- Elsevier PDF accept request: 406; application/pdf restricted.
- DOI and linkinghub: 200 redirect HTML, not notice body.
- Europe PMC exact DOI search: hitCount 0.
- OpenAlex: closed, no OA URL, no repository fulltext location; not proof that no lawful copy exists.

## Correction status

What the notice corrects: UNKNOWN. Whether it changes participants, protocol, doses, numerical results, tables, authorship, or conclusions: UNKNOWN. Do not classify it as minor, authors-only, or efficacy-equivalent without original correction text.

Detailed URLs, UTC retrieval times, HTTP responses, payload sizes and SHA-256 hashes are in retrieval-log.json. Raw response files preserve the evidence and failures; files ending in .bin are denial/error responses, not recovered PDFs. notice-audit.json provides the machine-readable status. web-attempts.json records the bounded search queries and web-tool failures.

## Source response hashes

- crossref-notice.json: SHA-256 `b07a101dc463b9ae093d373d2b56a7f66a342fde9e7fbabd33f5aeddd14edbf4`; 1934 bytes; HTTP 200.
- doi-resolver.html: SHA-256 `c4a58d9b0d781956b7a9d9027c6092e46b5a654c57ee8cb3af61a6d5501db018`; 2644 bytes; HTTP 200.
- linkinghub.html: SHA-256 `c4a58d9b0d781956b7a9d9027c6092e46b5a654c57ee8cb3af61a6d5501db018`; 2644 bytes; HTTP 200.
- publisher-notice.html: SHA-256 `fadd3b5852ba00063b45d5e204d13db9aa3697155ccacc79377ce0764e08f998`; 832804 bytes; HTTP 403.
- publisher-notice-pdf-response.bin: SHA-256 `2b5a24899d78902cc9cf6450a6254db492b93dfc5025814f89e092a75c3aaa58`; 832804 bytes; HTTP 403.
- elsevier-xml-response.xml: SHA-256 `19351a0fdfd1fd779e07b22aa95a021c4fdcd4ed35905bc8b67865e0cfe18434`; 1735 bytes; HTTP 200.
- elsevier-text-response.txt: SHA-256 `20332b7f504e84c1bbbc7570f8728d79b2c2db445b3365e667a37eac42f06bdc`; 159 bytes; HTTP 400.
- pubmed-main-efetch.xml: SHA-256 `0f2350142f587ecddb64afaee41ce8c25f3ce8a11da19f4a667ad7b7d81d639d`; 8224 bytes; HTTP 200.
- europepmc-notice-search.json: SHA-256 `6c1921525f448fa9a7bbcc41ccf2cc56784e3af9f44f4eb899deb42eaea1d249`; 192 bytes; HTTP 200.
- elsevier-full-xml-response.xml: SHA-256 `a199c5505f5d84ca6206475b3a116d509aa4528f154f0d3cdbc57669ec400bb5`; 133 bytes; HTTP 401.
- elsevier-pdf-response.bin: SHA-256 `8896659c8776e3601cba7215e75d52d13a0aa4cde5150bbf00660945a33f39b7`; 162 bytes; HTTP 406.
- openalex-notice.json: SHA-256 `eab9520ba675628a4b261074480c15969188c155bf209bf3eee7f00d78ceeddd`; 3617 bytes; HTTP 200.
