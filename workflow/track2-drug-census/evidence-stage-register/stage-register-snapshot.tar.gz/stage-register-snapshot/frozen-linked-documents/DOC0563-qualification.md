# Selected new preparation: KSM-66 ashwagandha root extract

**Retain for independent review as a human strength-training compensation challenger.** [Wankhede et al., 2015](https://doi.org/10.1186/s12970-015-0104-9), PMID 26609282/PMC4658772, reports randomized placebo-controlled strength gains with the named extract. The preparation is absent from the current 256 appraisal IDs/routes/aliases. This is a substantive controlled functional comparison beyond niacin's uncontrolled myopathy observations, but not evidence of greater clinical benefit than apitegromab, MVA efficacy, or BUBR1 restoration.

## Preparation and actual contrast

**KSM-66**, manufactured by Ixoreal BioMed, was a water-extracted *Withania somnifera* root preparation standardized to **5% withanolides by HPLC**. A local laboratory put 300 mg extract or 300 mg starch into visually identical cellulose capsules. The source regimen was one capsule twice daily for eight weeks. This describes the trial, not a recommended regimen. Results belong to the standardized multicomponent root extract, not isolated withanolides, withaferin A, leaf extracts or an arbitrary retail bottle. No independent lot-composition assay was reported.

Both arms received the same prescribed resistance-training program, with two initial acclimatization weeks and progressive loading. The comparison is **extract plus training versus starch plus training**; there is no extract-only arm. Randomization and double blinding are reported, with identical capsule appearance/weight/texture, but sequence generation, concealment and assessor-specific masking are not detailed. The main gives no registration identifier or recruitment dates. Bounded CTRI-index and ClinicalTrials.gov exact-title checks found no matched record; prospective endpoint hierarchy and registration timing remain UNKNOWN, not proven absent. No sample-size calculation was identified.

## Functional results and denominators

Native CONSORT Figure 1 shows 79 screened, 57 randomized (extract 29/placebo 28), and 50 analyzed (25/25). Four extract and three placebo participants stopped resistance training and were lost to follow-up. Reported efficacy is therefore a **completer analysis**, without a supplied intention-to-treat estimate or missing-data sensitivity analysis.

Participants were healthy men aged 18–50, inexperienced in resistance training. Mean completer ages were 28 and 29. Muscle strength was the author-stated primary endpoint, evaluated on bench-press and leg-extension machines using a described multiple-RM variant of a 1RM protocol; it is a task-load strength measure, not direct dynamometer muscle force. Assessment occurred at baseline and two days after the eight-week program.

| Primary strength change | Extract, n=25 | Placebo, n=25 | Direct comparison |
|---|---:|---:|---|
| Bench-press 1RM | +46.05 kg (within-arm 95% CI 36.56–55.54) | +26.42 kg (19.52–33.32) | P=.001; difference in reported mean changes **+19.63 kg** |
| Leg-extension 1RM | +14.50 kg (10.76–18.23) | +9.77 kg (7.18–12.35) | P=.04; difference **+4.73 kg** |

The differences above are simple subtraction of source means. **No confidence interval for the between-arm difference is reported**; the quoted intervals describe each arm's change. Bench baseline/post means were 33.21/79.26 kg versus 31.35/57.77 kg; leg-extension means 27.89/42.38 kg versus 25.22/34.98 kg. Both groups improved substantially, consistent with training and novice-task adaptation.

ANOVA with group as a factor, Mann–Whitney when nonnormal, and alpha .05 are reported. Multiplicity adjustment is not described despite two strength outcomes and numerous secondary tests. The leg-extension P=.04 is consequently a nominal finding; no hierarchy or multiplicity procedure has been prospectively verified.

## Positives, nulls and safety boundaries

Secondary findings favored extract for estimated arm cross-sectional area, chest girth, body-fat change, testosterone change and the creatine-kinase metric. **Thigh-size change was nonpositive (P=.36)**. Size was estimated from girth/skinfolds rather than imaging; body fat used impedance. Testosterone's final between-group level was nonsignificant (P=.42), despite its significant change contrast.

“Recovery” was a **creatine-kinase biomarker difference between 24 and 48 hours after exercise**, compared before/after training. It was not a measured restoration of force, soreness resolution or daily function. Table 6's negative changes and confidence intervals take precedence over inconsistent signs in narrative/abstract descriptions; arm-size means also differ slightly between abstract and Table 3.

No serious side effects were reported; tolerability was rated good/excellent, without detailed event counts or a separate safety-analysis denominator. Eight weeks in 50 completers cannot establish rare, long-term, pediatric or cancer-context safety. [NCCIH](https://www.nccih.nih.gov/health/ashwagandha) recognizes marketed ashwagandha supplements and notes preparation variability, GI/sedating effects, rare liver-injury reports and interaction concerns. That agency material supplies availability/safety context, not efficacy credit for this trial or proof of retail equivalence.

The authors declared no conflicts and thanked Shri Kartikeya Pharma/Ixoreal for supplying extract; cash funding and sponsor influence are not described. PubMed/Crossref contained no linked correction/retraction in this bounded check. Full scientific main, all three native figures and native Tables 2–6 were read. No supplement was linked in the retrieved main; raw data and prospective protocol were not obtained.

**Next:** independently review this packet, then qualify the concrete later KSM-66 trial PMID 38988644/PMC11234080 before treating the signal as replicated. Current priority is a preparation-specific functional reserve, with no nomination change, repository integration, new original-queue credit or worldwide-complete claim.
