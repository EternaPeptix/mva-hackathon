# What the broad drug search changes

**Adopted research comparison, 21 September 2026; challenger comparison updated 29 September.** The proposal nominates **niacin for BUBR1 restoration and apitegromab for downstream muscle compensation, tested separately**. NMN is now explicit as a distinct NAD-precursor benchmark in the restoration comparison, not a niacin alias or an established winner. Everolimus remains a conditional mTORC1 mechanism probe. Neither primary nominee has demonstrated MVA rescue; this is a research-priority judgment, not an estimate of treatment efficacy.

The census screens 15,357 entities plus [45 dated FDA 2026 product entries](fda-approval-refresh-20261004.md) retained separately, with **309 curated route/compound appraisals**. Retrieval and co-mentions do not establish every drug's efficacy; missing evidence remains UNKNOWN. The revised local V4 movie and eight-slide deck are complete. At the existing Vimeo URL, V3 remains published pending replacement. Track 2 portal submission remains pending.

**Literature refresh, 28 September:** a targeted chaperone query returns 878 source/ID records. Seven pairs were absent from the saved 21 September gene corpus; two are duplicate index records, leaving five additional paper identities. One HCC multi-omics paper lists BUB1B among combination-associated transcripts after loratadine/raloxifene/sorafenib treatment, but does not report BUB1B's direction or function. This is not MVA rescue or ingredient-specific evidence and does not alter the candidate comparison; see the [source-bounded refresh](chaperone-refresh-2026-09-28.md).

**Oncology-compatibility source check, 29 September:** a 2025 breast-cancer study reports that genetic BUB1B knockdown changes radiation-associated checkpoint and DNA-damage-repair markers in MDA-MB-231 cells. It tests no BUBR1-restoring compound and no irradiated tumor survival. This is a specific reason to test interaction with a confirmed radiotherapy regimen, not evidence that niacin, NMN or another candidate worsens cancer outcomes; see the [source-bounded qualification](bubr1b-radiation-compatibility-qualification.md).

## Consumer-product chemicals, 28 September 2026

The [dated EPA CPDat v4.0 and v4.1 formulation overlays](cpdat-v4.1/README.md) and separate [Article-kind screens](cpdat-v4.1/articles/README.md) extend discovery beyond medicines and supplements. The v4.1 Formulation subset contributes **7,572 DTXSIDs** across 12 categories; the Article subset contributes **2,530 DTXSIDs** across 14 categories, with 1,634 occurring in both. These are source identifiers and composition records, not verified products, unique bioactive molecules or exposure estimates. After downgrading common-word/name-fragment collisions, the v4.1 Formulation screen retains **1,079 review-class field rows** across 685 source/ID records and 233 DTXSIDs; its Article screen retains **195 rows** across 122 source/ID records and 79 DTXSIDs. Eleven newly represented formulation DTXSIDs and six article-only exact-hit DTXSIDs receive initial source-role triage. Co-mentions are discovery leads, not efficacy evidence.

| Consumer-product chemical | BUB1B-relevant source result | Decision |
|---|---|---|
| **Bisphenol A (BPA)** | Two cell studies report lower BUB1B under exposure: human cumulus-cell expression at 20 μg/mL (abstract-level, described by the authors as supra-physiological) and BUB1B RNA/protein in BEAS-2B cells at 80 nM alongside cytotoxicity. CPDat v4.0 associates its DTXSID with 42 stable product IDs; the v4.1 export has 43 formulation rows and 43 document/product-name pairs across “Food and drug” and “Home maintenance.” | **Adverse-exposure comparator, not a treatment.** These different export keys are not directly equivalent. No BUB1B-variant, MVA, chromosome-fidelity, muscle-output or ordinary-use effect was demonstrated. See the [source-bounded qualification](cpdat-v4.0/bisphenol-a-consumer-exposure-qualification.md). |
| **Ibuprofen** | A 2026 primary rhesus-macaque Sertoli-cell RNA-seq comparison reports lower BUB1B transcript at 100 μM; Data File S4 gives effect column −1.0040105, adjusted P=2.89×10⁻⁸. CPDat v4.1 includes two formulation rows under “Food and drug.” | **Adverse-direction, high-concentration comparator; decline as a restoration lead.** The study measured neither BUBR1 protein/function nor muscle, chromosome fidelity or MVA, and does not establish ordinary-use harm. [Full qualification](naproxen-ibuprofen-bubr1b-qualification.md). |
| **Naproxen** | In the same primary study, 400 μM exposure lowered the BUB1B transcript signal (effect column −0.681759, adjusted P=6.08×10⁻⁶); lower-dose profiles were described as similar to vehicle. CPDat v4.1 separately lists naproxen sodium, a salt-form match. | **Adverse-direction, high-concentration comparator; decline as a restoration lead.** No BUBR1 protein/function, muscle, chromosome-fidelity, MVA or ordinary-use effect was shown; keep the salt-form product entry distinct. [Full qualification](naproxen-ibuprofen-bubr1b-qualification.md). |
| **Ozone (O₃)** | In 3-day-old mice exposed to 1,000 ppb for 3 h, a whole-lung microarray and published supplement report Bub1b RNA 2.16-fold lower at 24 h (P=6.90×10⁻⁵, q=0.043); independent GEO reanalysis matches the row to rounding. CPDat records ozone only in its Article-kind construction/material category. | **Adverse-direction exposure comparator, not an MVA lead.** This is whole-lung RNA after pollutant exposure; no BUBR1 protein/function, faithful segregation, muscle or MVA result. ChEMBL's max-phase-3 record is not an approval or MVA indication, and this inhalation exposure does not establish outcomes for medical-ozone routes. [Qualification](ozone-bubr1b-qualification.md). |
| **Mono-n-butyl phthalate (MnBP)** | A primary study reports lower BUB1B RNA after MnBP exposure in pooled human granulosa cells and an observational association between urinary MnBP and endometriosis. | **Adverse-direction exposure comparator, not a treatment.** Culture cells were pooled, concentrations were high, and no BUBR1 protein/function, faithful segregation or MVA outcome was measured. CPDat's generic “Phthalate” article alias is not an identity match to MnBP. [Qualification](monobutyl-phthalate-bubr1b-qualification.md). |
| **Parthenolide** | A primary cell study reports binding to ZNF207/BUGZ and disrupting kinetochore-microtubule attachment and chromosome congression. | **Do not promote for MVA.** This is not BUB1B restoration and points to interference with accurate mitosis in the tested cancer-cell context; normal/MVA cells and muscle were not tested. [Primary source](https://pubmed.ncbi.nlm.nih.gov/40425854/). |

The [three-paper comparison](vascular-enzyme-qualification.md) retains
anti-KLK8 antibody as an organ-protection research lead, K858's vascular benefit,
and a BUB1B RNA response to alglucosidase alfa in Pompe myocytes. Catalogue-listed
research reagents are included on their measured merits. None yet justifies
replacing the provisional niacin/apitegromab pair.

The [47-question follow-up reconciliation](batch15-followup-reconciliation.md) links component-level answers to the actual qualified sources. Related compounds, different experiments and source-name matches do not close a question; missing experiments remain explicit.

## Food-derived and epigenetic compounds, refreshed 28 September 2026

The [FDA food-substance inventory](food-substances/README.md) preserves 3,971 source rows and 234 lexical matches. The [literal-policy](food-substances/abstract-findings.md) and [common-name](food-substances/common-abstract-findings.md) reviews jointly annotate **234 query rows across 213 source/ID records**, with **212 saved abstracts read**. Missing PMID 18082453 receives no credit, and its [binding-source limit](fatty-acid-binding-source-limit.md) remains unresolved. An [explicit 64-record admission](food-admission-findings.md) reconciles already-read food records into outer coverage; it is not a new-paper count. Inventory membership and a name hit still do not establish efficacy, approval or formulation equivalence.

| Candidate | Evidence that changes its assessment | Decision relative to the provisional nominees |
|---|---|---|
| **Resveratrol** | Randomized exercise-associated power/torque positives, a pilot with an inconclusive walking-speed outcome, and partial toxin-exposed oocyte protection. One Copenhagen cohort shows a smaller aerobic-fitness gain but no significant added/adverse knee-endurance effect. In a separate A549 microarray, three resveratrol arrays show lower BUB1B probe signal than one control. | **Serious functional reserve, not a demonstrated restoration lead.** The array is single-control and non-inferential; rat BUBR1 staining remains unverified. No MVA superiority. The two Copenhagen papers share participants. [Original positives](resveratrol-qualification.md); [counterevidence](resveratrol-exercise-counterevidence-qualification.md); [BUB1B expression screen](resveratrol-bubr1b-qualification.md). |
| **BMS-309403** | Actual PA+BMS treatment has mean BUB1B RNA **2.290 times PA alone**, near control, alongside membrane/lipid improvement. | **Mechanistic RNA research reserve.** Gene-specific P value, BUBR1 protein and function are unqualified; schedules differ and FABP1 attribution is unresolved. [Qualification](lipid-rescue-qualification.md). |
| **Oleic acid / free EPA** | Both have measured HepaRG membrane/lipid effects; OA has a smaller descriptive BUB1B RNA shift. Separate oocyte main text reports EPA-associated maturation disruption. | **Distinct, context-dependent comparators.** EPA has no deposited liver RNA arm; the oocyte supplement’s exact exposure/native panels remain unqualified. No food/derivative equivalence or general dietary-harm inference. [Lipid](lipid-rescue-qualification.md); [oocyte](oocyte-metabolism-qualification.md) qualifications. |
| **PA-d31** | Produces the membrane/lipid challenge and lower BUB1B RNA. | **Stressor/tracer comparator**, not a beneficial nomination or ordinary-diet inference. [Qualification](lipid-rescue-qualification.md). |
| **Potassium bromate** | Adverse survival/progenitor findings in a low-BubR1 model. | **Adverse comparator.** No antioxidant rescue follows; source dose/count uncertainties remain explicit. [Qualification](bromate-qualification.md). |
| **Propylparaben** | The mouse-oocyte primary abstract reports impaired maturation and spindle/kinetochore injury at a nominal 600 µM, with persistent BUB3/BubR1 checkpoint activation. | **Common-preservative adverse-exposure comparator, not a treatment.** This is abstract-only, meiotic, and at a concentration about 51,500 times a separate human serum mean; that cross-matrix comparison is not a safety threshold. No BUB1B-MVA rescue or ordinary-use risk is established. [Qualification](propylparaben-oocyte-qualification.md). |
| **Chinese poplar propolis ethanol extract (EEP)** | A 24-hour IC50 exposure in DLBCL SU-DHL-2 cells produced a cell-cycle proteomic enrichment listing BUB1B and a qRT-PCR-reported BUB1B mRNA decrease. | **Adverse-direction, cytotoxic-cell comparator; do not nominate.** No BUBR1 function, normal-cell selectivity, chromosome-fidelity, muscle or MVA test. This regional mixture is not generic propolis, CAPE or PROPOLIS WAX. [Qualification](propolis-qualification.md). |
| **Taurine** | Actual aged-rat treatment improved chloride conductance/excitability and moved contraction threshold toward adult values. Small human exercise studies add one post-exercise eccentric-torque signal, one endurance/performance null, and caffeine-history-dependent acute torque/power findings, including adverse-direction results. | **Low-priority muscle-physiology reserve.** Human monotherapy evidence is inconsistent; the animal full paper and effect-size/control details remain access-limited. No BUBR1/MVA benefit; TauT-knockout survival is genetic depletion, not supplementation benefit. [Qualification](taurine-qualification.md). |
| **Fisetin** | Separate non-MVA mouse studies report normalized grip/holding-impulse benefits and a selective FAP-apoptosis result in vitro. A primary human-cell study reports Aurora B inhibition, reduced kinetochore BubR1 signal and forced mitotic exit/polyploid progeny at high micromolar exposure. | **Do not nominate; retain as an adverse-direction checkpoint comparator.** The cell result is not an oral-exposure or patient-harm estimate, but it challenges checkpoint safety in a BUBR1-insufficiency model. No BUB1B/MVA treatment evidence or fidelity-safe dose window. [Muscle-senescence qualification](muscle-senescence-qualification.md); [primary checkpoint study](https://pmc.ncbi.nlm.nih.gov/articles/PMC2691139/). |
| **Arachidonic acid** | In mouse oocytes, 300–400 µM impaired maturation and spindle/chromosome organization; plotted 100–200 µM comparisons were nonsignificant. | **Dose-specific adverse evidence.** Washout and partial NKAP genetic rescue are not beneficial ARA treatment. No somatic-MVA or dietary-harm inference. [Qualification](oocyte-metabolism-qualification.md). |
| **Lunasin** | Actual synthetic-peptide treatment raised BUB1B RNA 2.23-fold in a non-tumorigenic prostate line; checksum-pinned GEO reanalysis reproduces 2.229-fold in RWPE-1 and finds 1.252-fold in RWPE-2. | **Retain a food-derived restoration reserve.** GEO says its citation is missing; the accession-to-paper link is inferred, and the same likely arrays are not biological replication. BUBR1 protein, faithful division, muscle benefit and achievable intracellular exposure remain unestablished; human extract findings and clinical nulls stay visible. [Qualification](lunasin-qualification.md). |
| **Astaxanthin, oral study preparations** | A nursing-home trial reports a walking interaction (F=6.12, P<.05; 24/30 completers); a ten-person crossover reports longer cycling endurance. | **Qualified human-function reserve.** Strength/mass and separate time-trial nulls remain. Mixture strength findings are within-arm; the follow-up is the same cohort. Small samples, reporting errors and preparation differences limit inference. [Qualification](astaxanthin-functional-qualification.md). |
| **MS023** | Actual drug suppresses ccRCC xenografts and lowers BUB1B RNA/qualitative protein signal in cancer cells. | **Deprioritize restoration.** The observed direction and repair impairment weaken that rationale at tested exposures. Normal-MVA harm was not measured; retain anticancer evidence. [Qualification](ms023-qualification.md). |
| **Bromosporine** | Pancreatic-tumor monotherapy benefit and additional anti-PD-1 combination benefit. | **Retain anticancer comparator.** Broad bromodomain activity, incomplete catalytic PCAF attribution, immune nulls and absent formal synergy prevent the stronger mechanistic claims. No MVA-restoration bridge. [Qualification](bromosporine-qualification.md). |
| **GSK591 / STM2457** | GSK591-only animal effects plus cell/PDO combination effects. | **Retain cancer probes.** One PDO has no significant combination advantage over either monotherapy; animal combination and formal synergy are not demonstrated. BUB1B is a correlation, not rescue. [Qualification](prmt5-mettl3-qualification.md). |
| **Gemini-Cur** | Curcumin in a gemini surfactant formulation suppresses HCT-116 viability; carrier and free-curcumin comparators are present. BUB1B RNA falls and the protein band is weaker. | **Formulation-specific cancer-cell comparator.** The qPCR graph conflicts with prose, and supplied DEG counts differ from reported totals. Three RNA samples per arm are reported; culture independence is unclear. No checkpoint or normal-function rescue; no transfer to all curcumin/polyphenols. [Qualification](gemini-cur-qualification.md). |
| **10-HDA** | Actual 10-hydroxy-2-decenoic acid suppresses lymphoma-cell CCK-8 signal and lowers BUB1B RNA; the HSF comparator is less affected. | **In-vitro anticancer comparator.** No validated BUBR1 protein direction or successful animal efficacy; LO2 is not a valid normal-hepatocyte comparator. Solvent/dose inconsistencies remain. No royal-jelly or MVA efficacy transfer. [Qualification](10hda-qualification.md). |
| **Claramine** | Cell insulin-receptor cleavage/signaling effects in 2021; separate 2015 diabetic-mouse glucose/insulin-tolerance benefit. | **Metabolic-function reserve.** The mouse treatment is not the 2021 disease-context cohort. No BUB1B-specific trafficking lesion, BUBR1 restoration, muscle output or fidelity rescue established; no inferred pediatric harm. [Qualification](claramine-qualification.md). |
| **Nutlin-3a** | Improved movement and reduced baseline-relative grip loss in MDM2-overexpressing U87MG tumor-bearing mice. | **Tumor-associated physical-function reserve.** No absolute muscle restoration or MVA result; no combined drug–exercise arm. Regimen/group inconsistencies and tumor-context transfer remain explicit. [Qualification](nutlin-qualification.md). |
| **Selenomethionine (SM/SeMet)** | Table 6 places BUB1B RNA higher under SM than MSA in prostate cancer cells; a separate primary abstract reports reduced carboplatin-associated reporter mutation in mouse bone marrow. | **Access-limited protection lead, not demonstrated restoration.** The relative RNA result does not establish an increase over untreated control; arrays lacked replicates, deposited labels conflict, and BUBR1 protein/fidelity were not tested. The mutation report remains abstract-only, with delivery, doses, effect size and selection controls unqualified. SELECT’s separate adult L-SeMet prostate-prevention null does not test MVA or MSA. [Qualification](selenium-qualification.md). |
| **Methylseleninic acid (MSA)** | A distinct comparator in the prostate-cell expression study; the separate primary abstract also reports reduced carboplatin-associated reporter mutation for MSA. | **Access-limited protection lead.** SM greater than MSA is a between-form RNA contrast, not evidence of MSA-mediated BUBR1 restoration or loss. Earlier MSA array data and missing replication cannot resolve control-normalized rescue. Preserve the antimutagenesis claim without assigning unverified in-vivo dosing or inheriting other selenium forms’ outcomes. No muscle-output or MVA rescue is established by the reviewed sources. [Qualification](selenium-qualification.md). |
| **Pectolinarigenin** | Reduced gastric-cancer MTT signal and actual high-dose AGS-xenograft tumor-growth/weight inhibition; short-term body-weight and blood-test nulls remain bounded. | **Experimental cancer comparator.** The AGS BUB1B-assigned spot falls 1.9-fold (nominal P=.014), but spot 1147 lies near 30 kDa against 119.5 kDa theoretical mass; total BUBR1 loss is unproved. Normal-cell selectivity and MVA/fidelity rescue were not tested. Figure/table, replication and purity gaps remain; pectolinarin and plant extracts are distinct. [Qualification](pectolinarigenin-qualification.md). |
| **Capsaicin** | Local pretreatment reduced rat incision pain-like behavior with sensory denervation. | **Symptom-specific reserve.** No BUB1B-specific drug response, muscle renewal or MVA rescue. The second mouse source is abstract-only; its funding correction was read. [Qualification](capsaicin-qualification.md). |
| **Glucosamine hydrochloride plus sodium chondroitin sulfate** | A blinded crossover trial reports 23% lower CRP, its registered primary outcome, in 18 analyzed adults. | **Human inflammatory-biomarker reserve.** Exploratory plasma BUB1B antibody data do not establish intracellular restoration or muscle benefit. No monotherapy/product equivalence. [Qualification](glucosamine-chondroitin-qualification.md). |
| **Potentilla fulgens methanolic root extract (PRE)** | Fewer stomach carcinomas at day 260 (2/10 versus 10/10), plus lower premature chromosome separation during a carcinogen challenge. | **Substantive protection reserve.** Prophylactic co-exposure, small groups and source-reporting issues; no BUBR1, muscle or genotype-specific rescue. No transfer to root foods or other products. [Qualification](potentilla-qualification.md). |
| **ECGU: epicatechin, catechin, gallic acid and ursolic acid** | The four-component mixture lowered premature chromosome-separation percentages in exposed mice. | **Preparation-specific protection reserve.** No mixture tumor-histology arm or individual-component controls; all four displayed protein-marker treatment comparisons are nonsignificant. No synergy or MVA benefit established. [Qualification](potentilla-qualification.md). |

The comparison covers **309 appraisals**. [Creatine monohydrate](creatine-inflammatory-myopathy-qualification.md) now has a randomized functional benefit in adults with stable inflammatory myopathy receiving shared exercise; separate aging strength nulls and pediatric results remain part of its assessment. [Sildenafil](sildenafil-dystrophinopathy-qualification.md) did not demonstrate the primary benefits sought in two dystrophinopathy trials, and one produced an imprecise cardiac safety signal. A source-specific [Chinese poplar propolis extract](propolis-qualification.md) produced a BUB1B-down transcript signal at a cytotoxic lymphoma-cell IC50, not a restoration or muscle-benefit result. These findings strengthen compound-level comparison without establishing MVA benefit or changing the provisional nominees.

The [4 October common-compound extension](common-compound-extension.md) adds L-tyrosine, riboflavin, rutin, MK-4 and MK-7, with preparation-specific positives and counterevidence. The independently qualified [D2/inulin/HMB trials](batch11-common-compound-followup.md) add two appraisals and amend calcium-HMB without counting it twice. Controlled adult function signals remain visible alongside dose, analysis and task-test limits; none demonstrates BUB1B/MVA rescue or changes the provisional nominees. The separate outcome-first screen now accepts 2,120 exact source/ID records, with 54,097 unscreened; [batch 15](outcome-first-batch15-screen.md) passed independent reading of all available saved abstracts and all required root checks, retaining incomplete originals, nulls, alternatives and the original retraction notice. [Batch 16](outcome-first-batch16-screen.md) adds 157 available saved abstracts and three metadata-only records after source-first readings, full root annotation comparison and independent integration QA, preserving all 1,759 flags and eight unresolved cases; it adds no full-paper efficacy or ledger credit.

## Common-compound functional comparisons

The broader search has produced measured benefits worth testing against the nominees. Endpoint type determines the comparison: human muscle function, reproductive output and chromosome protection cannot be combined into one efficacy score.

| Material | Measured benefit | Competitive decision and weakness |
|---|---|---|
| [Myoki / CG-A1 trial formulation](myoki-muscle-qualification.md) | Reported 12-week controlled lean-mass gain and nominal secondary walking/grip benefits in adults with muscle atrophy. | Retain the direct estimates with inconsistent functional confidence intervals/P values and reversed flowchart arm counts. Per-protocol exclusions, shared ingredients, exposure and product status remain unresolved. In-vitro binding does not establish human target engagement or MVA benefit. |
| [LAUREL NUTRILAB lacto-vegetarian trial soup](lacto-vegetarian-soup-qualification.md) | Reported comparative 12-week GEE SPPB +0.83 points (95% CI 0.15–1.51) and chair-rise −2.25 seconds (−4.04 to −0.44). | Retain controlled functional credit with unspecified model construction, open-label/unmatched nutritional control and outcome-specific missingness. Grip, walking and body-composition comparisons were nonsignificant; recipe and retail equivalence are unresolved. No isolated-protein or MVA conclusion. |
| [Sodium butyrate](sodium-butyrate-rabbit-qualification.md) | A 14-rabbit dietary study reports higher body weight/average daily gain and quadriceps fiber number, area and density. Cecal BUB1B appears in a cell-cycle gene cluster correlated with fiber density; a separate BODYBIO COPD study has within-arm handgrip/gait signals. | **Common-compound reserve, not a BUBR1 lead.** No BUB1B-specific treatment effect, protein/checkpoint/fidelity result or muscle-force endpoint. The human capsule source lacks a recovered randomized between-arm functional contrast; feed, culture and capsule preparations are distinct. No MVA superiority. |
| [Cholecalciferol / vitamin D3](vitamin-d3-functional-qualification.md) | 2015 abstract reports a within-active-arm chair-rise increase; its controlled contrast is unverified. 2023 daily-trial primary leg-power contrast is null (P=.63). | Retain a bounded functional appraisal. The 2016 monthly active-comparator trial has an SPPB null and higher-dose falls signal; no placebo-only arm, secondary multiplicity and separate calcifediol-combination limits remain. No generalized D3 benefit/harm or MVA ranking. |
| [Study magnesium oxide](magnesium-functional-qualification.md) | Older-women SPPB +0.41 points (P=.03), chair-stand and 4-m gait benefits against control. | Mobility reserve at complete-abstract/current-registry depth. No placebo; 124/139 analyzed; strength nulls. Dose wording, product, missingness and below-RDA subgroup interaction remain unresolved. |
| [Magnosolv-Granulat magnesium/potassium](magnesium-functional-qualification.md) | CAD exercise duration 8.7 versus 7.8 minutes (P=.0075); exercise-induced chest pain lower. | Preparation-specific functional reserve. Potassium co-intervention and 73/84 efficacy denominators limit attribution. Most direct QOL contrasts are null; diarrhea worsens. The US 50-person report is an ancillary subset. |
| [ReMag magnesium chloride](magnesium-functional-qualification.md) | Controlled VO₂max and mean sprint power decreases (P=.005/.03); 10-km time and peak-power nulls (.89/.70). | Adverse-direction comparator for this brief regimen in regular exercisers. 15/22 complete, sprint n=13, biopsy n=6; literal salt-dose wording, GI reports and selective respiration endpoints prevent general magnesium conclusions. |
| [Alpha-lipoic acid](lipoic-acid-functional-qualification.md) | 17-person crossover strength-recovery interaction P=.028; NATHAN 1 examiner-rated weakness P=.045. | Functional/neuropathy reserve. Athlete acute/biomarker nulls; neuropathy primary P=.105, last-available endpoints and serious-event imbalance; larger MS walking null and proteinuria signal. Trial preparations and source depths remain distinct. |
| [L-citrulline](arginine-citrulline-functional-qualification.md) | Calf 10RM load +1.5 versus -0.3 kg, interaction P=.03, in a controlled T2D crossover. | Preliminary functional reserve. 16/22 complete; secondary outcome, grip null, no walking/durability result. Background metformin is usual care, not demonstrated synergy or the assigned DMD combination. |
| [Source-labelled chronic oral L-arginine](arginine-citrulline-functional-qualification.md) | NO-PAIN walking gain 11.5% versus placebo 28.3%, P=.024. | Decline this regimen as a positive lead; retain counterevidence. Both groups improved, so not universal deterioration. Full main/native/safety tables unavailable; short intravenous findings do not transfer. |
| [Source-labelled betaine](betaine-muscle-qualification.md) | Direct bench-force/power contrasts in a small human crossover; aged-mouse normalized grip/running and selected respiratory positives. | Functional reserve. CrossFit interaction P=.230; healthy-human/short-study, normalized-strength, treadmill-unit, genetic-control, preparation and harms limits remain. Increased proton leak is not improved efficiency. |
| [Tested nitrate-rich beetroot juice](nitrate-muscle-qualification.md) | A nine-person crossover in heart failure shows high-speed knee-extension power benefit, about 11% at 6.28 rad/s; fitted maxima are related outputs. | Functional reserve. P=.07 at the other high speed is not positive; static strength/walking/fatigue nulls, acute scope, no paired CI, registry discrepancies and pooled-cohort overlap remain. No salt/NO-donor or generic beet inheritance. |
| [Beta-alanine](beta-alanine-muscle-qualification.md) | Controlled EMG-estimated cycling fatigue-threshold benefit on matched nutritional background; adjusted grip/arm-mass ratio positive. | Human functional reserve. Absolute grip null; 44/60 complete; ratio ICC .68; paresthesia includes withdrawals. Chair-stand superiority only high-v-low, not established high-v-control; separate training trial null. |
| [Apigenin](nad-modulator-qualification.md) | Actual cellular/hepatic NAD preservation, CD38 inhibition and specified controlled mouse metabolic responses. | NAD-preservation reserve. No demonstrated SIRT2/BUBR1 rescue, muscle function or human/oral exposure bridge. AUC significance, lipid flux and in-vivo SIRT1 mediation are not established; glycosides/extracts do not inherit efficacy. |
| [Beta-lapachone](beta-lapachone-muscle-qualification.md) | Controlled aged-mouse rotarod benefits at three/ten months; normalized-grip and pole-test benefits at ten months. | Preclinical functional reserve. Grip is per body weight, which changes; survival/variable denominators limit late comparisons. Acute NAD ratio is not chronic pool expansion. Separate cellular NAD depletion and antibody-readout counterevidence remain. |
| [Sodium alpha-ketoglutarate](akg-muscle-qualification.md) | Controlled mdx grip and two treadmill positives, n=10/group, with separate ADRB2-regulation evidence. | Preclinical muscle-function reserve. Unknown received dose, eight/nine-week discrepancy, strain/size confounds and corrected-image access limits remain. ADRB2 is not BUBR1; other salts or esters do not inherit the result. |
| [Source-labelled epicatechin](epicatechin-muscle-qualification.md) | Exact primary abstract reports single-agent TUG benefit and separate exercise-combination strength advantages in older men. | Abstract-qualified functional reserve. Dose, stereochemistry, effect sizes, arm counts, multiplicity and harms are unresolved. No forced enantiomer or mixture equivalence; no single-agent strength claim. |
| [NR chloride in NEM6](nr-nemaline-qualification.md) | Preventive mitochondrial-morphology observations and selected OXPHOS-protein increases in Kbtbd13 mice. | Addendum to existing NR. Respiratory tests compare genotype within each condition, not treatment effects. No treated grip/endurance or post-treatment NAD assay; NICE remains the functional priority source. |
| [NR / nicotinamide riboside](nr-pad-qualification.md) | Assigned-group six-month walking contrast +17.6 m in 90 randomized PAD participants; one-sided P=.08 meets the supplied pilot P<.10 rule. | Upgrade to a substantive preliminary human-function comparator. Two primary tests without multiplicity correction, no demonstrated muscle NAD/BUBR1 benefit and distinct older metabolic/grip nulls limit transfer. |
| [NR plus trans-resveratrol](nr-pad-qualification.md) | Three-month secondary walking signal; six-month primary contrast +3.65 m, P=.38. | No demonstrated added benefit over NR alone; no equivalence, antagonism or resveratrol-monotherapy inference. Post-hoc adherer results do not replace assigned-group analysis. |
| [Quercetin glycosides](quercetin-glycosides-qualification.md) | With matched training, 26/30 completers show knee-strength interaction P=.036 and mean individual POST/PRE ratios 115.1% vs 105.3%. | Formulation-specific strength reserve. Functional-task/mass nulls, late registration, completer analysis and longer-trial strength nulls constrain confidence. No aglycone, D+Q or arbitrary product inheritance. The [acute 500 mg source](quercetin-acute-function-qualification.md) reports greater post-exercise torque decline at low/moderate intensity (P=.014/.025), with no significant high-intensity contrast (P=.792). No intensity interaction or chronic benefit/harm follows; exact preparation matching remains unknown. |
| [L-carnosine](carnosine-muscle-qualification.md) | Overall seven physical tests null at both visits; two nominal age/sex subgroup comparisons have favorable reported changes. | Bounded functional comparator. Active-only adherence/urinary-response filtering leaves 91/101 analyzed at final visit from 153/146 randomized. No ITT or subgroup interaction support; no zinc-carnosine/beta-alanine inheritance. |
| [Glycine + NAC (GlyNAC)](glynac-muscle-qualification.md) | Measured muscle GSH and gait/grip/chair-rise improvements during active treatment in a randomized older-adult trial; the planned final functional treatment contrast is unreported. | Retain a combination-specific metabolic/function-trajectory reserve. A separate short trial has an overall primary blood-GSH null; its favorable abstract subgroup comparison is actually within-active baseline-to-end. No ingredient, synergy or BUBR1-restoration inference. |
| [Caffeine culture](caffeine-fidelity-qualification.md) | Related full-paper PGT-A subset: 97 patients, 215 versus 242 biopsies; euploid rates 22.9% versus 10.9%, P=.002; mosaicism comparison nonsignificant. A separate somatic-cell study reports aneuploid progeny at 10 mmol/L caffeine. | Retain a selected-embryo ploidy/development reserve, not an MVA treatment lead. Historical-cycle controls and embryo selection limit causality and absolute yield; birth follow-up is treated-only and conference overlap unresolved. The somatic-cell result is high-concentration and does not establish ordinary-use harm. No oral-coffee, muscle or BUBR1 transfer. |
| [L-carnitine / levocarnitine](carnitine-muscle-qualification.md) | Twelve-person mitochondrial-myopathy crossover: constant-work cycling endurance 14 versus 11 minutes, marked P<.05; inspiratory capacity also improved. | Retain an endurance reserve. Strength, peak exercise and body composition were nonsignificant. Crossover Methods conflict with unpaired-test footnotes; carnitine levels/genotype were not measured. A separate 20-person DMD abstract reports a year-long functional null; full paper and randomization remain unverified. |
| [L-leucine](leucine-muscle-qualification.md) | The smaller trial reports nominal preservation of walking time and expiratory pressure; LACE has a primary SPPB difference of 0.1 point (95% CI -1.0 to 1.1; P=.90). | Retain mixed adult functional evidence. Only 42/50 were analyzed in the smaller trial; LACE recruited 145/440 planned. Positive subgroups do not establish effect modification. LACE’s source label does not verify L-stereochemistry. |
| [Calcium-HMB](hmb-muscle-qualification.md) | One 156-person factorial trial reports a secondary usual-gait-speed main effect of +0.06 m/s (95% CI 0.01–0.11). A distinct 2015 open-label drink trial (80 randomized, 65 completers; 1.5 g calcium-HMB in an Ensure Plus Advance drink versus no drink) had a null primary SPPB and nominal torque, 6MWT and grip-endurance secondary signals; see the [2015 source qualification](hmb-2015-drink-qualification.md). | Retain a formulation-level adult functional comparison, not an isolated HMB effect. The 2021 protocol placebo lacks HMB and calcium; broad gains belong to exercise. The 2015 drink trial was unblinded, had no placebo or matched drink, and did not adjust its exploratory secondary tests; recent malignancy and renal failure were excluded. Neither study measures BUB1B/BUBR1 or MVA outcomes. Primary mass interaction was nonsignificant, but separate HMB mass estimates for that trial remain unavailable. Companion analysis is the same cohort; durability and detailed results remain unresolved. The separate [bed-rest trial](hmb-bedrest-qualification.md) has all-evaluable mass P=.16, becoming P=.02 after one active DXA exclusion; measured functional treatment comparisons were nonpositive. Within-arm recovery is not a treatment effect; its TSI preparation, control and populations remain separate. |
| [HMB after liver transplantation](hmb-liver-transplant-qualification.md) | The 22-man randomized post-transplant study measured grip, FFMI, 6MWT and TUG; grip rose within the HMB arm. | No postbaseline between-treatment estimate is reported. Registry FFMI primary is nonpositive in the paper; one control death was excluded and only survivors analyzed. Salt/product remain unknown; do not map to calcium-HMB or infer MVA/BUB1B efficacy. |
| [SuperbaBoost krill oil](krill-oil-muscle-qualification.md) | Six-month controlled knee torque **+9.3% (95% CI 2.8–15.8)** and grip **+10.9% (8.3–13.6)** in healthy older adults. | Retain a substantive preparation-specific strength comparator. Walking/chair-rise, whole-body mass and QoL were nonpositive; 94/102 randomized participants were analyzed, with late registration and incomplete safety reporting. The subgroup paper is the same cohort. No generic fish-oil equivalence, MVA rescue or nominee superiority. |
| [Phenylcapsaicin / aXivite study preparation](phenylcapsaicin-function-qualification.md) | A 2.5 mg acute crossover condition reports a CMJ positive and selected repetition-velocity positives in trained men. | Retain an acute performance comparator. Corrected velocity-pairwise comparisons, isometric force/RFD, EMG and total volume were nonpositive. Analysis n, carryover and supplement reporting defects remain unresolved; no established chronic, pediatric or MVA benefit or nominee change. |
| [Creatine monohydrate](creatine-muscle-qualification.md) | Three earlier DMD abstracts retain strength/energy positives and strength/task/scale nulls. A [2003 DMD/BMD crossover](creatine2003-dystrophinopathy-qualification.md) reports placebo-versus-creatine elbow-strength, fatigue and stiffness positives. | Prioritize a substantive compensation comparison. This is more direct pediatric strength evidence than niacin’s open-label functional context, while apitegromab retains stronger documented SMA motor evidence. The earlier three DMD mains remain unread. The 2003 full main shows functional persistence through washout without a period/sequence-adjusted contrast; effect precision, multiplicity and safety limits remain. |
| [Earlier glutamine evidence](creatine-muscle-qualification.md) and [four-month L-glutamine trial](glutamine-dmd-qualification.md) | The separate CINRG arm did not establish manual/quantitative strength benefit. The later 30-boy crossover did not demonstrate an overall walking benefit, but reported a nominal treatment benefit in an unplanned subgroup of five corticosteroid-treated boys. | The subgroup needs confirmation and does not establish a steroid interaction. The later trial also had less fat-free-mass gain and greater fat-percentage increase, with measurement/order limits. Earlier CINRG secondary outcomes, precise contrasts and product identity remain unresolved; preparations and populations are not interchangeable. |
| [L-citrulline + metformin hydrochloride](citrulline-metformin-qualification.md) | At 13 weeks, nominal strength +18.3 N (95% CI 3.0–33.5) and distal-function +2.9 points (0.1–5.8); MRI shows slower worsening at 26 weeks. | Retain a combination-specific functional reserve. Final primary P=.09, final strength/walking nulls, subgroup interaction P=.67 and multiplicity constrain confirmation. There were 43 complete primary outcomes, not 45. Neither component inherits the combination result. |
| [Resveratrol](resveratrol-exercise-counterevidence-qualification.md) | Separate randomized muscle-power/torque positives remain. One shared Copenhagen training cohort shows a smaller VO2max gain, with gains in both arms and no significant drug effect on knee-extensor endurance. | Retain serious functional comparison. Do not count the two Copenhagen publications as independent replications or infer treatment differences from within-arm stars. The rat BUBR1 paper remains abstract-only; a separate one-control/three-treatment A549 array shows a descriptive downward BUB1B signal without inferential evidence. |
| [Icariin](icariin-aging-qualification.md) | Exact abstract: 100 mg/kg daily for 15 days in 24-month mice, reported rotarod benefit and BUB1b among increased markers. Direct dosing and fecal transfer are different interventions. | Prioritize assay/exposure clarification. RNA versus protein, tissue, biological n, effect size and formulation are unresolved. Medication rank is unknown; missing full text is not negative efficacy. |
| [TG101209](tg101209-lung-qualification.md) | Early post-LPS mouse treatment improves injury and two of six respiratory readouts; survival curve direction is favorable. | Retain lung comparator plus separate thermal probe. Four respiratory nulls, underdescribed acquisition, unspecified survival test and TG-only death of unknown cause remain. No BUB1B assay or human-exposure bridge in this source. |
| [Vitamin K2](vitamin-k2-neonatal-qualification.md) | Pretreatment-associated behavioral benefit, higher Bub1b mRNA and BUB1B-labeled tissue fluorescence in injured neonatal mouse NAc; IF n=3 mice/group. | Prioritize exact-regimen and assay follow-up. This is a direct molecular comparison beyond hub membership, but no per-cell functional BUBR1 or causal dependence is established. Subtype, dose, route and antibody methods remain unresolved. |
| [Spermidine](spermidine-reproduction-qualification.md) | Mouse meiotic aneuploidy decreases after injection, oral and culture interventions; reproductive outcomes also improve. | Retain as a preclinical fidelity/reproduction comparator. Full Methods, clustering and some exposure/denominator mappings remain unresolved. Bub1b RNA is lower with Q=.1013, not an FDR-significant response or protein-supply rescue. |
| [CoQ10](coq10-reproduction-qualification.md) | Aged-mouse follicle, spindle-alignment and litter-size benefits; separate Pdss2-model partial rescue. | Retain the functional reserve. Injection, early-life oral rescue and human oral/culture studies are separate. Bub1b RNA is nonpositive; the small oral human trial is null and the IVM main remains inaccessible. |
| [Mitoquinone](mitoquinone-reproduction-qualification.md) | Improved mouse blastocyst development/hatching and ICM fraction after high-oxygen oocyte culture. | Retain a distinct developmental comparator. Maturation/fertilization and low-oxygen comparisons are nonpositive. No current-paper BUB1B or nuclear-chromosome endpoint; the human arm is untreated. Salt, oral exposure and ordinary-CoQ10 equivalence are unestablished. |
| [Urolithin A](urolithin-human-qualification.md) | Randomized human fatigue-resistance and hamstring-torque secondary benefits. | Retain as an exploratory muscle-function competitor. Primary outcomes were null; the older-adult endurance advantage was not significant at four months. No BUBR1/MVA result, pediatric evidence or demonstrated superiority. |
| [Putrescine dihydrochloride](putrescine-reproduction-qualification.md) | Less embryo resorption in two mouse strains and more blastocyst cells. | Retain as a reproductive-function reserve. Aggregate live pups increased, but litter-rate and litter-size comparisons were nonsignificant; males were co-exposed and embryo analyses did not account for maternal clustering. The separate 2013 aneuploidy source remains abstract-only. |
| [L-ascorbic acid](ascorbate-oocyte-qualification.md) | 500 µM during maturation increased normal 20-chromosome outcomes from 60.0% to 84.6% and reduced PSSC from 26.0% to 2.6% in Sod1-deficient oocytes. | Retain as a distinct chromosome-protection comparator, reusing the NAC source. No treatment-induced BUBR1 assay or downstream developmental outcome; the maturation denominator remains unclear. Do not transfer to ascorbate 2-phosphate or oral products. |

The astaxanthin refinement credits controlled performance findings without turning mixture-only, within-arm or repeated-cohort observations into independent ingredient effects. Its functional case is stronger than the earlier composite-culture evidence alone suggested. It remains subject to the same exposure, useful-function, renewal and chromosome-fidelity requirements as the nominees.

The separate [MAX-EPA access note](maxepa-ra-source-note.md) preserves abstract-reported RA fatigue-onset and tender-joint estimates, with damaged comparator/significance wording, unverified analysis denominators and persistence beyond the four-week washout. The original main/native outcomes remain unread. It adds no decision or verified strength benefit and transfers no efficacy to free EPA or Lovaza.


The [food-name review](food-substances/common-abstract-findings.md) retains 212 available abstracts across 213 source IDs. [Batch15](batch15-revalidation-findings.md) adds the final 532 saved strings: **3,598 accepted revalidations, 5,759 combined outer source/ID records and zero pending in the original selection**. This closes that queue, not the broader search or primary-source follow-up. The earlier 2,161 annotations were not independently re-audited here. Root checked 16 source/annotation pairs in the final batch; versions are not independent studies and the 143 initially empty fields retain separate recovery statuses.

The separate [NIH DSLD ingredient inventory](dsld-ingredients/README.md) preserves **6,467 source groups, 78,788 synonym cells and 85,255 total name/synonym cells**. Its **41,496 lexical matches, including 1,077 unflagged matches, provide no efficacy assessment** and confer no reading or appraisal credit. A separate first pass annotates six rows across four previously read abstracts, without new unique credit. Groups, label terms and matches are not unique drugs, verified chemical equivalents or additions to the main entity denominator. API version 9.5.0 (May 2026) and index-name suffix `2025-09-25n` are distinct source descriptors, not current-market or record-update guarantees.

## Research probes: two primary follow-ups, 23 September 2026

The [SGC inventory](sgc-probes/README.md) preserves 249 probe labels and their
controls beyond clinical-development catalogs. All seven exact-hit abstracts
were read, with one false BSP acronym match retained as such. This expands
discovery; it does not establish those probes as treatments or unique new drugs.

| Candidate | New evidence | Competitive decision |
|---|---|---|
| **GSK620** | The published 2025 GBM study reports longer survival after actual drug treatment in a small mouse xenograft experiment. The earlier preprint reported no survival benefit with a different regimen. | Upgrade to an experimental anticancer comparator. No BUBR1, MVA muscle, fidelity or established normal-tissue safety result; [version and endpoint qualification](gsk620-gbm-qualification.md). |
| **GSK778 / ipatasertib** | Separate glioblastoma proliferation and AKT/chromatin experiments. | Add distinct cell/mechanism probes; neither inherits GSK620 survival or normal-cell selectivity. |
| **GSK343 / DZNep** | Ordinary-oocyte methylation perturbation, distinct from genetic EZH2 effects on BubR1. | Retain mechanism probes. No drug-mediated restoration; rare GSK343 polar-body abnormalities and limited functional-rescue evidence remain explicit in the [primary assessment](ezh2-oocyte-qualification.md). |

That earlier follow-up added four appraisals and refined two BET entries; the other 150 preceding objects were unchanged. **At that historical checkpoint, 2,516 strings remained pending**; the probe inventory and seven overlapping readings added no outer credit. Niacin and apitegromab remain provisional, unproved in MVA.

## The same comparison for leaders and challengers

The separate [Broad Hub crosscheck](broad-hub-review.md) screens another catalog's
7,540 overlapping source names, without inflating the main denominator. Its
2,148 lexical mentions are discovery pointers; an unmapped name is not a new
medicine, and a co-mention is not a beneficial intervention.

We compare mechanism relevance, actual-drug functional evidence, transfer to this
genotype and tissue, exposure/eligibility, and harms. No numerical efficacy or
weighted winner score is inferred from missing experiments. A challenger does not
have to demonstrate actual-allele rescue before being considered when neither
current candidate has done so. Every candidate faces the same eventual requirement:
greater absolute muscle function with preserved renewal and chromosome fidelity.

| Candidate or route | Strongest relevant evidence | Load-bearing gap or counterevidence | Research decision |
|---|---|---|---|
| **Niacin** | Human muscle NAD engagement; separate NMN experiments connect NAD availability to BUBR1 abundance. | These are different administered molecules. No niacin-mediated BUBR1 or MVA rescue; the selected BubR1-hypomorphic mouse survival benefit came from genetic SIRT2 overexpression, not NMN or niacin. Healthy treated controls also gained strength in the unblinded niacin study. Pediatric prescription safety/effectiveness is unestablished. | **Retain restoration lead**, conditional on usable BUBR1 rescue. Niacin has human muscle NAD-engagement evidence, but its BUBR1 mechanism remains an indirect, testable bridge. |
| **NMN (distinct NAD-precursor challenger)** | [North et al.](https://pmc.ncbi.nlm.nih.gov/articles/PMC4194088/) report NMN-associated BubR1 abundance increases in aged wild-type mice and SIRT2-dependent induction in MEFs; [Kang et al.](https://pmc.ncbi.nlm.nih.gov/articles/PMC6170003/) report improved mitotic completion in NQO1-depleted cancer cells. Three qualified human trial datasets are mixed: a short treadmill-walking signal, analysis-limited gait/chair signals, and a longer physical-function null despite blood NAD increase. | Mouse exposures and aging/NQO1 models do not establish restoration of the patient's alleles; Kang did not establish BUBR1 mediation or daughter-cell fidelity. Human trials measured circulating NAD, not muscle BUBR1; there is no MVA or pediatric result. The trials are not head-to-head with niacin and differ in product, population and endpoint. Supplement-product eligibility is not therapeutic approval. | **Strongest direct NAD-precursor-to-BubR1 abundance challenger to niacin; keep the precursors separate in the comparison.** NMN is more direct for this molecular endpoint, while niacin has human muscle NAD-engagement evidence. Neither demonstrates MVA rescue or superiority. [Human qualification](nmn-human-functional-qualification.md); [2022 trial qualification](nmn-igarashi2022-qualification.md); [route comparison](../../reports/appendices/track2-route-decisions.md). |
| **Vitamin K2** | Actual-compound Bub1b RNA and BUB1B-associated tissue fluorescence recovery, alongside preventive behavioral benefit in injured neonatal mice. | Exact subtype/dose/route and assay specificity remain unresolved. Tissue composition can affect RNA/IF; per-cell functional BubR1 and causal dependence were not established. | **Priority molecular follow-up.** More direct drug-associated BUB1B evidence than niacin’s NMN/genetic-SIRT2 bridge, but no defined comparable exposure or muscle-function result yet. Niacin retains separate human muscle NAD engagement. [Qualification](vitamin-k2-neonatal-qualification.md). |
| **BMS-309403** | Actual-compound BUB1B transcript recovery in PA-challenged HepaRG cells: mean 2.290 times PA, near control, plus membrane/lipid effects. | No gene-specific significance, BUBR1 protein or functional rescue; different exposure schedules and unresolved cellular target attribution. No clinical exposure bridge established. | **Retain a mechanistic RNA research reserve.** The compound-transcript observation is more direct than niacin's cross-intervention BUBR1 bridge; niacin separately has human muscle NAD engagement and medicine/exposure context. Neither establishes genotype-specific rescue or superiority. |
| **Apitegromab** | Randomized SMA motor-function evidence; approved in the US for SMA from age two with SMN2-targeted treatment. It blocks myostatin activation and can support muscle independently of correcting the causal gene. | No BUB1B/MVA experiment; benefit in treated SMA does not establish benefit in developmental MVA muscle. Fractures are a labeled risk; lean-mass retention elsewhere is not functional rescue. | **Adopt as the primary downstream comparator**, tested separately from niacin. It replaces everolimus in the two-medication muscle-benefit proposal; niacin retains the distinct restoration hypothesis. |
| **Creatine monohydrate** | Selected DMD grip/manual-strength and muscle-energy findings, plus [2003 DMD/BMD](creatine2003-dystrophinopathy-qualification.md) placebo-versus-creatine strength/fatigue contrasts. | Six-month strength-null trial; task/functional-scale nulls; the earlier three mains remain unread. The 2003 trial has persistent functional carryover and no reported period/sequence adjustment; magnitude and safety remain bounded. No BUB1B/MVA result. | **Priority compensation comparator.** Challenges niacin on direct strength evidence, while the restoration hypothesis and apitegromab’s SMA motor evidence remain distinct. [Qualification](creatine-muscle-qualification.md). |
| **Everolimus** | Known mTORC1 pharmacology and pediatric experience in other diseases. | The two-carrier-per-genotype blot does not establish excess pathway activity; the RNA reanalysis did not corroborate an mTORC1 signal. Context-specific BUBR1 lowering and growth/immune liabilities matter. No MVA functional rescue. | **Mechanism probe, not the leading downstream benefit hypothesis.** Reopen priority if relevant excess and causal functional benefit are demonstrated. |
| **AZD1152 / barasertib** | Direct drug treatment in BubR1-hypomorphic mice: a conference abstract reports longer survival. This is more direct same-gene drug evidence than niacin's chain. | Conference-only reporting; sarcopenia and other monitored age-related phenotypes did not improve. No eligible approved product established. | **New named Aurora-B compensation reserve**, especially for cardiac biology. Do not erase the result by treating every checkpoint-related inhibitor as mechanistically equivalent. |
| **FRZB/sFRP3 reduction** | Same-gene genetic rescue of selected developmental/neural phenotypes. | Genetic intervention, no qualified drug implementation or muscle-function result. Broad Wnt activation is not the same intervention. | **New causal target opportunity**, outside the current existing-medicine nomination. |
| **PAK2 reduction** | Same-gene genetic lifespan/senescence benefit. | Physical function remained unchanged; no drug reproduced the genetic intervention. | **New mechanism reserve**, lower priority for muscle benefit. |
| **Decitabine** | Raised BUBR1 abundance in selected non-MVA promoter-repression/cell-aging contexts. | No relevant promoter repression demonstrated here; broad epigenetic effects, context dependence and no actual-mutant functional rescue. | **Transcription reserve**, reopened by an observed reversible supply defect. |
| **UPCP / FTI-277 / lonafarnib analogy** | UPCP countered progerin-associated BUBR1 dysfunction in HGPS models; FTI-277 was a distinct cell comparator. | Progerin-driven disease is a different lesion. UPCP is experimental; FTI-277 evidence cannot be assigned to approved lonafarnib. | **New mechanistic precedent**, not an eligible MVA lead on current evidence. |
| **Griseofulvin** | A 2026 primary report describes Mad1/BubR1 binding; it is an approved antifungal. | Reported mitotic disruption and tumor-cell death, not restoration. Binding-assay details were not independently available. | **Reported direct binder; decline muscle-restoration lead.** Target binding is not beneficial target action. |
| **Dasatinib / ceritinib direct-target assay records** | Retrieved BUB1B biochemical annotations: respectively >75% residual activity at 1 µM and IC50 13.08 µM. | Limited/weak inhibitory observations; neither supplies mutant rescue. Dasatinib's senolytic hypothesis is a separate rationale. | **Do not promote on target-database presence.** Keep the previously defined dasatinib reserve separate. |
| **BAY-320 / BAY1816032 / 2OH-BNPP1** | Original studies establish BUB1-directed pharmacology. A later source separately annotates a BAY1816032 BUB1B thermal signal. | BUB1 is a different gene/protein; known BUB1 activity and a thermal observation do not establish selective functional BUBR1 inhibition or rescue. | **Keep target identities and assay scopes separate.** See the [source review](target-assay-review.md). |

Sources and detailed limitations: [current niacin/apitegromab evidence](../../reports/appendices/track2-evidence-pipeline.md),
[apitegromab primary-source review](apitegromab-review.md),
[same-gene and restoration literature](literature-review.md), and
[direct-target source checks](appraisal.md). The proposed ordering can change
after experiments. It is not a claim that niacin is more effective than apitegromab.

## Recent approvals and additional routes

The [FDA 2026 novel-approval list](https://www.fda.gov/drugs/novel-drug-approvals-fda/novel-drug-approvals-2026)
adds a current regulatory check to older catalog releases. Forty product entries
were retained and their names screened against the complete saved gene corpus.
Thirty-six cross-reference a catalog entity; two combinations map to their
separate ingredients without merging product identity. Daraxonrasib and
milsaperidone remain additional unmatched product entries. No specific alias
co-mention was found for those two in this title/abstract corpus; that is unknown
efficacy, not a negative experiment. The check does not cover every worldwide
approval, supplemental indication, CBER biologic or product formulation.

| Additional candidate | Why considered | Why it does not presently replace the research lead |
|---|---|---|
| **Brepocitinib** | New approval and randomized functional benefit in adult inflammatory dermatomyositis. | This is drug-specific human evidence, but no JAK-dependent inflammatory cause of this BUB1B muscle phenotype is established. It belongs beside the JAK/secretory reserve, not as proof that any myopathy responds. [VALOR](https://pubmed.ncbi.nlm.nih.gov/41910335/). |
| **Garetosmab** | Approved activin-A blockade for FOP offers a neighboring muscle/bone signaling intervention. | The demonstrated benefit prevents ectopic bone in a different receptor disorder; it is not a myostatin or BUBR1 rescue experiment. Skin/soft-tissue infection and nosebleeding warnings also preclude assuming harmless muscle support. [FDA assessment](https://www.fda.gov/drugs/news-events-human-drugs/fda-approves-second-treatment-fibrodysplasia-ossificans-progressiva). |
| **Gedatolisib** | FDA-approved PI3K/mTOR inhibitor; a preprint also shows prevention of cell-enlargement-associated segregation errors during palbociclib arrest. | **Upgrade to a conditional cell-size/fidelity comparator.** The washout experiment is not BUBR1 restoration or muscle rescue, and dual PI3K/mTOR effects cannot be assigned to everolimus. Approval is for adult breast-cancer combinations; pediatric safety is unestablished. [Primary and label qualification](clearance-and-fidelity.md#gedatolisib-a-stronger-conditional-experiment-not-general-mtor-rescue). |
| **Icariin** | Reported rotarod benefit and BUB1b upregulation among markers in 24-month aged mice after 100 mg/kg daily for 15 days; exact abstract only. | **Priority assay/exposure clarification.** Assay type/tissue/protein relevance, full Methods and exact formulation remain unresolved. Direct dosing is distinct from fecal transfer. [Qualification](icariin-aging-qualification.md). |
| **CAPE** | Actual treatment improved tau-model fly climbing and scopolamine-mouse object discrimination; memory/crawling nulls remain explicit. | **Neurological-function reserve.** The differentiation result is BUB1B RNA by RT-PCR, not BUBR1 protein loss. Formulation/control and reporting conflicts remain; no MVA or muscle rescue, and CAPE is not caffeic acid. [Qualification](cape-neurological-qualification.md). |
| **NAC / ascorbate** | Reduced segregation errors in oxidatively stressed Sod1-deficient oocytes, extending the redox reserve beyond a generic antioxidant argument. | A different gene, meiotic tissue and exposure context; BUBR1-mediated MVA muscle rescue remains unproved. [Primary study](https://pubmed.ncbi.nlm.nih.gov/39845481/). |

## Interventions recovered beyond the catalog-name filter

The additional [catalog-independent review](catalog-independent-review.md)
retains every one of 1,460 gene-query records, with machine priority and actual
manual-review depth separately recorded. Seven newly appraised primary studies
and a deeper review of the already cited NAC/ascorbate study add the following
comparisons. This is a bounded sensitivity pass, not a systematic review of every
record or proof that no other candidate exists.

| Route | Relevant administered-intervention result | Competitive decision and missing bridge |
|---|---|---|
| **7,8-DHF / BDNF signaling** | 7,8-DHF reduced aneuploidy in aged mouse oocytes. Secretome and recombinant BDNF had related but distinct timing/localization assays. | **Admit an experimental chromosome-fidelity comparator.** No actual BUB1B-allele, muscle, clinical-exposure or qualified approved-product bridge; do not assign all secretome endpoints to 7,8-DHF. |
| **Amla / Phyllanthus emblica fruit extract** | One 2016 NCM460 study reports higher BubR1 mRNA and fewer mitotic/genomic abnormalities; two same-group papers add COLO320 CIN/apoptosis and Colo205 chemotherapy-growth context. Normal-cell arrest/apoptosis and colony suppression also occur in the chemotherapy study. | **High-priority laboratory comparator among reviewed consumer preparations.** One BubR1 transcript study plus two context studies is not independent replication, protein rescue or a matched tumor-selectivity result. MVA cells might respond adversely; exposure, preparation identity, absolute output and progenitor renewal require qualification. [Full source comparison](catalog-independent-review.md#amla--phyllanthus-emblica-aqueous-fruit-extract--chromosome-endpoints-and-cell-state-risk). |
| **Melatonin** | Improved maturation after oocyte cryopreservation, at one concentration; stage-specific Bubr1 marker recovery. | **Contextual reserve.** Not chromosome-number or mutant-muscle rescue; other tested concentrations impaired maturation. |
| **EUK-207** | Preserved hearing in SAMP8 mice and protected cochlear explants. | **Functional antioxidant reserve.** Different lesion/tissue; drug-mediated BUBR1 restoration and eligible human exposure unestablished. |
| **Folic acid** | Less induced apoptosis in bovine mammary cells; BUB1B network association. | **Low priority.** Cow gene differences were nonsignificant; surviving cells do not establish correct division or productive muscle renewal. |
| **Lithium chloride** | Spindle/pronuclear benefit after Axin1 depletion in oocytes. | **Contextual mechanism evidence.** Not pharmacological reproduction of FRZB reduction in BubR1 mice; clinical lithium equivalence not shown. |
| **Pifithrin-alpha** | Primary abstract reports relief of chromium-associated arrest and BubR1 marker reduction. | **Decline restoration lead.** Full treatment details unread; arrest relief does not establish chromosome repair, and same-gene p53 counterevidence remains. |

Each row's primary citations, dose/model details and evidence limits are in the
[intervention review](catalog-independent-review.md). NAC/ascorbate's chromosome
outcomes strengthen its existing reserve without establishing MVA muscle rescue.
The [supplemental PubMed appraisal](pubmed-supplement-review.md) also qualifies
KIF18A tumor killing as checkpoint- and schedule-dependent, not a generic
aneuploid-cell vulnerability or normal-tissue restoration strategy. Preprints and
journal versions are linked, not added as independent support. **The elected
niacin/apitegromab research comparison remains unchanged.**

## New routes outside the gene-in-abstract filter

The [433-record outer review](outer-corpus-findings.md) adds actual administered
interventions that a gene-title/abstract gate can miss: ConA-associated oocyte
chromosome/developmental benefit, chaetocin in progerin disease, hesperetin/CISD2,
HDAC6 inhibitors after a TUBB8 perturbation, and conditional IAA, liraglutide and
calcitriol routes. These are original source-level appraisals with different
models and endpoints, not automatically equivalent medicines. Primary follow-up elevates **TM5484/PAI-1** for an actual mouse contraction
endpoint and **hesperetin/CISD2** for motor performance, while preserving the
absence of a clear later-treatment force benefit and small rotarod denominator. TM5441 and
genetic PAI-1 outcomes stay separate from TM5484. The review explicitly
left 5,469 outer records outside those three selections. The subsequent
[unfiltered pass](unfiltered-findings.md) reads another 384 complete abstracts,
bringing the historical subtotal to 817 records with 4,942 originally saved
abstracts unread at that stage. Separately, missing-abstract recovery reads 18 recovered
abstracts and 53 short available bodies, including 14 availability notices and
one keyword index. These are distinct reading depths, not full-paper coverage.

The unfiltered pass recovers actual nicotinic-acid protection in toxin-exposed
human oocytes. It strengthens the compound-specific cellular precedent without
showing SIRT2, drug-induced BUBR1 restoration or MVA muscle benefit. The [nine-question primary comparison](unfiltered-primary-qualification.md) now qualifies SH1/MZ242, NAC, berberine, HMGN1/CD4, collagen matrices, TTK inhibition, jasplakinolide, Bub3 crotonylation and sFRP3. HMGN1/CD4 earns real tumor/immune function, collagen culture support earns hormone-secretion function, and jasplakinolide earns osteogenic differentiation evidence. CFI402257 has a low-dose survivor-population genomic result with a critical selection uncertainty. None currently displaces the muscle-focused comparison. This follows the measured endpoints and intervention/model differences, not a special exemption for nominees lacking MVA efficacy. Genetic chromosome-fidelity leads and unreviewed literature remain open; sFRP3 is a rediscovery, not new replication.

PLK1 is also a more concrete opportunity than its earlier genetic-only summary
suggested: BI2536 partially restored patient-cell ciliogenesis according to the
primary paper, **with data not shown and an unresolved patient regimen**.
Centrosome correction remains RNAi; faithful drug-treated divisions remain
unestablished. The [qualification](lead-qualification.md) preserves both the
positive observation and the opposing mitotic mechanism. Bletilla's bone
finding remains a mixture reserve with unresolved identity/mediation.

## What remains unknown

The [primary-source qualification](lead-qualification.md) now **raises Aurora-B
balancing as an experimental functional comparator**: attachment rescue after
BUBR1 depletion is real drug evidence, but is not completed faithful division.
Geraniin retains its cellular signal with an unresolved parent-exposure bridge;
TG101209 remains a thermal probe with competing pharmacology; its [separate lung qualification](tg101209-lung-qualification.md) adds bounded functional evidence without validating BUB1B restoration. KP372-1 and
okadaic acid receive explicit contextual/reagent decisions rather than being
mistaken for unnamed BUBR1-restoring drugs. The comparison applies the same
actual-allele evidence gap to nominees and challengers.

The deeper [complete-saved-abstract review](abstract-review-findings.md) adds
**geraniin** as a chromosome-fidelity comparator to qualify, **TG101209** as a
protein-stability probe, **Bletilla extract** as a mixture-level reserve,
**PLK1 reduction** as a same-disease target opportunity with a limited drug precedent, and contextual
GW5074/B7E2 pharmacology. The comparison table gives the positive finding and
missing bridge for each. These are further lines from the broad search, so its
“no further leads” condition has not been met. Niacin/apitegromab remain the
nominated research pair, not proven superior treatments.

The [all-target assay review](target-assay-review.md) also identifies four
residual-activity values mislabeled as inhibition, including two swapped
compound/concentration assignments. Original records are retained beside the
source-based interpretation; target-database membership cannot decide efficacy.

The [census](README.md) enumerates public clinical-development and regulator-linked
records, plus additional literature-derived compounds. It cannot certify “every
drug in existence”: unpublished compounds, some national products, changing
approvals and unindexed experiments have no complete public denominator. Salts,
formulations, combinations and unresolved identities further prevent treating
the row count as a count of unique medicines.

Every catalog entry receives a screening/evidence state, not a fabricated
efficacy estimate. Only the explicitly appraised candidates have a manually
reasoned competitiveness decision. Co-mention, biochemical inhibition, genetic
rescue, animal function, human target engagement and clinical efficacy are
different evidence types. Thousands of unknown rows do not become excluded drugs.

## Experimental next step and delivery status

The new comparison is incorporated into the written proposal and revised narration. For apitegromab, verify target availability and actual-drug engagement, then test absolute contractile output, renewal, chromosome fidelity and matched tumor/nonmalignant responses. Elevated baseline myostatin is not a necessary condition for compensation. Niacin retains its own NAD/SIRT2/BUBR1 mediation tests. Test single agents first; no combination benefit or pediatric MVA regimen is inferred. The [pipeline](../../reports/appendices/track2-evidence-pipeline.md) defines drug-appropriate controls and the four-claim confirmation family, with everolimus outside it unless prospectively promoted.

The final V4 eight-slide Skylar movie measures 180 seconds: 166.64 seconds of speech and 13.36 seconds of transitions. All slides and sampled encoded frames were visually checked; V4 retains the V3 narration and captions. The niacin/apitegromab movie is **verified as V3 at [the existing Vimeo URL](https://vimeo.com/1228990028)**; V4 publication and Track 2 portal submission remain pending. The owner interface reported optimization complete and enabled English captions for V3. Signed-out playback at 01:19 showed the apitegromab slide with the trial result and age/background-treatment qualifications alongside the matching caption. This was a visual playback/caption check, not full independent listening. V2 remains in private version history.

The historical 77/100 review assessed the niacin/everolimus package; it is not a score for this adopted scientific revision or the replacement movie.

## Translation qualification

The [primary comparison](translation-qualification.md) identifies the actual
interventions behind additional rescue claims. TM5614 has adult clinical exposure
and ongoing phase III development, with Japanese unapproved status; it is not
the TM5484 muscle compound. ConA has measured chromosome-number benefit, while
tubacin also harms a control maturation outcome. Centromere rescue requires
TP53 siRNA plus 2-PCPA; the liver-function result belongs to a five-agent regimen.
These distinctions preserve real positive findings without promoting class or
mixture results to a single approved MVA medicine.

The [clearance and fidelity comparison](clearance-and-fidelity.md) upgrades
gedatolisib from a pathway-adjacent medicine to a conditional cell-size experiment
and okadaic acid from localization evidence to partial live-division rescue.
PZ15227 and DT2216 remain different compounds: equal survivor reseeding limits
the former's growth claim, while the latter has human platelet toxicity and a
suspended pediatric combination trial. SB-431542, EPZ-5676 and a nucleoside
mixture receive explicit positive findings and reasons for remaining reserves.
The [intervention check](intervention-qualification.md) qualifies all fourteen
follow-ups flagged by the final ranked selection. BI2536's reduction of
post-cytokinesis defects strengthens a conditional route, while control-cell
arrest and distinct volasertib tumor findings narrow it. BMP4 differentiation,
combination-RNA heart function and clone-specific anti-PD-1 survival are real
positive results with different intervention and tissue boundaries. Mirdametinib
is an implemented existing-active-ingredient probe; SHP099 supplies the separate
mouse metabolic benefit. Kv10.1 knockdown, MAD2 restoration and CDC20 reduction
cannot be relabeled drug rescue. The alternatives remain substantive; no
absence-of-further-leads claim or new submission follows.

## Muscle benefit recovered by the next unfiltered pass

The [additional 576 assessments](next576-findings.md) brought outer coverage at that stage to 1,393 source/ID records, leaving 4,366 originally saved abstracts unread. The [primary comparison](next576-primary-qualification.md) admits **ursolic acid as a substantive functional reserve**: its mouse grip and absolute-force benefit and small randomized human handgrip signal deserve credit alongside the separate human null. It challenges niacin on empirical muscle benefit; niacin is retained for the distinct restoration hypothesis. Apitegromab retains stronger pediatric disease-associated functional evidence. None has demonstrated MVA efficacy, and ursolic-acid product/exposure eligibility remains unresolved.

**MG132** has separate alignment and ex vivo muscle-proteolysis benefits, without demonstrated completed faithful division or contractile improvement in the inspected studies. **DHMMF** has RACK1-associated tumor-cell activity, with phospho-BUBR1 rising during damage. These endpoints do not justify muscle-restoration election. The same primary comparison upgrades the existing **bortezomib** entry: bortezomib plus humanin prevented neonatal-denervation contractures, but mortality and reduced normally innervated muscle growth keep it a combination-specific reserve. No active-force or monotherapy benefit is established. The ledger adds three appraisals and revises this existing entry, leaving 96 at that stage; these are not 96 approved medicines or closed efficacy questions. Further source flags and unread literature remain; publication and submission remain pending.

## Exact intervention and endpoint follow-up

The [three-source check](intervention-identity-followup.md) raised the ledger at that stage to 99 appraisals without adding abstract records. It identifies DETA/NO and PROLI/NO as distinct vascular interventions, resolves the behavioral claim to flavopiridol while retaining full-text access limits, and qualifies GSK-923295 as a source-specific adverse structural comparator. The existing STLC route now separates partial frog-embryo bipolarity recovery from human-cell monopolar prevalence and control harm. None supplies a stronger current muscle nomination; the reported brain and vascular findings are preserved at their actual evidence depth.


## A current non-US inventory exposes remaining identity work

The [EMA direct-feed comparison](ema-coverage-review.md) retains 1,568 authorised human product records separately from the 15,357-entity census. There are 180 whole-field name mismatches, including combinations and descriptions. Official pages confirm garadacimab, zapomeran and etuvetidigene autotemcel examples without exact matches in the compared layers; these are unresolved identity candidates, not new BUB1B leads. Kygevvi components and dorocubicel already have catalog entries. The supplement separates initial authorisation from later decisions and recommendations, preserves a source timestamp discrepancy, and leaves efficacy unassessed. These gaps are another reason not to claim enumeration or evaluation of every drug.


## NAD reference evidence and three newly qualified products

The [NQO1 primary follow-up](nqo1-sirt2-followup.md) adds a reported functional
cell-division result for NMN in NQO1-depleted cancer cells. It strengthens the
reference experiment while leaving BUBR1 mediation, faithful daughters and
muscle output unestablished. The opposing dicoumarol result illustrates why
precursor support and NQO1 inhibition cannot be treated as one drug direction.

The [recovered EMA identities](ema-identity-followup.md) supply three product
assessments: garadacimab, zapomeran and etuvetidigene autotemcel. Their actual
clinical evidence concerns HAE, COVID-19 and WAS, respectively. Muscle injection
or a gene-therapy platform does not establish muscle compensation or BUB1B
restoration. The ledger at that stage has **103 appraisals**; the niacin/apitegromab research
comparison is unchanged, and efficacy in MVA remains unproved.


The [additional 256 saved entries](next256-findings.md) bring outer coverage to
1,649 source/ID records, with 4,110 saved abstracts still unread. Their strongest
new other-tissue drug finding receives [primary qualification](mebendazole-qualification.md):
mebendazole increases YTHDC1 and improves liver disease measures, with a material
missing-control limitation on the claimed mechanism. Retaining this lead brought
the ledger at that stage to **104 appraisals**. No muscle-performance or actual-MVA efficacy
has been established for it, and it does not yet displace the nominated pair.


## Senotherapeutic reserves and mitotic comparators from 512 further entries

The [next 512 saved entries](next512-findings.md) brought outer coverage at that stage to 2,161
source/ID records, with 3,598 saved abstracts still unread at that stage. Two primary
follow-ups result.

The [muscle-senescence qualification](muscle-senescence-qualification.md) retains
the fisetin mouse-function findings and the dasatinib-plus-quercetin
combination-only reserve. Fisetin is downgraded after a separate primary cell
study found high-micromolar spindle-checkpoint override, reduced kinetochore
BubR1 localization and polyploid progeny; a fidelity-safe exposure window has
not been shown. Fisetin's mouse endpoints are body-weight-normalized, and the
human trial found no functional advantage. D+Q improves isolated EDL specific
force in female Sod1-knockout mice, but this is not absolute-force rescue and
`prior-22` remains dasatinib alone, which cannot inherit a combination effect.

The [mitotic qualification](mitotic-qualification.md) adds proTAME and Apcin as
mechanistic comparators, not medication leads. proTAME raises selected mitotic
protein and phosphorylation signals in nocodazole-challenged DNA-PKcs-deficient
cells; Apcin does not reproduce it. Combination panels return to the
deficient baseline or below, without a combination-versus-proTAME statistical
comparison. Apcin itself is suppressive in A549, limiting attribution there.
These are bulk-lysate biochemical measurements in a different lesion,
so they cannot supply per-cell checkpoint correction or faithful descendants.

At that stage, the ledger held **108 appraisals**. Nothing here establishes BUBR1
restoration or MVA efficacy, and the nominated pair is unchanged.


## Source corrections and a further fidelity lead

The [source revalidation](review-quality-followup.md) withdraws the proposed
all-read/no-further-leads conclusion from an unreliable draft. The initial 186
re-read source records plus [eight subsequent 128-record batches](batch08-revalidation-findings.md)
left 2,388 selected strings pending at that checkpoint. The later [explicit food-record admission](food-admission-findings.md) reconciled 64 already-read records, leaving **2,324** at that checkpoint. [Batch09](batch09-revalidation-findings.md) left **2,196** pending; [Batch10](batch10-revalidation-findings.md) left **2,068** pending at its checkpoint; [Batch11](batch11-revalidation-findings.md) left **1,812** pending at its checkpoint; [Batch12](batch12-revalidation-findings.md) left **1,556** pending; [Batch13](batch13-revalidation-findings.md) left **1,044** pending; [Batch14](batch14-revalidation-findings.md) left **532** pending; [Batch15](batch15-revalidation-findings.md) closes the original queue with zero pending. The
[UMK57 appraisal](umk57-qualification.md) adds a genuine acute and completed-division
fidelity result in cancer cells, followed by limited durability. It is a
mechanistic competitor, not an established MVA medicine. Apcin's context-dependent
direction, AICAR/ABT-263 combination results and a metformin protein-stabilization
precedent are kept at their qualified source depths. Neither existing nominee
is MVA-proven; absence of a replacement today is not proof of superiority.

The [six-paper follow-up](protein-and-tissue-qualification.md) now qualifies
CX-4945, metformin, Wy-14643, bFGF/collagenase, ephedrine/salbutamol and eplerenone.
It added seven compound/tool appraisals and updated metformin, for **116** at that stage.
Protein-specific stabilization and ex vivo or reported clinical functional
benefits retain positive credit; drug-assigned organ-function recovery is not
shown for Wy-14643 or eplerenone. These are different sources and endpoints,
not seven independent studies or seven approved medicines. None demonstrates
MVA efficacy or currently changes the nominations.

The [corrected catalog screen](literature-v2/summary.json) now propagates all
recovered matches and source-role decisions into current coverage and triage:
511 entities have specific co-mentions, while 14,846 remain without one. A
match is not efficacy. The [primary-question status](primary-question-status.json)
now links nine of the original 34 questions to primary qualifications, leaving
25 unreconciled there. The first seven later batches flagged 52, 49, 31, 34, 27, 22 and 14 questions.
Batch08 added 18 source questions, not 18 drugs. Current coverage is **3,598 accepted revalidations and 5,759 combined outer records**, with **zero selected strings pending** after Batch15. This does not close primary follow-up or broader discovery. Publication and
submission remain pending.


## SC-43 and garcinone D: research availability and competitive position

The [source-qualified comparison](stat3-compound-qualification.md) adds two
appraisals, bringing that stage of the ledger to **124**. SC-43 earns a controlled survival
positive in mouse liver fibrosis alongside SHP-1/STAT3 evidence. Its clinical
registration does not establish human outcomes: one trial withdrew before
recruiting anyone, and a second has unknown status without posted results.
Garcinone D earns actual compound-associated MAD2L1 protein and proliferation
results, plus separate natural-product cell-study evidence. These observations
are not BUBR1 restoration or healthy muscle rescue. Both have supplier listings;
availability alone is not efficacy. Neither currently displaces the provisional
niacin/apitegromab comparison, and neither is dismissed for being outside an
approved-drug catalogue.

A subsequent [Apcin primary qualification](apcin-liver-qualification.md)
credits improved plotted survival and lower liver-injury markers after mouse
pretreatment. It updates the existing entry rather than adding another drug.
The plot does not verify the stated seven-day endpoint or statistical survival
significance; drug-induced CDC20/BUB1B restoration was not measured. This
positive organ-level signal and the earlier negative biochemical findings
coexist, without establishing an MVA mechanism or clinical treatment window.


## Renal function and reprogramming: different positive endpoints

The [renal qualification](renal-growth-qualification.md) credits actual-drug
preservation of renal function with rapamycin and enalapril in a transgenic rat
growth-adaptation model. It separates the significant alternate-day rapamycin
result from the weaker weekly schedule and the absence of a significant
enalapril body-weight difference. Bulk Bub1b RNA decreased during protection;
that is not a per-cell BUBR1 protein measurement or a restoration mechanism.
Enalapril is a phenotype-dependent reserve, with no matching renal lesion yet
established for this case. The existing rapamycin entry gains this evidence.

The [reprogramming qualification](reprogramming-qualification.md) retains an
actual functional positive: the A2S cocktail assisted OSKM-driven mouse-cell
reprogramming, with reported stable pluripotency and normal endpoint karyotypes.
It adds separate entries for the catalog-qualified ascorbate-phosphate reagent,
SGC0946 and CHIR99021, and updates existing mirdametinib. These are components
of one protocol, not four independently effective rescue agents. The paper's
Bub1b evidence is RNA association; neither full-length BUBR1 restoration nor
muscle rescue was measured. Historic reagent identity and unread figure images
and supplements remain explicit limits.

At that stage, the ledger reached **128 appraisals**. These positives broaden the evidence
without demonstrating a better MVA candidate. Niacin/apitegromab remain
provisional, and further source questions remain open.


## Broader compounds: separate survival, protein abundance and fidelity

The [injury study](mapk-injury-qualification.md) and
[SIRT2 study](sirt2-substrate-qualification.md) add five appraisals, for **133**
at that stage. These are two primary-study appraisals with multiple compounds and separate
checkpoint counterevidence, not five independent demonstrations of benefit. All preceding decision objects are
preserved, including PR1's retained work.

| Compound | Evidence earned | Decision and limiting evidence |
|---|---|---|
| **FR180204** | Early protection of morphology, actin and metabolic signal after fungal-filtrate injury in A549 cells. | Injury-response reserve. Most signal is lost later; no BUBR1 protein, faithful division or muscle benefit measured. |
| **SP600125** | Similar early protection, with residual metabolic benefit at 24 and 36 hours. | Counter-probe. Separate Mps1 work shows checkpoint override in susceptible cells; protecting injured cells does not establish faithful division. |
| **SB203580** | A defined negative morphology/actin comparator in the same injury model. | Keep the scoped null; no matched p38 target-engagement proof or displayed XTT/flow arm. |
| **NPD11033** | SIRT2 deacetylase inhibition, PANC-1 ATP-signal reduction and a separate dose-dependent HeLa BUBR1-protein decrease. | Mechanistic counter-probe. The protein direction supports measuring this pathway, but does not prove the reverse niacin-to-BUBR1 rescue chain. |
| **SirReal2** | Actual PANC-1 ATP-signal reduction as a distinct SIRT2 comparator. | Retain the positive at its measured scope. The NPD11033 BUBR1 result was not measured for SirReal2 in this study. |

None changes the provisional niacin/apitegromab comparison. Their advantages
remain hypotheses and evidence from other diseases; these new studies supply
neither a head-to-head comparison nor an MVA efficacy estimate. The
[fourth reading batch](batch04-revalidation-findings.md) also retains further
unqualified leads rather than declaring the search complete.


## Distinguish tissue differentiation from tumor killing

The [Aquamin appraisal](aquamin-qualification.md) preserves controlled
human-adenoma differentiation responses, the calcium-alone comparison and the
specific Soluble formulation. It does not convert a BUB1B mutation in one
complex donor specimen into a measured BUBR1 deficiency or rescue. The low-dose
Ki67 decrease lacks a significance marker; morphology reverts after withdrawal.

The [KIF18A appraisal](kif18a-compound-qualification.md) gives four distinct
compounds credit for their own experiments. AM-1882, AM-5308 and AM-9022 have
actual mouse tumor responses; AM-0277 has cellular evidence. Resistant cancer
models, limited healthy-donor controls and immune-deficient hosts bound the
selectivity claim. Regression, growth inhibition and absence of measurable
tumor remain separate endpoints. This supports a specific tumor-research route,
without establishing useful nonmalignant MVA tissue restoration.

Those qualifications brought the ledger to 138 appraisals. The subsequent
[corneal study](corneal-qualification.md) adds 2-DG, Stattic and rotenone; the
[cardiomyocyte study](cardiomyocyte-qualification.md) adds FGF4 and extends the
existing ascorbate-phosphate entry. Those additions brought the ledger to **142**.

| Route | Evidence retained | Competitive implication |
| --- | --- | --- |
| 2-DG and Stattic | Reduced mouse corneal swelling, inflammation and haze after local treatment. | Real tissue benefit; no BUBR1, vision or muscle rescue. Incomplete injection schedules and safety controls limit transfer. |
| Rotenone | Adverse-direction cell-marker perturbation. | Mechanistic control, without a therapeutic rescue result. |
| FGF4 plus AA | Improved differentiation and optical beating in hESC-derived cardiomyocytes. | Combination-level cardiac function; subsequent hypoxia caused injury, and the BUB1B transcript decrease does not establish protein rescue. |

**Historical batch07 checkpoint:** the [seventh reading batch](batch07-revalidation-findings.md) brought accepted revalidations to 1,082 and left 2,516 strings pending, with 14 questions separately flagged. These are that checkpoint’s counts, not the current totals.

## Cancer control and mitotic timing are distinct positives

The [unesbulin appraisal](unesbulin-qualification.md) brought the ledger to **143** at that stage.
The official randomized LMS trial reports an incremental combination benefit:
unesbulin plus dacarbazine versus placebo plus dacarbazine, median PFS 3.6 versus
2.6 months, HR 0.61 (95% CI 0.45–0.83), P=.0017 in the 209/105 modified ITT
population. The study was terminated for a stated business decision; this must
not be relabeled as demonstrated efficacy failure. Overall-survival medians
were unestimable. Safety uses 238/120 treated participants, with serious febrile
neutropenia in 8/0; raw events are not all attributable to unesbulin.

The separate full preclinical paper supports direct colchicine-site tubulin
binding and GBM-model survival benefit. ATRT results remain conference-level
and potentially overlapping. These findings support cancer research, without
establishing selective BMI1 action, BUBR1 restoration or MVA muscle benefit.
LMS results cannot establish rhabdomyosarcoma treatment compatibility.

The [Greatwall/OA appraisal](greatwall-qualification.md) preserves a different
positive: 500 nM okadaic acid shortens entry into mitosis after MASTL depletion.
It also accelerates control-cell entry. That experiment does not measure the
number or fidelity of healthy daughter cells. The genetic PP2AC phosphorylation
comparisons have different baselines, and the older 20 nM OA partial
completed-mitosis result is retained separately. No additional OA identity or
medicine count is created. These source-specific results do not yet change the
provisional niacin/apitegromab comparison.

## BET and neural-stem-cell follow-up

**Historical BET/neural checkpoint:** nine appraisals brought the ledger to **152**. All 143
preceding assessment objects were unchanged at that stage. The
[BET review](bet-macrophage-qualification.md) distinguishes seven compounds
from one shared macrophage study; [the sFRP3 review](sfrp3-direction-qualification.md)
adds a recombinant protein and levetiracetam. AAV gene delivery is kept
separate and does not create another compound entry.

| Unelected route | Result retained | Why it does not currently displace the nominees |
| --- | --- | --- |
| ABBV-744 | Controlled mouse plaque reduction during diet challenge. | No matching MVA tissue mechanism, BUBR1 protein or useful-muscle result. Some cytokine comparisons are nonsignificant. |
| Molibresib, (+)-JQ1, apabetalone, GSK046, GSK620, MZ1 | Compound-specific cell inflammatory/lipid findings, including conditional nulls. | Six comparators share one study; no animal benefit may be borrowed from ABBV-744. MZ1 is a degrader. Apabetalone's separate cardiovascular trial missed its primary significance threshold. |
| Recombinant sFRP3 | Reduced excess stem-cell division in APP mice. | Long-term pool/behavioral findings used AAV. Hypomorphic BubR1 models start with deficient division and support the opposite genetic direction. |
| Levetiracetam | Frzb RNA increase among selected seizure responders. | Nonresponders excluded, inconsistent sample count, and no new BUBR1/muscle or all-treated functional result. |

These historical primary follow-ups supplied **zero additional abstract-reading credit**. Current coverage is recorded above; no biological replication is claimed. Niacin/restoration and apitegromab/compensation remain provisional under the same functional and safety requirements.

ABBV-744, molibresib, apabetalone and levetiracetam join existing catalog
entities by exact normalized aliases. The other five do not; none of these
joins establishes approval, efficacy or historical formulation equivalence.
The 15,357-entity retrieval denominator is unchanged.

## Quercetin aglycone: consumer identity and BUB1B source evidence

A source-bounded [GEO GSE15162 reanalysis](quercetin-bubr1b-qualification.md) examined the BUB1B probe in HepG2 cells treated with 3 μM non-conjugated quercetin. The one-array-per-condition/timepoint matrix gives small shifts in mixed directions over 2–24 hours; it contains no replicate-level variance, so no significance test is possible. BUBR1 protein, checkpoint function, chromosome fidelity, muscle and MVA were not measured. This does not elevate quercetin over niacin or apitegromab as an MVA candidate. The separate [quercetin glycoside](quercetin-glycosides-qualification.md) exercise-training preparation and dasatinib-plus-quercetin interventions do not inherit this result.

Two additional quercetin RNA pointers remain unresolved: [PMID 15309432](https://pubmed.ncbi.nlm.nih.gov/15309432/) and [PMID 21632981](https://pubmed.ncbi.nlm.nih.gov/21632981/). Their complete primary abstracts describe Caco-2 cancer-cell and HepG2 genotoxicity/transcriptomic studies, respectively, but do not name BUB1B; the database-reported gene-specific directions have not been checked against the original expression rows. GSE15162 is a distinct study and does not resolve those pointers. In the CPDat v4.0 and v4.1 formulation snapshots, a “Quercetin” ingredient name occurs in 21 Personal-care composition rows, while “Quercetin-3-glucoside” occurs in two rows. These are source rows, not purchase prevalence, supplement use or exposure measurements. A name match does not convert the transcript screen into efficacy evidence.

## CENP-F intermediates and a botanical fraction

Four administered materials from one CENP-F paper and one exact botanical preparation are assessed separately. The shared paper is not four independent studies, and a null control receives no positive efficacy credit.

| Material | What was measured | Competitive decision and weakness |
|---|---|---|
| Zoledronic acid, source hydrated disodium formulation | Reduced CENP-F kinetochore localization and increased metaphase-region misalignment in cancer cells. | Mechanistic perturbation comparator. No tumor-killing or normal-function rescue demonstrated in this source; normal-cell and apoptosis nulls were unshown. Active-name catalog mapping does not establish salt/formulation equivalence. [Qualification](zoledronate-cenpf-qualification.md). |
| trans,trans/(E,E)-farnesol | 50/100 µM concurrent treatment raised localized-cell fractions from 16.7% with zoledronic acid alone to 49.2%/60.0% (reported P<.01). | Direct partial localization-rescue comparison. No total BUBR1, completed chromosome-fidelity, survival or MVA result. Other isomers, generic mixtures and consumer products do not inherit the result. [Qualification](zoledronate-cenpf-qualification.md). |
| Source-labelled trans-geranylgeraniol | 50/100 µM comparisons were nonsignificant; reversal at 150 µM was reported without shown data. | Dose-qualified comparison, not an all-dose negative. Geometry is incomplete; high-dose magnitude and functional/BUBR1 rescue remain unknown. [Qualification](zoledronate-cenpf-qualification.md). |
| Clodronate disodium tetrahydrate | 500 µM for 48 h reportedly left CENP-F localization unchanged, data not shown. | Administered null control with no positive rescue credit; no equivalence, normal-tissue safety or MVA benefit established. [Qualification](zoledronate-cenpf-qualification.md). |
| Kalanchoe tubiflora KT-NB laboratory fraction | Cancer-culture growth suppression and spindle/chromosome defects; WI-38 is less affected than A549 but remains inhibited. | Antimitotic preparation comparator. Unknown active composition and source dose/denominator conflicts; no BUB1B assay or useful normal-cell rescue. No household-plant or ingredient equivalence. [Qualification](kalanchoe-mitosis-qualification.md). |

## Conditional chromosome-congression comparators

The accessible published source supplies real partial alignment improvements in non-transformed RPE-1 cells. Its title/first-author link to the flagged preprint does not verify that preprint’s version or text. Cells, not independent studies or donors, underlie the descriptive means.

| Material | Measured evidence | Competitive decision and weakness |
|---|---|---|
| Centrinone | Centriole loss permits a restricted congression bypass after CENP-E perturbation. | Organelle-loss-dependent mechanism comparator; rare fully acentriolar RPE-1 cells, anaphase-selection limits and absent faithful-daughter/tissue outcomes prevent a restoration claim. [Qualification](cenpe-feedback-qualification.md). |
| MLN8054 | Polar-chromosome mean 3.553 versus 7.026 under CENP-E inhibition; reported Tukey P=1.77×10⁻⁷. | Partial congression positive in non-transformed RPE-1, with accompanying spindle shortening. Pooled quantitative columns omit exact dose composition; no BUBR1 or completed-fidelity result. [Qualification](cenpe-feedback-qualification.md). |
| TCS7010 | 100 nM/30 min: polar-chromosome mean 3.857 versus 7.026; reported Tukey P=4.39×10⁻⁶. | Partial congression positive, with shortened spindles. Useful normal-tissue function, faithful daughter yield and MVA transfer are untested. [Qualification](cenpe-feedback-qualification.md). |
| Alisertib / MLN8237 | 125 nM/30 min: polar-chromosome comparison P=.117; phosphosignal ratio and spindle length also nonsignificant. | Retain this exposure-specific null. Longer/higher exposure was not tested; the conflicting MLN8237 caption does not confer MLN8054 efficacy. [Qualification](cenpe-feedback-qualification.md). |
| Existing GSK-923295, ZM-447439, monastrol and MG-132 | Respectively a lesion inducer, phospho-marker control, separate negative/structural control and metaphase-arrest support. | Their prior source evidence is preserved. None inherits the Aurora-A congression positives or genetic Hec1-9A rescue from this paper. [Qualification](cenpe-feedback-qualification.md). |

## Common consumer compounds: label prevalence is not efficacy

The [public NIH DSLD full-label export](dsld-label-prevalence/README.md) provides a new product-label breadth layer for common consumer compounds. This file came from the publicly exposed staging-S3 bulk asset; its embedded readme identifies version 9.4.0 | January 2026, with **214,780 distinct labels**, of which **121,959 are marked on-market**. The production API separately reported version 9.5.0 (May 2026), so these counts are tied to the embedded bulk-file snapshot, not assumed to match that later index. We counted distinct labels containing each exact Supplement Facts ingredient string; source spellings and formulations remain separate. This is not a sales, current-retail-stock, user-exposure or efficacy ranking.

| Exact label string | Labels marked on-market | BUB1B / muscle relevance and decision |
|---|---:|---|
| Niacin | 10,617 | Supports broad supplement-label presence only; form is unspecified in the export. Only 23 labels literally say “Nicotinic Acid,” while 627 say “Niacinamide.” These entries cannot inherit the clinical nicotinic-acid regimen's muscle NAD result. |
| Beta-Nicotinamide Mononucleotide / Nicotinamide Mononucleotide / NMN | 45 / 23 / 9 | Direct NMN-to-BubR1 evidence remains preclinical; the distinct literal-label counts are not combined. Human NMN outcomes remain mixed, and no label count establishes target engagement. |
| Vitamin K2 | 1,306 | Worth a higher-priority form-and-assay follow-up because a separate mouse study reported Bub1b RNA and tissue-fluorescence signals. The tested subtype, per-cell functional BUBR1 and muscle benefit remain unestablished. Menaquinone-7 (49) and menaquinone-4 (19) are separate source strings. |
| Amla / *Phyllanthus emblica* | Amla 340; Amla Fruit Extract 92; Amla extract 77; Amla fruit extract 57; Phyllanthus emblica fruit extract 7 | One BubR1-mRNA/chromosome-endpoint study and two same-group cancer/chemotherapy-context studies justify a laboratory comparison. These spellings are not summed or equivalent to the studied extracts. Protein mediation, MVA muscle and systemic exposure remain unknown; arrest/selection can lower damage counts at a cost to output. |
| Chondroitin sulfate | 899 | The [FCS cancer-cell paper](https://pubmed.ncbi.nlm.nih.gov/39583738/) identifies BUB1B computationally but assays BUB1/PLK1; its sea-cucumber fucosylated glycan is not the ordinary supplement ingredient. The existing [human glucosamine/chondroitin study](glucosamine-chondroitin-qualification.md) reports CRP and an unresolved plasma antibody signal, not functional intracellular BUBR1. |
| Resveratrol | 697 | The existing [one-control/three-treatment array](resveratrol-bubr1b-qualification.md) is a small, non-inferential BUB1B-down signal; separate exercise outcomes do not establish BUBR1 restoration. |
| Saffron | 45 | The [BUBR1-containing study](https://pubmed.ncbi.nlm.nih.gov/30710515/) treated cells with purified crocin and disrupted microtubules; retail saffron is not the tested crocin exposure or a checkpoint-restoration demonstration. |
| Thymoquinone | 34 | In the [co-mentioned PLK1-inhibitor study](https://pubmed.ncbi.nlm.nih.gov/25975351/), BubR1 activation was caused by BI 2536/GSK461364, not thymoquinone. |
| Oleic Acid / exact lowercase Oleic acid | 813 / 3 | Actual PA-injury cotreatment produced a descriptive BUB1B RNA mean 1.184× PA alone, still below control, with no gene-specific significance, BUBR1 protein or fidelity outcome. Exact label spellings remain separate; food fatty-acid intake is outside this supplement-label count. |
| Eicosapentaenoic Acid / EPA | 3,375 / 138 | EPA was included in the PA-injury study but no EPA BUB1B RNA arm was deposited; lipid readouts do not inherit oleic acid's separate transcript change. Exact spellings are not pooled. |
| Creatine monohydrate | 1,180 | A visible consumer muscle-function comparator, but no BUB1B/MVA rescue. Other creatine formulations are not pooled. |
| Taurine / L-Taurine | 2,644 / 809 | Common muscle-physiology entries, with no demonstrated BUBR1 restoration or MVA benefit. Source spellings remain separate. |
| Caffeine anhydrous / Caffeine | 2,347 / 1,816 | Product-label presence does not establish ordinary-use chromosome harm; the existing source-specific fidelity qualification governs. The forms are not pooled here. |
| Quercetin / Quercetin dihydrate | 1,788 / 403 | The bounded HepG2 BUB1B RNA reanalysis remains small and mixed-direction; no BUBR1 protein or function result. Hydrate/formulation is separate. |
| Fisetin | 52 | Its source-specific spindle-checkpoint override remains a fidelity concern; no candidate advancement without a fidelity-safe exposure window. |
| N-acetylcysteine label spellings | N-Acetyl-L-Cysteine 557; N-Acetyl Cysteine 529; N-Acetyl L-Cysteine 210; N-Acetyl-Cysteine 99; N-Acetylcysteine 60 | The already-reviewed Sod1-deficient oocyte experiment reports improved chromosome outcomes at 500 µM, but did not remeasure BUBR1 after NAC. This is a strong common-compound fidelity comparator, not MVA or muscle rescue; spellings are not summed. |
| Ascorbic-acid label spellings | L-Ascorbic Acid 8; Ascorbic Acid 161; Vitamin C 19,525 | The same oocyte study reports a separate 500 µM L-ascorbic-acid arm with the same reported normal-chromosome percentage as NAC. Broad Vitamin C labels do not establish that exact preparation. |
| Linoleic Acid | 875 | The already-reviewed NSCLC B7E2 study tested isolated linoleic acid with vinorelbine for apoptosis; BUBR1 phosphorylation/MCC activation was measured for the mixed B7E2 extract plus vinorelbine. This is a tumor-chemosensitization context, not BUB1B restoration or muscle benefit. |

This label screen does not change the provisional niacin/apitegromab nominations. Generic “Niacin” labels do not identify the clinical nicotinic-acid formulation or exposure; apitegromab is a prescription biologic outside this supplement database. Amla supplies a high-priority laboratory comparison among reviewed consumer preparations: one study measured a positive BubR1 mRNA response and chromosome-related endpoints, while two same-group papers add cancer/chemotherapy context and potential selection costs. This is not three-study BUBR1 replication. MVA cells might respond adversely, so preparation, exposure, functional protein, useful output and progenitor renewal require measurement. Vitamin K2 remains a form-and-assay follow-up, and NAC a chromosome comparator from a different lesion. The B7E2/linoleic-acid result remains tumor-cell sensitization evidence. See the [candidate shortlist](../../reports/appendices/track2-candidate-shortlist.md), [current report](../../reports/jeweled_track2_report_submission.md) and [route decisions](../../reports/appendices/track2-route-decisions.md).


The [food/BCAA/Shoden follow-up](common-preparation-counterevidence.md) adds three bounded preparation appraisals: Camembert physical-function nulls, shared-training rather than added BCAA benefit, and controlled Shoden symptom nulls despite hormone changes. Two mains remain inaccessible; none adds an objective-function positive or changes the nominees.

The [three further preparation comparisons](common-preparation-functional-followup.md) retain shatavari training/contractility and MFGM-mixture mobility positives alongside strength/pain nulls and analysis limits. The protein-meal walking signal remains abstract-bounded, with grip decline in both arms and relative hsCRP increase. These bring the ledger to 303 without changing the nominees.

The [dated FDA refresh](fda-approval-refresh-20261004.md) adds five product rows already represented by catalog names; no molecules, efficacy appraisals or abstract-reading credit follow. Selected label endpoints and source-access limits remain distinct from pending primary-paper qualification.

The [MFGM fraction qualification](mfgm-function-qualification.md) admits one preparation-family appraisal, bringing coverage at that checkpoint to **304**. It retains a small controlled primary strength benefit, agility/conduction positives and comparative strength nulls under shared exercise. Fraction identity, carryover, subsets and unknown participant overlap prevent constituent attribution or four-independent-trial counting; nominations remain unchanged.

The [batch 14 primary follow-ups](batch14-primary-followups.md) add one tannase-treated green-tea preparation and amend existing riboflavin/CoQ10 appraisals. Complete and partial source access remain distinct; narrow exercise signals and nulls do not establish BUB1B/MVA benefit. Ledger coverage at that checkpoint was **305 appraisals**.

The [creatine–HMB rowing preparation](creatine-hmb-rowing-qualification.md) adds the 306th appraisal: a reported W8 lactate-indexed power comparison, with nonsignificant WAT/W4 and body-composition interactions. Original numerical conflicts and unconfirmed formal synergy remain explicit. This adds no chemical entities or eligibility records, inherits no component aliases and changes no nominees.

The separately qualified [acute-stroke creatine regimen](creatine-acute-stroke-qualification.md) found no significant controlled benefit in its reported functional, strength or mass/degradation outcomes. This small seven-day pilot does not establish equivalence or negate the distinct myopathy/dystrophinopathy results. Nominal biomarker findings, gastrointestinal symptoms and creatinine rises remain explicit; the chemical form is unknown and aliases remain empty. The source-specific addition brings the curated comparison to 307 appraisals without changing nominees or eligibility coverage.

The preparation-specific [Pennisetum aqueous-extract appraisal](pennisetum-muscle-qualification.md) retains a reported grip interaction alongside nonsignificant visit-level grip, walking and comparative mass/marker results. Paper and current registry disagree on allocation, and harms ascertainment remains incomplete. This adds the 308th appraisal with empty aliases, no eligibility increment and no nominee change; it does not establish BUB1B/MVA benefit.

The preparation-specific [Korean red ginseng tablet appraisal](korean-red-ginseng-muscle-qualification.md) retains a reported secondary self-reported FSS change comparison. Objective force/task performance was unmeasured; TAS and blood mtDNA remain biomarkers. Allocation wording, completer analysis, retrospective registration, missing outcomes, printed conflicts and harms uncertainty remain explicit. This adds the 309th appraisal with empty aliases, no eligibility increment and no nominee change; it does not establish BUB1B/MVA benefit.
