# Mechanical reproduction

Read-only full check (writes nothing):

```sh
python3 /Users/jeweled/mva-hackathon/track2-drug-census-work/global-existing-evidence-stage-register-20261005/verify_mechanical_register.py --check-only
```

Rebuild in a new destination that does not exist, using frozen metadata only:

```sh
python3 /Users/jeweled/mva-hackathon/track2-drug-census-work/global-existing-evidence-stage-register-20261005/rebuild_from_frozen_inputs.py --destination /absolute/new/output-directory
```

This reconstructs the register/TSVs from frozen repository inputs and explicit-document snapshots; it does not consult live reports or fetch/reappraise scientific bodies. The byte-pointer QA separately checks current existence/hash and never awards reading credit. The original package stays immutable. Future rechecks may identify a changed/deleted foreign pointer without altering its historical capture record.

Pipeline: capture exact stable inputs and explicit metadata pointers; build_existing_stage_register.py; augment_identity_fields_and_limits.py; complete_catalogue_projection_and_write_final_tsv.py; verify_mechanical_register.py. Builders accept MVA_STAGE_REGISTER_ROOT for a fresh destination and reject existing scientific output files where applicable. Main and separate status-unverified inputs are frozen independently. Input-snapshot-bindings.json and additional-needed-catalogue-input-binding.json retain exact capture paths, HEAD and hashes.

mechanical-qa.json records125,332 passing checks. frozen-input-rebuild-verification.json records the actual fresh rebuild,12 passing comparison groups and byte-identical TSVs. Historical failures and the reference-order-only correction are retained; no original reported field or chronology was rewritten. final-bindings.json and final-verification.json exclude only their own exact root self-paths, while every saved foreign-manifest copy is bound.

Counts are decision/source-URL/component/pointer occurrences, not unique drugs, trials, actual source readings or efficacy. No worldwide, full-primary, validated RNA/protein/checkpoint/fidelity/function or comparative efficacy denominator is invented.
