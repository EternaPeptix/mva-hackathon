import pathlib,json,datetime
O=pathlib.Path('/Users/jeweled/mva-hackathon/track2-drug-census-work/global-existing-evidence-stage-register-20261005')
def j(n):return json.loads((O/n).read_text())
d=j('bounded-stage-denominators.json');q=j('mechanical-qa.json');r=j('frozen-input-rebuild-verification.json');s=j('input-snapshot-bindings.json');m=j('historical-partial-access-and-mixed-depth-index.json')
end=j('repository-end-state-and-captured-scope.json')
assert q['status']==r['status']=='PASS'
component_lines=[]
for k,v in d['component_scoped_claim_presence_counts'].items():
 component_lines.append('|'+k+'|'+str(v.get('VERBATIM_SCOPED_CLAIMS_PRESENT_NOT_VALIDATED',0))+'|'+str(v.get('UNKNOWN_NO_EXPLICIT_COMPONENT_READING_RECEIPT_AT_THIS_IDENTITY',0))+'|')
text=f'''# Linked existing-evidence stage register

This mechanical register preserves every complete existing decision object at captured repository HEAD `{s['HEAD_start']}`: **309 decisions**, not309 unique drugs, preparations, primary readings or independent trials. It implements the linked-stage work identified in the frozen scope audit `b1cc3d7791d1819791b2ae7f5aa4bb9f789723fba713e531e36d3c6dddd447f6`. The broader objective remains worldwide drug/common-compound coverage and comparable BUB1B/function evidence; this register does not establish global inventory or efficacy completeness.

All original fields, aliases, source pointers, evidence labels, limits, shared-primary identifiers and nominee dispositions are retained verbatim. No scientific outcome was reappraised. No chemical join, alias, source-reading credit, accepted screen, trial/cohort count, efficacy rank or nominee change is granted. Q03 and all foreign packages remain unchanged.

## Bounded units and proven counts

|Unit|Count|What the count establishes|
|---|---:|---|
|Complete existing ledger objects|309|Exact original decision values and order retained, including every optional field.|
|Distinct original primary report pointer values|153|All resolve locally at capture; report presence is not source reading.|
|Original source-URL occurrences|874|873 source_urls plus1 additional_source_urls occurrence; identifiers, not unique bodies/trials.|
|Component rows|8,740|10 component categories for each URL/preparation/contrast identifier occurrence.|
|Individually frozen explicitly reached documents|947|220 Markdown,720 JSON and7 JSONL documentation/metadata files; no foreign tree enumeration.|
|Reported depth/scope fields and lines|14,673|Verbatim claims with exact supporting document/JSON pointer or literal line/character coordinates; includes metadata, dates, negatives and partials.|
|Reported structured stage fields|516|Existing fields only; no new assay or efficacy interpretation.|
|Report topic statements|2,740|Verbatim statements retained; topic words are not validated stage labels.|
|Preparation/comparator/contrast/route/dose/population/time fields|1,674|Existing values retained. No explicit contrast_id/preparation_id/study_family_id keys found in these linked originals; such IDs remain UNKNOWN.|
|Explicit raw-byte pointer occurrences freshly rechecked|14,453|Byte/hash existence only, with repeats; not new source reading or body equivalence.|
|Uncapped explicit gap objects|12,660|Overlapping decision-stage, component and unresolved-pointer gaps; not12,660 distinct study defects.|

Every scientific-looking number or statement is an existing reported field/line with its original pinned source-document locator. These labels and values are not newly accepted scientific evidence. Reported reading is kept separate from independently verified file bytes and from exact source/body/cohort equivalence, which is UNKNOWN unless explicitly supplied. A hash, title, directory, rationale, shared DOI/PMID/PMCID/registry or name does not validate reading, comprehension or clinical efficacy.

## Catalogue presence and existing joins

The needed stable catalogue inputs are frozen individually:14,882 main catalogue rows,475 separate DrugCentral status-unverified source rows,15,357 appraisal-projection rows and309 decision-alias projection rows. Original source statuses, forms and unresolved identity limits remain unchanged.

Decision-row join states are **119 EXACT_ALIAS_SINGLE_ENTITY**, **12 AMBIGUOUS_MULTIPLE_ENTITIES** and **178 NO_CATALOG_MATCH**. The separate catalogue-appraisal projection has **115 MANUAL_DECISION_EXACT_ALIAS_JOIN**, **25 AMBIGUOUS_REQUIRES_IDENTITY_REVIEW** and **15,217 UNKNOWN_NOT_IN_CURATED_APPRAISALS**. These are different denominators and are not combined or relabelled as efficacy coverage.

Three reported DC-prefixed projection IDs lie outside the main catalogue and are retained against their exact integer IDs in the separate475-row status-unverified table. This is a lookup of an existing projection identifier representation, not a chemical/name/alias join or approval upgrade. Both source layers remain separate; original alias and appraisal rows are unchanged.

## Component depth: claims remain claims

The table counts URL/preparation/contrast identifier occurrences with explicitly scoped component mentions in existing depth fields. **Positive, negative, partial, access-limited, metadata-only and historical claims are all included. These counts are not actual-reading, full-source completion or validated primary denominators.** UNKNOWN means no explicit component-depth claim was attributable at that identifier scope under this mechanical method; document-scope claims remain available separately rather than being silently assigned to every source in a shared report.

|Component|Occurrences with scoped component claims, unvalidated|UNKNOWN explicit component-depth scope|
|---|---:|---:|
'''+ '\n'.join(component_lines)+f'''

The full-main qualified-source denominator is **UNKNOWN**. Validated restoration/RNA/protein/checkpoint/chromosome-fidelity/function/compensation denominators are **UNKNOWN**. Unique drug/chemical/preparation/cohort/trial and comparable-competitiveness denominators are **UNKNOWN**. This audit grants0 scientific source-reading credit; that does not assert that previous reviewers read0 sources.

The register contains every309 original route, disposition, evidence_scope, bub1b_variant_efficacy and rationale value. Existing stage-related structured values and report statements retain their source scope and literal text. Requested stage-specific validation stays UNKNOWN instead of being reconstructed from title/rationale or generic topic wording. Function, biomarkers, compensation and genotype-specific restoration remain distinct labels in their original context; no new scientific label is assigned here.

## Identity, contrasts and retrieval scope

Each source URL occurrence retains its original decision/preparation route, its original ledger field/index, identifier tokens, explicit linked-document edges and component rows. Shared DOI/registry/name denotes an identifier edge; it does not establish the same cohort, source-body version, drug form, preparation or comparison. Existing shared-primary source-group and shared-evidence-with fields remain intact in the complete original objects, without additional trial counts.

Explicit preparation, comparator, contrast and time values are separately indexed and linked only through declared identifier context. When no explicit contrast ID exists, the register says UNKNOWN; it does not manufacture a contrast from a favorable outcome, report title or paragraph. Reported body depth and independently byte-checked pointers are separate fields. The latter do not prove publisher authenticity, whole-body completeness, scientific reading or comprehension.

The crawler followed exact source_report/additional/related report pointers and direct ledger audit paths, plus explicit local documentation/metadata links and literal JSON pointers. It did not search directories for convenient companions, fetch new article bodies or pursue generic name aliases. Ordinary remote article links remain identifier edges. Unresolved exact pointers are retained with the original pointer and reason, rather than guessed replacement paths.

## Historical, partial, access and contradictory depth

All{m['limit_claim_count']} captured partial/negative/metadata-only/UNKNOWN/access-limit claim references remain visible. The index retains{m['count']} component rows with multiple reported depth classifications as possibly historical, mixed or contradictory; it does not resolve them by voting or assume a contradiction without context. Older claims are not erased by later claims. Missing supplements/protocols/history/notice links do not prove none existed; absence of an explicit receipt does not imply no biological effect.

The explicit gap file preserves every decision-stage UNKNOWN, every component lacking attributable reported depth, and all3,217 unresolved pointer occurrences in the directed graph. These counts overlap, so they are not summed as independent scientific gaps. All25 explicit ledger audit path/hash/byte bindings match their captured documents; that validates bytes only.

## Fresh QA and reproducibility

All **{q['check_count']:,} mechanical checks passed**. Checks include all309 complete original objects and canonical hashes; unchanged alias/catalogue projections; every captured metadata file; all14,673 exact depth fields/lines; all516 structured stage fields,2,740 report statements and1,674 preparation/contrast values; all874 URL occurrences/8,740 component rows; exact TSV round trips; and14,453 fresh explicit raw-pointer byte rechecks. No comprehension or clinical evidence is validated by these checks.

A rebuild using frozen inputs only passed all12 comparison groups and the same{q['check_count']:,} QA checks. All3 TSVs are byte-identical; all9 compared JSON objects are semantically identical except generated top-level UTC timestamps. One early helper failure and one nondeterministic derived-reference order failure are retained in historical folders; the latter changed only reference-list order, preserving all original fields, claims and chronology. Derived reproduction scratch was removed after successful comparison, with its hashes and exact command receipts preserved.

The captured HEAD is retained. The end-of-run readonly HEAD is `{end['current_HEAD_readonly']}`, which differs from the capture; the decisions input hash remains `{end['current_decisions_sha256_metadata_only']}` at that read. Concurrent B17/other changes were not rebound into this register. No growing screen or other agent directory is bound. The final manifest covers only this owned directory and individual frozen inputs; it does not bind foreign live trees or claim the captured309 state is a permanent current ledger count.

## Deliverables and remaining broader work

- source-evidence-stage-register.json: all309 complete decisions,874 source/preparation/contrast identifier occurrences and8,740 component rows.
- source-evidence-stage-register-decisions.tsv, source-evidence-stage-register-sources.tsv and source-evidence-stage-register-components.tsv: complete final machine-readable projections, including verbatim original decision objects.
- reported-reading-depth-claims-verbatim.json and existing-stage-statements-and-fields-verbatim.json: uncapped literal reported claims/labels with supporting manifest/document fields.
- explicit-preparation-contrast-fields-verbatim.json and explicit-linked-document-capture.json: exact identity/preparation and pointer provenance.
- bounded-stage-denominators.json and uncapped-explicit-gaps.json: only proven bookkeeping denominators and explicit UNKNOWN scope.
- historical-partial-access-and-mixed-depth-index.json and ledger-explicit-audit-pointer-binding-checks.json: historical/negative/mixed scope and independently checked expected bytes.
- mechanical-qa.json, frozen-input-rebuild-verification.json and executable scripts: reproducible mechanical QA.

Worldwide inventory closure still requires separately bounded jurisdiction/product/acquisition-class retrieval. Comparable BUB1B/function coverage still requires exact source families, component-level actual reading receipts, genotype/assay distinctions and controlled comparable contrasts. This register makes the existing reported evidence and missing scope inspectable; it changes no nomination or efficacy ranking.
'''
(O/'report.md').write_text(text)
(O/'summary.md').write_text(f'''# Existing-evidence stage register complete

All309 existing decisions are preserved verbatim at captured HEAD `{s['HEAD_start']}`. The register contains874 original URL occurrences and8,740 component rows; these are not unique drugs or trials.

Reported depth and labels remain separate from verified bytes:947 exact linked documents,14,673 reported depth fields,1,674 preparation/contrast fields and12,660 uncapped gap objects are retained. Main and475 status-unverified catalogue rows remain separate; no chemical or alias join is added. Whole-primary, validated BUB1B/restoration/function and competitiveness denominators remain UNKNOWN.

All{q['check_count']:,} mechanical QA checks passed, including14,453 explicit byte-pointer rechecks. Frozen-only rebuild passed12 comparisons; all3 TSVs are byte-identical. Historical helper failures and mixed/partial/access claims are retained. Q03, foreign packages, repository, evidence labels and nominees remain unchanged; all new admission/source-reading/trial/rank credits are0.

[Register]({O/'source-evidence-stage-register.json'}) · [Decision TSV]({O/'source-evidence-stage-register-decisions.tsv'}) · [Component TSV]({O/'source-evidence-stage-register-components.tsv'}) · [Full report]({O/'report.md'})
''')
(O/'REPRODUCIBILITY.md').write_text(f'''# Mechanical reproduction

These commands reproduce this pinned309-decision snapshot. Full-primary and validated scientific-stage denominators remain UNKNOWN; a later ledger needs a separately versioned capture.

Read-only full check (writes nothing):

```sh
python3 {O/'verify_mechanical_register.py'} --check-only
```

Rebuild in a new destination that does not exist, using frozen metadata only:

```sh
python3 {O/'rebuild_from_frozen_inputs.py'} --destination /absolute/new/output-directory
```

This reconstructs the register/TSVs from frozen repository inputs and explicit-document snapshots; it does not consult live reports or fetch/reappraise scientific bodies. The byte-pointer QA separately checks current existence/hash and never awards reading credit. The original package stays immutable. Future rechecks may identify a changed/deleted foreign pointer without altering its historical capture record.

Pipeline: capture exact stable inputs and explicit metadata pointers; build_existing_stage_register.py; augment_identity_fields_and_limits.py; complete_catalogue_projection_and_write_final_tsv.py; verify_mechanical_register.py. Builders accept MVA_STAGE_REGISTER_ROOT for a fresh destination and reject existing scientific output files where applicable. Main and separate status-unverified inputs are frozen independently. Input-snapshot-bindings.json and additional-needed-catalogue-input-binding.json retain exact capture paths, HEAD and hashes.

mechanical-qa.json records{q['check_count']:,} passing checks. frozen-input-rebuild-verification.json records the actual fresh rebuild,12 passing comparison groups and byte-identical TSVs. Historical failures and the reference-order-only correction are retained; no original reported field or chronology was rewritten. final-bindings.json and final-verification.json exclude only their own exact root self-paths, while every saved foreign-manifest copy is bound.

Counts are decision/source-URL/component/pointer occurrences, not unique drugs, trials, actual source readings or efficacy. No worldwide, full-primary, validated RNA/protein/checkpoint/fidelity/function or comparative efficacy denominator is invented.
''')
print(json.dumps({'status':'REPORTS_COMPLETE','report_characters':len(text),'QA_checks':q['check_count'],'rebuild_status':r['status']}))
